# 覆盖率相关内容
echo "coverage prepare"
sudo -iu sankuai

function rm_merge_class() {
    if [ -d /opt/meituan/mobile/mergeclasses ]; then
      echo "coverage: remove mergeclasses";
      rm -rf /opt/meituan/mobile/mergeclasses
    fi
}

rm_merge_class