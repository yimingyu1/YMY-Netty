#!/bin/bash


gitUri=""
sourcePath=""
newBranch=""
oldBranch=""



gitUri=$1
sourcePath=$2
newBranch=$3
oldBranch=$4



echo "coverage：参数信息"
echo "    源码相对路径路径："$sourcePath
echo "    当前测试分支："$newBranch
echo "    原测试分支："$oldBranch
echo "    测试项目GitUri："$gitUri


echo "coverage：删除之前存放code的目录"
rm -rf ./$sourcePath

echo "coverage：创建新的存放code的目录"
mkdir -p $sourcePath
echo "mkdir -p" $sourcePath

currentDir=`pwd`

echo "coverage：git clone -b "$newBranch $gitUri $sourcePath
git clone -b $newBranch $gitUri $sourcePath

cd $sourcePath

echo "coverage：git fetch origin"
git fetch origin

if [ ! -z $oldBranch ]; then
  echo "coverage：oldBranch 参数存在，拉取 $oldBranch 的内容"
  echo "coverage：git checkout $oldBranch"
  git checkout $oldBranch
  echo "coverage：git pull origin $oldBranch"
  git pull origin $oldBranch
fi

echo "coverage：git checkout $newBranch"
git checkout $newBranch

if [ -d $sourcePath/src/main/java/ ];then
  # 拷贝源码文件到 source 目录
  echo "coverage：[第一处] cp -r -f $sourcePath/src/main/java/* $sourcePath"
  cp -r -f $sourcePath/src/main/java/* $sourcePath
fi

# 开始遍历 sourcePath 下的其他文件夹
dir=$(ls -l $sourcePath |awk '/^d/ {print $NF}')

echo "coverage：$sourcePath 下存在如下目录"
echo $dir

echo "coverage：开始复制"
for i in $dir
    do
        # 检测到 **/**/target/classes 类型的目录
        if [ -d $sourcePath/$i/src/main/java/ ];then
            # 拷贝源码文件到 source 目录
            echo "coverage：cp -r -f $sourcePath/$i/src/main/java/* $sourcePath"
            cp -r -f $sourcePath/$i/src/main/java/* $sourcePath
        # 检测到 **/**/**/target/classes 类型的目录
        elif [ -d $sourcePath/$i/*/src/main/java/ ];then
            # 拷贝源码文件到 source 目录
            echo "coverage：cp -r -f $sourcePath/$i/*/src/main/java/* $sourcePath"
            cp -r -f $sourcePath/$i/*/src/main/java/* $sourcePath
        else
          echo "coverage：是未见过的源码路径，不是 $sourcePath/$i/src/main/java/ 也不是 $sourcePath/$i/*/src/main/java/"
        fi
    done








