#!/bin/bash -e
# 拉取分支并同步数据到branch文件中
branchFileName=$1
gitAddress=$2
componentDir=$3
branchFileDir=$4
suffix=$5
if [ ! -d $componentDir ];then
  echo "开始创建[$componentDir]目录"
  mkdir -p $componentDir
  echo "[$componentDir]目录创建完毕"
fi
cd $componentDir
echo "进入到[$componentDir]目录下"
if [ ! -d $componentDir$branchFileName ];then
  echo "开始clone[$gitAddress]"
  git clone $gitAddress
  codeStatu=$?
  [ $codeStatu -eq 0 ] || ! echo $codeStatu || exit
fi
cd $branchFileName
echo "进入[$branchFileName]目录"
ls | xargs rm -rf
if [ ! -d $branchFileDir ];then
  echo "开始创建[$branchFileDir]目录"
  mkdir -p $branchFileDir
  echo "[$branchFileDir]目录创建完毕"
fi
filepath=$branchFileDir$branchFileName$suffix
if [ ! -f $filepath ];then
  echo "开始创建[$filepath]文件"
  touch $filepath
  echo "[$filepath]文件创建完毕"
fi
echo "重定向所有分支到[$filepath]文件中"
git branch -a > $filepath
echo $?