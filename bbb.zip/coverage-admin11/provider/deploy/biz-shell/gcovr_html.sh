# !/usr/bin/env bash

# 只做iOS端覆盖率文件生成html报告
#/Users/weibin/Desktop/wasd/test11/hh

gcovr -r=$1 --html --html-details -o example-html-details.html
