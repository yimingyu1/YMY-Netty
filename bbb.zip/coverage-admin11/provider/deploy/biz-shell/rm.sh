# !/usr/bin/env bash

# 删除目标目录的文件

echo "删除 $1 的内容"

rm -rf $1