# !/usr/bin/env bash

# 只做iOS端覆盖率文件生成csv报告
#/Users/weibin/Desktop/wasd/test11/hh

gcovr --root=$1 --csv -o coverage.csv
