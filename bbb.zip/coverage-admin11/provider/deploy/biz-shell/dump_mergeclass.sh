#!/bin/bash


iplist=""
sourcePath=""

iplist=$1
sourcePath=$2



echo "coverage：参数信息"
echo "    class的相对路径："$classPath
echo "    被测试服务器ip地址列表："$iplist

echo "coverage：删除之前存放class的目录"
rm -rf ./$2

echo "coverage：创建新的存放class的目录"
mkdir -p $2

currentDir=`pwd`

cd $2

rm -rf mergeclasses

array=(${iplist//,/ })

echo "coverage：复制被测试服务器上的 mergeClasses"
for var in ${array[@]}
   do
       scp -r sankuai@$var:/opt/meituan/mobile/mergeclasses/ $2/
#       scp -r /Users/guoyixuan/workspace/aserver/libs/mergeclasses/ $2/
       echo "scp -r sankuai@$var:/opt/meituan/mobile/mergeclasses/ $2/"
   done
