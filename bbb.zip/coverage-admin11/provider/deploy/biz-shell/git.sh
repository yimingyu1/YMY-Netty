#!/bin/bash

codePath=""
sourcePath=""
iplist=""

codePath=$1
sourcePath=$2
iplist=$3

echo "coverage：参数信息"
echo "    源码的相对路径："$classPath
echo "    code存储位置："$sourcePath

echo "coverage：删除之前存放源码的目录"
rm -rf ./$2

echo "coverage：创建新的存放源码的目录"
mkdir -p $2

currentDir=`pwd`

cd $2
array=(${iplist//,/ })

echo "coverage：复制被测试服务器上的源码"
for var in ${array[@]}
   do
      scp -r $1 $2
      echo "scp -r $1 $2"
#       scp -r sankuai@$var:$1 $3/
#       echo "scp -r sankuai@$var:$1 $3/"
   done

