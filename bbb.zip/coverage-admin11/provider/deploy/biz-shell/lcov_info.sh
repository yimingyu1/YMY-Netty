# !/usr/bin/env bash

# iOS端增量覆盖率中间文件.info文件生成

lcov -b $1 -d $2 -c -o result.info --rc lcov_branch_coverage=1
