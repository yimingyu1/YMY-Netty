# !/usr/bin/env bash

# 只做克隆代码

git clone -b $2 $1 $3