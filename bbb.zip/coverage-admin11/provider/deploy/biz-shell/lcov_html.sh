# !/usr/bin/env bash

# 生成iOS端增量覆盖率html报告

genhtml -o result result.info
