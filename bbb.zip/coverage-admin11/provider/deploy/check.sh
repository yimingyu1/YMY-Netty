#!/bin/sh
WAIT_SECONDS=30
k=1
COUNT=0
echo "check service......"
if [ -z $TEST_PORT ]; then
    echo "Warning:Need a test_url!"
    exit 0
fi

for k in $(seq 1 $WAIT_SECONDS)
do
    sleep 1
    COUNT=`netstat -ntlp | grep $TEST_PORT | wc -l`
    if [ $COUNT -gt 0 ]; then
        echo "request test_port:$TEST_PORT succeeded!"
        echo "response count:$COUNT"
        exit 0
    else
        echo "request test_port:$TEST_PORT failed!"
        echo "response code: $COUNT"
        echo "try one more time:the $k time....."
    fi
    if [ $k -eq $WAIT_SECONDS ];then
        echo "have tried 30 times, no more try"
        echo "failed"
        exit -1
    fi

done
