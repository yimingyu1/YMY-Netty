package com.maoyan.coverage.admin.provider.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * @author lizhuoran05
 * @date 2021/7/8
 */
@Configuration
@ConfigurationProperties(prefix = "sso")
public class SSOConfig {

    private String secret;
    private String clientId;

    public String getSecret() {
        return secret;
    }

    public void setSecret(String secret) {
        this.secret = secret;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

}
