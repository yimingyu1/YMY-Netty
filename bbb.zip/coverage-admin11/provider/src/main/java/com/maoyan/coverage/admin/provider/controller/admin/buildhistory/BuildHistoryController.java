package com.maoyan.coverage.admin.provider.controller.admin.buildhistory;

import com.maoyan.coverage.admin.biz.build.BuildHistoryManageBiz;
import com.maoyan.coverage.admin.biz.jobmanage.JobOptManageBiz;
import com.maoyan.coverage.admin.domain.constant.ErrorMessageConstant;
import com.maoyan.coverage.admin.domain.constant.PageingConstant;
import com.meituan.mobile.movie.common.response.ApiResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * @author yimingyu
 * @date 2021/07/29
 */
@RestController
@RequestMapping("/api/admin/buildHistory")
@Slf4j
public class BuildHistoryController {

    @Resource
    private BuildHistoryManageBiz buildHistoryManageBiz;

    @Resource
    private JobOptManageBiz jobOptManageBiz;

    /**
     * 获取buildHistory列表
     * @param offset
     * @param limit
     * @param id
     * @return
     */
    @RequestMapping(path = "/list.json", method = RequestMethod.GET)
    public ApiResponse<Object> getBuildHistoryList(@RequestParam(name = "offset", required = false, defaultValue = "0") int offset,
                                                   @RequestParam(name = "limit", required = false, defaultValue = "10") int limit,
                                                   @RequestParam(name = "id", required = true) int id){
        log.info("getBuildHistoryList params offset = {}, limit = {}, jobid = {}", offset, limit, id);
        if (offset < 0) {
            return ApiResponse.buildFailure("起始页不能为负数");
        }
        if (limit < 1) {
            return ApiResponse.buildFailure("每页的数量必须大于0");
        }
        if (id < 0) {
            return ApiResponse.buildFailure(ErrorMessageConstant.JOB_CONFIG_ID_ERROR);
        }
        if (limit > PageingConstant.MAX_LIMIT) {
            log.info("请求的分页数>{}, 限制每页数量最大为{}", PageingConstant.MAX_LIMIT, PageingConstant.MAX_LIMIT);
            return buildHistoryManageBiz.getBuildHistoryListByJobId(offset, PageingConstant.MAX_LIMIT, id);
        }
        return buildHistoryManageBiz.getBuildHistoryListByJobId(offset, limit, id);
    }

    /**
     * 获取buildHistoryChart列表
     * @param id
     * @return
     */
    @RequestMapping(path = "/chartList.json", method = RequestMethod.GET)
    public ApiResponse<Object> getBuildHistoryChartList(@RequestParam(name = "id", required = true) int id){
        log.info("getBuildHistoryList params jobid = {}", id);
        if (id < 0) {
            return ApiResponse.buildFailure(ErrorMessageConstant.JOB_CONFIG_ID_ERROR);
        }
        return buildHistoryManageBiz.getBuildHistoryChartList(id);
    }

    /**
     * 获取指定buildId的jobInfo
     * @param id
     * @return
     */
    @RequestMapping(path = "/getJobInfoByBuildId.json", method = RequestMethod.GET)
    public ApiResponse<Object> getJobInfoByBuildId(@RequestParam(name = "id", required = true) int id) {
        log.info("getJobInfoByBuildId params --- id = {}", id);
        if (id < 1) {
            return ApiResponse.buildFailure(ErrorMessageConstant.BUILD_HISTORY_CONFIG_ID_ERROR);
        }
        return jobOptManageBiz.getBuildHistoryJobInfoById(id);
    }

    /**
     * 获取指定buildId的详情页
     * @param id
     * @return
     */
    @RequestMapping(path = "/getBuildHistoryDetail.json", method = RequestMethod.GET)
    public ApiResponse<Object> getBuildHistoryDetail(@RequestParam(name = "id", required = true) int id) {
        log.info("getBuildHistoryDetail params --- id = {}", id);
        if (id < 1) {
            return ApiResponse.buildFailure(ErrorMessageConstant.BUILD_HISTORY_CONFIG_ID_ERROR);
        }
        return buildHistoryManageBiz.getBuildHistoryDetailByBuildId(id);
    }


}
