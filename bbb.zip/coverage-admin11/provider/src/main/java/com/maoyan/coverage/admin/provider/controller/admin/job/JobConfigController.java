package com.maoyan.coverage.admin.provider.controller.admin.job;

import com.maoyan.coverage.admin.biz.jobmanage.JobOptManageBiz;
import com.maoyan.coverage.admin.common.exception.JenkinsException;
import com.maoyan.coverage.admin.common.utils.JenkinsUtils;
import com.maoyan.coverage.admin.domain.constant.ErrorMessageConstant;
import com.maoyan.coverage.admin.domain.constant.LengthConstant;
import com.maoyan.coverage.admin.domain.constant.PageingConstant;
import com.maoyan.coverage.admin.domain.enums.ProjectTypeEnum;
import com.maoyan.coverage.admin.domain.param.jobmanage.JobManageParam;
import com.meituan.mobile.movie.common.response.ApiResponse;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.bind.annotation.*;
import javax.annotation.Resource;
import java.util.Map;

/**
 * @author yimingyu
 * @date 2021/07/14
 */
@RestController
@RequestMapping("/api/admin/job")
@Slf4j
public class JobConfigController {

    @Resource
    private JobOptManageBiz jobOptManageBiz;

    /**
     * 添加job
     * @param jobManageParam
     * @param projectType
     * @param projectId
     * @return
     */
    @RequestMapping(path = "/add.json", method = RequestMethod.POST)
    public ApiResponse<Object> addJob(@RequestBody JobManageParam jobManageParam,
                                      @RequestParam(name = "projectType", required = true) int projectType,
                                      @RequestParam(name = "projectId", required = true) int projectId,
                                      @RequestParam(name = "jobType", required = false, defaultValue = "0") int jobType) {
        log.info("jobManage add job params --- projectType = {} projectId = {} jobType = {}", projectType, projectId, jobType);
        log.info("jobManage add job params --- jobAllConfigVO = {}", jobManageParam);
        if (projectId < 0) {
            return ApiResponse.buildFailure("项目Id错误,请确认后重试");
        }
        if (projectType < ProjectTypeEnum.PC.getId() || projectType > ProjectTypeEnum.MRN.getId()) {
            return ApiResponse.buildFailure("项目类型不正确");
        }
        if (StringUtils.isEmpty(jobManageParam.getJobName())) {
            return ApiResponse.buildFailure("job名不能为空");
        }
        if (jobManageParam.getReportType() < 0 || jobManageParam.getReportType() > 1) {
            return ApiResponse.buildFailure("报告类型不正确,请确认后重试");
        }
        if (StringUtils.isEmpty(jobManageParam.getCurrentBranch())) {
            return ApiResponse.buildFailure("当前被测分支不能为空");
        }
        if (0 == jobManageParam.getReportType() && StringUtils.isEmpty(jobManageParam.getOriginBranch())) {
            return ApiResponse.buildFailure("对比分支不能为空");
        }
        if (0 == jobManageParam.getReportType() && jobManageParam.getCurrentBranch().equals(jobManageParam.getOriginBranch())) {
            return ApiResponse.buildFailure("对比分支不能和被测分支相同");
        }
        if (jobManageParam.getThreshold() < 0 || jobManageParam.getThreshold() > 1) {
            return ApiResponse.buildFailure("阈值只能介于0到1之间");
        }
        if (jobManageParam.getJobName().length() > LengthConstant.JOB_NAME_MAX_LENGTH){
            return ApiResponse.buildFailure("job名超长，限制在" + LengthConstant.JOB_NAME_MAX_LENGTH + "个字符以内");
        }
        return jobOptManageBiz.addJob(projectId, projectType, jobType, jobManageParam);
    }

    /**
     * 获取job列表
     *
     * @param offset
     * @param limit
     * @param projectId
     * @return
     */
    @RequestMapping(path = "/list.json", method = RequestMethod.GET)
    public ApiResponse<Object> getJobList(@RequestParam(name = "offset", required = false, defaultValue = "0") int offset,
                                          @RequestParam(name = "limit", required = false, defaultValue = "10") int limit,
                                          @RequestParam(name = "projectId", required = true) int projectId,
                                          @RequestParam(name = "jobType", required = false, defaultValue = "0") int jobType) {
        log.info("get jobList params --- offset = {}, limit = {}", offset, limit);
        log.info("get jobList params --- projectId = {}", projectId);
        if (offset < 0) {
            return ApiResponse.buildFailure("起始页不能为负数");
        }
        if (limit < 1) {
            return ApiResponse.buildFailure("每页的数量必须大于0");
        }
        if (limit > PageingConstant.MAX_LIMIT) {
            log.info("请求的分页数>{}, 限制每页数量最大为{}", PageingConstant.MAX_LIMIT, PageingConstant.MAX_LIMIT);
            return jobOptManageBiz.getJobList(offset, PageingConstant.MAX_LIMIT, projectId, jobType);
        }
        return jobOptManageBiz.getJobList(offset, limit, projectId, jobType);
    }

    /**
     * 获取指定Id的job信息
     *
     * @param id
     * @return
     */
    @RequestMapping(path = "/getJobInfoById.json", method = RequestMethod.GET)
    public ApiResponse<Object> getJobInfoById(@RequestParam(name = "id", required = true) int id) {
        log.info("getJobInfoById params --- id = {}", id);
        if (id < 1) {
            return ApiResponse.buildFailure(ErrorMessageConstant.JOB_CONFIG_ID_ERROR);
        }
        return jobOptManageBiz.getJobInfoByJobId(id);
    }

    /**
     * 更新job信息
     * @param projectType
     * @param jobManageParam
     * @return
     */
    @RequestMapping(path = "/edit.json", method = RequestMethod.PUT)
    public ApiResponse<Object> updateJobInfo(@RequestParam(name = "projectType", required = true) int projectType,
                                             @RequestBody JobManageParam jobManageParam) {
        log.info("jobManage add job params --- projectType = {}", projectType);
        log.info("jobManage add job params --- jobAllConfigVO = {}", jobManageParam);
        if (StringUtils.isEmpty(jobManageParam.getJobName())) {
            return ApiResponse.buildFailure("job名不能为空");
        }
        if (jobManageParam.getId() < 1) {
            return ApiResponse.buildFailure(ErrorMessageConstant.JOB_CONFIG_ID_ERROR);
        }
        if (jobManageParam.getJobName().length() > LengthConstant.JOB_NAME_MAX_LENGTH){
            return ApiResponse.buildFailure("job名超长，限制在" + LengthConstant.JOB_NAME_MAX_LENGTH + "个字符以内");
        }
        return jobOptManageBiz.updateJobInfo(projectType, jobManageParam);
    }

    @RequestMapping(path = "/delete.json", method = RequestMethod.DELETE)
    public ApiResponse<Object> delJobById(@RequestParam(name = "id", required = true) int id) {
        if (id < 1) {
            return ApiResponse.buildFailure(ErrorMessageConstant.JOB_CONFIG_ID_ERROR);
        }
        return jobOptManageBiz.delJobById(id);
    }

    /**
     * 获取job详情页的头部信息
     * @param id
     * @return
     */
    @RequestMapping(path = "getJobDetailHeaderInfo.json", method = RequestMethod.GET)
    public ApiResponse<Object> getJobDetailHeaderInfo(@RequestParam(name = "id", required = true) int id){
        log.info("getJobHeaderInfo params --- id = {}", id);
        if (id < 1) {
            return ApiResponse.buildFailure(ErrorMessageConstant.JOB_CONFIG_ID_ERROR);
        }
        return jobOptManageBiz.getJobDetailHeaderInfo(id);
    }

    /**
     * 获取指定project中git的所有分支
     * @param projectId
     * @return
     */
    @GetMapping("getAllGitBranch.json")
    public ApiResponse<Object> getAllGitBranchByProjectId(@RequestParam(name="projectId", required = true) int projectId){
        log.info("getAllGitBranchByProjectId params --- projectId = {}", projectId);
        return jobOptManageBiz.getAllGitBranchByProjectId(projectId);
    }

    /**
     * 根据jenkinsRef获取jenkinsGitAddress和jenkinsGitBranch
     * @param jenkinsRef
     * @return
     */
    @RequestMapping(path = "/getAddressAndBranchByJenkinsRef.json", method = RequestMethod.GET)
    public ApiResponse<Object> getAddressAndBranchByJenkinsRef(@RequestParam(name="jenkinsRef", required = true) String jenkinsRef){
        log.info("getAddressAndBranchByJenkinsRef params --- jenkinsRef = {}", jenkinsRef);
        Map<String, String> data = null;
        try {
            data = JenkinsUtils.getJenkinsGitInfo(jenkinsRef);
        } catch (JenkinsException e){
            log.error(e.getMessage());
            return ApiResponse.buildFailure(e.getMessage());
        } catch (Exception e){
            log.error(e.getMessage());
            return ApiResponse.buildFailure("未知错误，请联系管理员!");
        }
        return ApiResponse.buildSuccess(data);
    }


}
