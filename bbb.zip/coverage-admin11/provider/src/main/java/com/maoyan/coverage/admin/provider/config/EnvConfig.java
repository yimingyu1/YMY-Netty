package com.maoyan.coverage.admin.provider.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * Create by songyu on 2019/4/28
 */
@Configuration
@ConfigurationProperties(prefix = "env")
public class EnvConfig {
    private String env;

    public String getEnv() {
        return env;
    }

    public void setEnv(String env) {
        this.env = env;
    }
}