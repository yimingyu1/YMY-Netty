package com.maoyan.coverage.admin.provider.config;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.S3ClientOptions;
import com.maoyan.coverage.admin.common.PropUtil;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class S3Client {

    private final String accessKey = PropUtil.getProperty("mss.accessKey");
    private final String secretKey = PropUtil.getProperty("mss.secretKey");
    private final String hostname = PropUtil.getProperty("mss.host");

    private final String prodAccessKey = PropUtil.getProperty("mss.prodAccessKey");
    private final String prodSecretKey = PropUtil.getProperty("mss.prodSecretKey");
    private final String prodHostname = PropUtil.getProperty("mss.prodHost");

    private final String envAccessKey = PropUtil.getProperty("env.mss.accessKey");
    private final String envSecretKey = PropUtil.getProperty("env.mss.secretKey");
    private final String envHostname = PropUtil.getProperty("env.mss.host");
    private final String envBucket = PropUtil.getProperty("env.mss.bucket");

    @Bean(name = "prodS3Client")
    public AmazonS3 prodClient() {
        S3ClientOptions s3ClientOptions = new S3ClientOptions();
        s3ClientOptions.setPathStyleAccess(true);

        AWSCredentials credentials = new BasicAWSCredentials(prodAccessKey, prodSecretKey);
        //生成云存储api client
        AmazonS3 s3ClientonPord = new AmazonS3Client(credentials);
        //配置云存储服务地址
        s3ClientonPord.setEndpoint(prodHostname);
        s3ClientonPord.setS3ClientOptions(s3ClientOptions);
        return s3ClientonPord;
    }

    @Bean(name = "testS3Client")
    public AmazonS3 testClient() {
        S3ClientOptions s3ClientOptions = new S3ClientOptions();
        s3ClientOptions.setPathStyleAccess(true);

        AWSCredentials credentials = new BasicAWSCredentials(accessKey, secretKey);
        //生成云存储api client
        AmazonS3 s3ClientonTest = new AmazonS3Client(credentials);
        //配置云存储服务地址
        s3ClientonTest.setEndpoint(hostname);
        s3ClientonTest.setS3ClientOptions(s3ClientOptions);
        return s3ClientonTest;
    }

    @Bean(name = "envS3Client")
    public AmazonS3 envS3Client() {
        S3ClientOptions s3ClientOptions = new S3ClientOptions();
        s3ClientOptions.setPathStyleAccess(true);

        AWSCredentials credentials = new BasicAWSCredentials(envAccessKey, envSecretKey);
        //生成云存储api client
        AmazonS3 s3ClientonTest = new AmazonS3Client(credentials);
        //配置云存储服务地址
        s3ClientonTest.setEndpoint(envHostname);
        s3ClientonTest.setS3ClientOptions(s3ClientOptions);
        return s3ClientonTest;
    }

}
