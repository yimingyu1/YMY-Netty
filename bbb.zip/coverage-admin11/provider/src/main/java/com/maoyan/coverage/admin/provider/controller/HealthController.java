package com.maoyan.coverage.admin.provider.controller;

import com.meituan.mobile.movie.common.response.ApiResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;

/**
 * @author liyebing created on 16/5/29.
 * @version $Id$
 */
@RestController
@RequestMapping("/service/")
public class HealthController {

    @RequestMapping(value = "alive", method = {RequestMethod.HEAD,RequestMethod.GET})
    public ApiResponse healthCheck() {
        return ApiResponse.buildSuccess();
    }

}
