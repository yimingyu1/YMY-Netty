package com.maoyan.coverage.admin.provider.controller.s3;

import com.maoyan.coverage.admin.biz.s3.S3Biz;
import com.maoyan.coverage.admin.domain.enums.CoverageTypeEnum;
import com.maoyan.coverage.admin.domain.enums.S3EnvEnum;
import com.maoyan.coverage.admin.domain.param.s3.S3UploadReportsReq;
import com.maoyan.coverage.admin.domain.param.s3.S3UploadDataReq;
import com.maoyan.coverage.admin.domain.vo.S3ObjectListVO;
import com.maoyan.coverage.admin.domain.vo.S3ObjectUrlVO;
import com.meituan.mobile.movie.common.response.ApiResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.util.List;

/**
 * Created by lihongmei03 on 2020-11-30
 */
@RestController
@RequestMapping("api/admin/coverage/S3")
public class S3Controller {
    public static final Logger LOGGER = LoggerFactory.getLogger(S3Controller.class);

    @Resource
    private S3Biz s3Biz;

    @RequestMapping(value = "/upload/data", method = RequestMethod.POST)
    public ApiResponse uploadData(@RequestBody S3UploadDataReq s3UploadDataReq) {
        try {
            if (s3UploadDataReq.getEmptyKey().size() != 0) {
                return ApiResponse.buildFailure("存在空值，以下值为空" + s3UploadDataReq.getEmptyKey().toString());
            }
            if (s3UploadDataReq.getEnv() == null) {
                s3UploadDataReq.setEnv("test");
            }
            LOGGER.info("testEnv: [{}] uploadData requests : {}", s3UploadDataReq.getEnv(), s3UploadDataReq.toString());
            boolean result = s3Biz.uploadObjectWithEnv(s3UploadDataReq);
            LOGGER.info("uploadData res : {}", result);
            if (result) {
                return ApiResponse.buildSuccess();
            } else {
                return ApiResponse.buildFailure("上传失败");
            }
        } catch (Exception e) {
            e.printStackTrace();
            return ApiResponse.buildFailure("系统异常");
        }
    }

    @RequestMapping(value = "/upload/maoyan/ios/gcda", method = RequestMethod.POST)
    public ApiResponse uploadIOSGcdaFile(HttpServletRequest request, HttpServletResponse response) {
        String tempGcdaZipPath = "./temp/ios/gcda/";
        CommonsMultipartResolver multipartResolver = new CommonsMultipartResolver(request.getSession().getServletContext());
        if (multipartResolver.isMultipart(request)) {
            MultipartHttpServletRequest multipartHttpServletRequest = (MultipartHttpServletRequest) request;
            MultipartFile gcdaFile = multipartHttpServletRequest.getFile("userFile");
            // 先将文件写入本地
            boolean uploadStatus = false;
            String version = request.getParameter("version");
            String buildNum = request.getParameter("buildNumber");
            String uuid = request.getParameter("uuid");
            String localTempGcdaZipPath = tempGcdaZipPath + version + "/" + buildNum + "/" + uuid + "/gcda/";
            File localTempGcdaZipPathFile = new File(localTempGcdaZipPath);
            if (!localTempGcdaZipPathFile.exists()) {
                boolean mkdirFlag = localTempGcdaZipPathFile.mkdirs();
            }
            String uploadFilePath = this.writeFileInLocal(localTempGcdaZipPath, gcdaFile);
            if (!uploadFilePath.equals("")) {
                // 先上传到 test 环境
                uploadStatus = s3Biz.uploadGcdaZipWithEnv(uploadFilePath, "movie", version, buildNum, uuid, CoverageTypeEnum.iOS.getType(), S3EnvEnum.TEST.getEnv());
            }
            if (uploadStatus) {
                return ApiResponse.buildSuccess();
            } else {
                return ApiResponse.buildFailure();
            }
        } else {
            LOGGER.error("上传文件不是 Multipart 格式");
            return ApiResponse.buildFailure();
        }
    }

    /**
     * iOS gcno.zip 上传
     */
    @RequestMapping(value = "/upload/maoyan/ios/gcno", method = RequestMethod.POST)
    public ApiResponse uploadIOSGcnoFile(HttpServletRequest request, HttpServletResponse response) {
        String tempGcdaZipPath = "./temp/ios/gcno/";
        CommonsMultipartResolver multipartResolver = new CommonsMultipartResolver(request.getSession().getServletContext());
        if (multipartResolver.isMultipart(request)) {
            MultipartHttpServletRequest multipartHttpServletRequest = (MultipartHttpServletRequest) request;
            MultipartFile gcdaFile = multipartHttpServletRequest.getFile("gcno");
            // 先将文件写入本地
            boolean uploadStatus = false;
            String version = request.getParameter("version");
            String buildNum = request.getParameter("buildNumber");
            String localTempGcdaZipPath = tempGcdaZipPath + version + "/" + buildNum + "/gcno/";
            File localTempGcdaZipPathFile = new File(localTempGcdaZipPath);
            if (!localTempGcdaZipPathFile.exists()) {
                boolean mkdirFlag = localTempGcdaZipPathFile.mkdirs();
            }
            String uploadFilePath = this.writeFileInLocal(localTempGcdaZipPath, gcdaFile);
            if (!uploadFilePath.equals("")) {
                // 先上传到 test 环境
                uploadStatus = s3Biz.uploadGcnoZipWithEnv(uploadFilePath, "movie", version, buildNum, CoverageTypeEnum.iOS.getType(), S3EnvEnum.TEST.getEnv());
            }
            if (uploadStatus) {
                return ApiResponse.buildSuccess();
            } else {
                return ApiResponse.buildFailure();
            }
        } else {
            LOGGER.error("上传文件不是 Multipart 格式");
            return ApiResponse.buildFailure();
        }
    }

    /**
     * iOS gcno.zip 上传
     */
    @RequestMapping(value = "/upload/maoyan/android/commit", method = RequestMethod.GET)
    public ApiResponse uploadAndroidCommitFile(@RequestParam String version, @RequestParam String applicationId,
                                               @RequestParam String variantName, @RequestParam String buildNum,
                                               @RequestParam String commit) {
        String tempCommitFilePath = "./temp/android/";
        File tempDir = new File(tempCommitFilePath);
        if (!tempDir.exists()) {
            tempDir.mkdirs();
        }
        // ./temp/android/${applicationId}-${version}-${buildNum}-commit
        String commitFilePath = tempCommitFilePath + applicationId + "-" + version + "-" + buildNum + "-commit";
        File commitFile = new File(commitFilePath);
        try {
            // 创建新文件
            commitFile.createNewFile();
            if (!commit.equals("")) {
                FileWriter fw = new FileWriter(commitFile, true);
                fw.write(commit);
                fw.flush();
                fw.close();
            }

            boolean uploadStatus = s3Biz.uploadCommitFileWithEnv(commitFilePath, applicationId, version, buildNum, variantName, S3EnvEnum.PROD.getEnv());
            if (uploadStatus) {
                return ApiResponse.buildSuccess();
            } else {
                return ApiResponse.buildFailure();
            }
        } catch (IOException e) {
            e.printStackTrace();
            return ApiResponse.buildFailure();
        }
    }

    /**
     * 安卓端 ec 文件上传
     */
    @RequestMapping(value = "/upload/file", method = RequestMethod.POST)
    public ApiResponse uploadFile(HttpServletRequest request, HttpServletResponse response) {
        String tempEcFilePath = "./temp/android/";
        File tempDir = new File(tempEcFilePath);
        if (!tempDir.exists()) {
            tempDir.mkdirs();
        }
        CommonsMultipartResolver multipartResolver = new CommonsMultipartResolver(request.getSession().getServletContext());
        if (multipartResolver.isMultipart(request)) {
            String version = request.getParameter("version");
            String applicationId = request.getParameter("applicationId");
            // 暂时没有使用
            String variantName = request.getParameter("variantName");
            String buildNum = request.getParameter("buildNum");
            if (buildNum == null) {
                LOGGER.warn("未上传buildNum，使用 undefined 作为版本");
                buildNum = "undefined";
            }

            MultipartHttpServletRequest multipartHttpServletRequest = (MultipartHttpServletRequest) request;
            MultipartFile ecFile = multipartHttpServletRequest.getFile("file");
            // 先将文件写入本地
            boolean uploadStatus = false;
            // 只获取第一个, 客户端每次上传都只上传一个文件
            try {
                int index;
                String uploadFilePath = tempEcFilePath + ecFile.getOriginalFilename();
                InputStream input = ecFile.getInputStream();
                byte[] ecFileBytes = new byte[ecFile.getBytes().length];
                File uploadFile = new File(uploadFilePath);
                if (!uploadFile.exists()) {
                    boolean isCreated = uploadFile.createNewFile();
                    if (!isCreated) {
                        LOGGER.error("创建文件失败");
                    }
                }
                FileOutputStream targetFile = new FileOutputStream(uploadFile);
                while ((index = input.read(ecFileBytes)) != -1) {
                    targetFile.write(ecFileBytes, 0, index);
                    targetFile.flush();
                }
                targetFile.close();
                input.close();

                uploadStatus = s3Biz.uploadEcFileWithEnv(uploadFilePath, applicationId, version, buildNum, variantName, S3EnvEnum.PROD.getEnv());
            } catch (Exception e) {
                LOGGER.error("文件保存到本地时失败, fileName 是 {}", ecFile.getOriginalFilename());
                e.printStackTrace();
            }
            if (uploadStatus) {
                return ApiResponse.buildSuccess();
            } else {
                return ApiResponse.buildFailure();
            }
        }
        LOGGER.error("上传文件不是 Multipart 格式");
        return ApiResponse.buildFailure();
    }

    /**
     * 安卓上传 src 和 class 压缩包
     */
    @RequestMapping(value = "/upload/maoyan/android/zip", method = RequestMethod.POST)
    public ApiResponse uploadAndroidZip(HttpServletRequest request, HttpServletResponse response) {

        CommonsMultipartResolver multipartResolver = new CommonsMultipartResolver(request.getSession().getServletContext());
        if (multipartResolver.isMultipart(request)) {
            String version = request.getParameter("version");
            String applicationId = request.getParameter("applicationId");
            // 暂时没有使用
            String variantName = request.getParameter("variantName");
            String buildNum = request.getParameter("buildNum");
            if (buildNum == null) {
                LOGGER.warn("未上传buildNum，使用 undefined 作为版本");
                buildNum = "undefined";
            }
            String fileType = request.getParameter("fileType");
            String tempZipPath = "./temp/android/" + version + "/" + buildNum + "/" + fileType + "/";
            File tempDir = new File(tempZipPath);
            if (!tempDir.exists()) {
                tempDir.mkdirs();
            }

            MultipartHttpServletRequest multipartHttpServletRequest = (MultipartHttpServletRequest) request;
            MultipartFile zip = multipartHttpServletRequest.getFile("file");
            // 先将文件写入本地
            boolean uploadStatus = false;

            String uploadFilePath = this.writeFileInLocal(tempZipPath, zip);
            if (!uploadFilePath.equals("")) {
                // 上传至线上S3
                uploadStatus = s3Biz.uploadSrcOrClassZipWithEnv(uploadFilePath, applicationId, version, buildNum, variantName, S3EnvEnum.PROD.getEnv(), fileType);
            }

            if (uploadStatus) {
                return ApiResponse.buildSuccess();
            } else {
                return ApiResponse.buildFailure();
            }
        }
        LOGGER.error("上传文件不是 Multipart 格式");
        return ApiResponse.buildFailure();
    }


    @RequestMapping(value = "/search", method = RequestMethod.GET)
    public ApiResponse getObjectList(@RequestParam("projectName") String projectName,
                                     @RequestParam("coverageType") int coverageType,
                                     @RequestParam("beginTime") String beginTime,
                                     @RequestParam("endTime") String endTime,
                                     @RequestParam("env") String env,
                                     @RequestParam(value = "projectVersion", required = false) String projectVersion) {
        try {
            S3ObjectListVO s3ObjectListVO = new S3ObjectListVO();
            LOGGER.info("getObjectList requests : projectName = {}, coverageType = {}, beginTime = {}, endTime = {}, projectVersion = {}, env = {}", projectName, coverageType, beginTime, endTime, projectVersion, env);
            List<String> objectList = s3Biz.getObjectListWithEnv(projectName, coverageType, beginTime, endTime, projectVersion, env);
            LOGGER.info("getObjectList response: objectList = {}", objectList);
            s3ObjectListVO.setObjectList(objectList);
            return ApiResponse.buildSuccess(s3ObjectListVO);
        } catch (Exception e) {
            return ApiResponse.buildFailure("系统异常");
        }
    }

    public String writeFileInLocal(String filePath, MultipartFile file) {
        String uploadFilePath = "";
        try {
            int index;
            uploadFilePath = filePath + file.getOriginalFilename();
            InputStream input = file.getInputStream();
            byte[] ecFileBytes = new byte[file.getBytes().length];
            File uploadFile = new File(uploadFilePath);
            if (!uploadFile.exists()) {
                boolean isCreated = uploadFile.createNewFile();
                if (!isCreated) {
                    LOGGER.error("创建文件失败");
                }
            }
            FileOutputStream targetFile = new FileOutputStream(uploadFile);
            while ((index = input.read(ecFileBytes)) != -1) {
                targetFile.write(ecFileBytes, 0, index);
                targetFile.flush();
            }
            targetFile.close();
            input.close();
            return uploadFilePath;
        } catch (Exception e) {
            LOGGER.error("文件保存到本地时失败, fileName 是 {}", file.getOriginalFilename());
            e.printStackTrace();
        }
        return uploadFilePath;
    }
}
