package com.maoyan.coverage.admin.provider.config;

import org.quartz.Scheduler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.quartz.SchedulerFactoryBean;

import java.util.Properties;

/**
 * @author lizhuoran05
 * @date 2021/7/9
 */
@Configuration
public class QuartzConfig {

    @Autowired
    JobFactoryConfig jobFactoryConfig;

    @Bean
    public SchedulerFactoryBean schedulerFactoryBean() {
        SchedulerFactoryBean schedulerFactoryBean = new SchedulerFactoryBean();
        schedulerFactoryBean.setJobFactory(jobFactoryConfig);
        Properties quartzProperties = new Properties();
        // 线程数量
        quartzProperties.setProperty("org.quartz.threadPool.threadCount", String.valueOf(50));
        schedulerFactoryBean.setQuartzProperties(quartzProperties);
        return schedulerFactoryBean;
    }

    @Bean
    public Scheduler scheduler() {
        return schedulerFactoryBean().getScheduler();
    }
}
