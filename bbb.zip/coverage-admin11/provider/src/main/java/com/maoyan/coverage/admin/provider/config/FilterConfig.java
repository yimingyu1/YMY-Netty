package com.maoyan.coverage.admin.provider.config;

import com.sankuai.it.sso.sdk.spring.FilterFactoryBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.filter.DelegatingFilterProxy;

import static javax.servlet.DispatcherType.REQUEST;

/**
 * @author lizhuoran05
 * @date 2021/7/8
 */
@Configuration
public class FilterConfig {

    @Autowired
    SSOConfig ssoConfig;

    @Autowired
    EnvConfig env;


    @Bean
    public FilterRegistrationBean mtFilter() {
        DelegatingFilterProxy filter = new DelegatingFilterProxy();
        FilterRegistrationBean registration = new FilterRegistrationBean();
        filter.setTargetBeanName("mtFilterBean");
        filter.setTargetFilterLifecycle(true);

        registration.setFilter(filter);
        registration.addUrlPatterns("/*");
        registration.setDispatcherTypes(REQUEST);
        registration.setName("mtFilter");
        registration.setOrder(1);
        return registration;
    }

    /**
     * mtFilter配置
     * 可在本地配置具体的值，每一配置的含义参考第三节
     */
    @Bean
    public FilterFactoryBean mtFilterBean() {
        FilterFactoryBean filterFactoryBean = new FilterFactoryBean();
        filterFactoryBean.setClientId(ssoConfig.getClientId());
        filterFactoryBean.setSecret(ssoConfig.getSecret());

        // <!--必须配置，dev、test、ppe对齐到SSO测试环境，staging和prod对齐到SSO线上环境-->
        filterFactoryBean.setAccessEnv(env.getEnv());

        //<!--必须配置，与includedUriList二者取其一，表示需要经过SSO过滤的uri，多个uri以','分割。两者都配置的情况下，includedUriList优先级更高 -->
        filterFactoryBean.setExcludedUriList("/service/**,/api/admin/coverage/S3/**,/api/job/**, /static/**, /chaoyueapi/**");

        return filterFactoryBean;
    }
}
