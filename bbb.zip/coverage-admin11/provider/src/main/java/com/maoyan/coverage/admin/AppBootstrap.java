package com.maoyan.coverage.admin;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.annotation.PropertySource;
import org.springframework.scheduling.annotation.EnableAsync;

/**
 * 应用启动类
 *
 * @author liyebing created on  15/9/14.
 * @version $Id$
 */
@SpringBootApplication
@PropertySource({
        "classpath:config/hlb-config.properties",
        "classpath:config/common.properties",
        "classpath:jenkinsConfig.properties"
})
@ComponentScan(basePackages = {
        "com.maoyan.coverage.admin.*"
})
@ImportResource(locations = {
        "classpath:applicationContext.xml"
})
public class AppBootstrap {

    private static final Logger LOGGER = LoggerFactory.getLogger(AppBootstrap.class);

    public static void main(String[] args) {
        LOGGER.info("Start to run AppBootstrap");
        ConfigurableApplicationContext context = SpringApplication.run(AppBootstrap.class, args);
    }

}



