package com.maoyan.coverage.admin.provider.config;

import com.offbytwo.jenkins.JenkinsServer;
import com.offbytwo.jenkins.client.JenkinsHttpClient;
import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import java.net.URI;
import java.net.URISyntaxException;

/**
 * @author yimingyu
 * @date 2021/11/09
 */
@Component
@ConfigurationProperties(prefix = "interfaceJenkins")
@Data
public class JenkinsConfig {

    private String jenkinsServerUri;
    private String jenkinsToken;
    private String jenkinsUser;


    @Bean
    public JenkinsServer jenkinsServer() throws URISyntaxException {
        return new JenkinsServer(new URI(jenkinsServerUri), jenkinsUser, jenkinsToken);
    }

}
