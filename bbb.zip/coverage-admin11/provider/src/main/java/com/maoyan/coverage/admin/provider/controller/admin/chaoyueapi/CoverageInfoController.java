package com.maoyan.coverage.admin.provider.controller.admin.chaoyueapi;

import com.maoyan.coverage.admin.biz.build.BuildHistoryManageBiz;
import com.maoyan.coverage.admin.biz.businessLine.BusinessLineManageBiz;
import com.maoyan.coverage.admin.biz.jobmanage.JobOptManageBiz;
import com.maoyan.coverage.admin.biz.projectmanage.ProjectOptManageBiz;
import com.meituan.mobile.movie.common.response.ApiResponse;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * @author yimingyu
 * @date 2021/10/27
 */
@RestController
@RequestMapping("/chaoyueapi/coverageInfo")
@Slf4j
public class CoverageInfoController {

    @Resource
    private BusinessLineManageBiz businessLineManageBiz;

    @Resource
    private ProjectOptManageBiz projectOptManageBiz;

    @Resource
    private JobOptManageBiz jobOptManageBiz;

    @Resource
    private BuildHistoryManageBiz buildHistoryManageBiz;

    /**
     * 获取所有的业务线id、业务线名
     * @return
     */
    @GetMapping(path = "/getBusinessLines.json")
    public ApiResponse<Object> getBusinessLines(){
        return businessLineManageBiz.getAllBusinessLines2ChaoYue();
    }

    /**
     * 获取指定业务线下所有的项目Id、项目名
     * @param businessLineId
     * @return
     */
    @GetMapping(path = "/getProjectsByBusinessLineId.json")
    public ApiResponse<Object> getProjectsByBusinessLineId(@RequestParam(name = "businessLineId") int businessLineId){
        log.info("coverageInfoController getProjectsByBusinessLineId id = {}", businessLineId);
        return projectOptManageBiz.getAllProject2ChaoYue(businessLineId);
    }

    /**
     * 获取指定项目下所有的jobId、job名
     * @param projectId
     * @return
     */
    @GetMapping(path = "/getJobInfosByProjectId.json")
    public ApiResponse<Object> getJobInfosByProjectId(@RequestParam(name = "projectId") int projectId){
        log.info("coverageInfoController getJobInfosByProjectId id = {}", projectId);
        return jobOptManageBiz.getAllJobByProjectId2ChaoYue(projectId);
    }

    /**
     * 获取指定job中的所有构建历史
     * @param offset
     * @param limit
     * @param jobId
     * @return
     */
    @GetMapping(path = "/getBuildHistoriesByJobId.json")
    public ApiResponse<Object> getBuildHistoriesByJobId(@RequestParam(name = "offset", defaultValue = "0", required = false) int offset,
                                                        @RequestParam(name = "limit", defaultValue = "10", required = false) int limit,
                                                        @RequestParam(name = "jobId") int jobId){
        log.info("coverageInfoController getBuildHistoriesByJobId offset = {}, limit = {}, jobId = {}", offset, limit, jobId);
        return buildHistoryManageBiz.getBuildHistoryListByJobId(offset, limit, jobId);
    }
    
}
