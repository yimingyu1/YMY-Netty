package com.maoyan.coverage.admin.provider.controller.admin.businessline;

import com.maoyan.coverage.admin.biz.businessLine.BusinessLineManageBiz;
import com.maoyan.coverage.admin.domain.constant.LengthConstant;
import com.maoyan.coverage.admin.domain.constant.PageingConstant;
import com.maoyan.coverage.admin.domain.constant.ErrorMessageConstant;
import com.maoyan.coverage.admin.domain.param.businessLine.BusinessLineParam;
import com.meituan.mobile.movie.common.response.ApiResponse;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.bind.annotation.*;
import javax.annotation.Resource;
import java.util.Map;

@RestController
@RequestMapping("/api/admin/businessLine")
@Slf4j
public class BusinessLineController {

    @Resource
    private BusinessLineManageBiz businessLineManageBiz;

    /**
     * 添加业务线
     *
     * @param
     * @return
     */
    @RequestMapping(path = "/add.json", method = RequestMethod.POST)
    public ApiResponse<Object> createBusinessLine(@RequestBody BusinessLineParam businessLineParam
    ) {
        log.info("create businessLine params --- businessLineName = {}", businessLineParam);
        if (businessLineParam.getBusinessLineName().length() > LengthConstant.BUSINESS_LINE_MAX_LENGTH){
            return ApiResponse.buildFailure("业务线名超长，限制在"+LengthConstant.BUSINESS_LINE_MAX_LENGTH+"个字符内");
        }
        if (!StringUtils.isEmpty(businessLineParam.getBusinessLineName())) {
            return businessLineManageBiz.addBusinessLine(businessLineParam.getBusinessLineName());
        }
        return ApiResponse.buildFailure("业务线名不能为空");
    }

    /**
     * 获取业务线列表
     *
     * @param offset
     * @param limit
     * @return
     */
    @RequestMapping(path = "/list.json", method = RequestMethod.GET)
    public ApiResponse getBusinessLineList(@RequestParam(required = false, defaultValue = "0") int offset,
                                           @RequestParam(required = false, defaultValue = "10") int limit,
                                           @RequestParam(required = false, defaultValue = "false") boolean isAllBusinessLine) {
        log.info("get businessLineList params --- offset = {}, limit = {}", offset, limit);
        if (offset < 0) {
            return ApiResponse.buildFailure("起始页不能为负数");
        }
        if (limit < 1) {
            return ApiResponse.buildFailure("每页的数量必须大于0");
        }
        if (limit > PageingConstant.MAX_LIMIT) {
            log.info("请求的分页数>{}, 限制每页数量最大为{}", PageingConstant.MAX_LIMIT, PageingConstant.MAX_LIMIT);
            return businessLineManageBiz.getBusinessLineList(offset, PageingConstant.MAX_LIMIT, isAllBusinessLine);
        }
        return businessLineManageBiz.getBusinessLineList(offset, limit, isAllBusinessLine);
    }

    /**
     * 修改业务线名
     *
     * @param
     * @return
     */
    @RequestMapping(path = "/edit.json", method = RequestMethod.PUT)
    public Object updateBusinessLine(@RequestBody BusinessLineParam businessLineParam) {
        log.info("edit businessLine params --- {}", businessLineParam);
        if (StringUtils.isEmpty(businessLineParam.getBusinessLineName())) {
            return ApiResponse.buildFailure("新业务线名不能为空");
        }
        if (businessLineParam.getBusinessLineName().length() > LengthConstant.BUSINESS_LINE_MAX_LENGTH){
            return ApiResponse.buildFailure("业务线名超长，限制在"+LengthConstant.BUSINESS_LINE_MAX_LENGTH+"个字符内");
        }
        if (businessLineParam.getBusinessLineId() < 1) {
            return ApiResponse.buildFailure(ErrorMessageConstant.BUSINESS_LINE_ID_ERROR);
        }
        return businessLineManageBiz.updateBusinessLine(businessLineParam.getBusinessLineId(), businessLineParam.getBusinessLineName());
    }

    /**
     * 删除业务线
     *
     * @param businessLineId
     * @return
     */
    @RequestMapping(path = "/delete.json", method = RequestMethod.DELETE)
    public Object deleteBusinessLine(@RequestParam(required = true, name = "businessLineId") int businessLineId) {
        log.info("delete businessLine params --- businessLineId = {}", businessLineId);
        if (businessLineId < 1) {
            return ApiResponse.buildFailure(ErrorMessageConstant.BUSINESS_LINE_ID_ERROR);
        }
        return businessLineManageBiz.deleteBusinessLineById(businessLineId);

    }


}
