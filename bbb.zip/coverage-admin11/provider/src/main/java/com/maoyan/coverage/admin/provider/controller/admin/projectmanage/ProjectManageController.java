package com.maoyan.coverage.admin.provider.controller.admin.projectmanage;

import com.maoyan.coverage.admin.domain.constant.LengthConstant;
import com.maoyan.coverage.admin.domain.constant.PageingConstant;
import com.maoyan.coverage.admin.domain.constant.ErrorMessageConstant;
import com.maoyan.coverage.admin.domain.enums.ProjectTypeEnum;
import com.maoyan.coverage.admin.biz.projectmanage.ProjectOptManageBiz;
import com.maoyan.coverage.admin.domain.param.projectmanage.ProjectParam;
import com.meituan.mobile.movie.common.response.ApiResponse;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.bind.annotation.*;
import javax.annotation.Resource;
import java.util.regex.Pattern;

/**
 * @author yimingyu
 * @date 2021/07/14
 */
@RestController
@RequestMapping("/api/admin/projectManage")
@Slf4j
public class ProjectManageController {


    @Resource
    private ProjectOptManageBiz projectOptManageBiz;

    @RequestMapping(path = "/add.json", method = RequestMethod.POST)
    public Object addProject(@RequestBody ProjectParam projectParam) {

        log.info("add project params --- projectManageModel = {}", projectParam);

        if (projectParam.getBusinessLineId() < 0) {
            return ApiResponse.buildFailure(ErrorMessageConstant.BUSINESS_LINE_ID_ERROR);
        }
        if (StringUtils.isEmpty(projectParam.getProjectName())) {
            return ApiResponse.buildFailure("项目名不能为空");
        }
        if (StringUtils.isEmpty(projectParam.getGitAddress())) {
            return ApiResponse.buildFailure("git地址不能为空");
        }
        boolean matches = Pattern.matches("^ssh://git@git\\.sankuai\\.com.*\\.git$", projectParam.getGitAddress());
        if (!matches) {
            return ApiResponse.buildFailure("git地址格式不正确");
        }
        if (projectParam.getProjectType() < ProjectTypeEnum.PC.getId() ||
                projectParam.getProjectType() > ProjectTypeEnum.MRN.getId()) {
            return ApiResponse.buildFailure("项目类型不正确");
        }
        if (projectParam.getProjectLeader().size() == 0) {
            return ApiResponse.buildFailure("项目负责人不能为空");
        }
        if (projectParam.getProjectName().length() > LengthConstant.PROJECT_NAME_MAX_LENGTH){
            return ApiResponse.buildFailure("项目名超长，限制在"+ LengthConstant.PROJECT_NAME_MAX_LENGTH + "字符以内");
        }
        if (projectParam.getProjectLeader().size() > LengthConstant.PROJECT_LEADER_MAX_LENGTH){
            return ApiResponse.buildFailure("项目负责人已达到上线，最多"+ LengthConstant.PROJECT_LEADER_MAX_LENGTH + "个, 请调整后重试");
        }
        if (projectParam.getGitAddress().length() > LengthConstant.PROJECT_REPOSITORY_ADDRESS_MAX_LENGTH){
            return ApiResponse.buildFailure("项目地址超长，限制在"+ LengthConstant.PROJECT_REPOSITORY_ADDRESS_MAX_LENGTH + "字符以内");
        }
        return projectOptManageBiz.addProject(projectParam);

    }

    /**
     * 获取项目列表
     *
     * @param offset
     * @param limit
     * @return
     */
    @RequestMapping(path = "/list.json", method = RequestMethod.GET)
    public Object getProjectList(@RequestParam(required = false, name = "offset", defaultValue = "0") int offset,
                                 @RequestParam(required = false, name = "limit", defaultValue = "10") int limit,
                                 @RequestParam(required = true, name = "businessLineId") int businessLineId,
                                 @RequestParam(required = false, name = "projectType", defaultValue = "0") int projectType) {
        log.info("get projectManageList params --- offset = {}, limit = {}", offset, limit);
        log.info("get projectManageList params --- businessLineId = {}, projectType = {}", businessLineId, projectType);
        if (offset < 0) {
            return ApiResponse.buildFailure("起始页不能为负数");
        }
        if (limit < 1) {
            return ApiResponse.buildFailure("每页的数量必须大于0");
        }
        if (businessLineId < 0) {
            return ApiResponse.buildFailure(ErrorMessageConstant.BUSINESS_LINE_ID_ERROR);
        }
        if (limit > PageingConstant.MAX_LIMIT) {
            log.info("请求的分页数>{}, 限制每页数量最大为{}", PageingConstant.MAX_LIMIT, PageingConstant.MAX_LIMIT);
            return projectOptManageBiz.getProjectList(businessLineId, offset, PageingConstant.MAX_LIMIT, projectType);
        }
        return projectOptManageBiz.getProjectList(businessLineId, offset, limit, projectType);
    }

    /**
     * 获取指定Id的项目信息
     *
     * @param id
     * @return
     */
    @RequestMapping(path = "/getProjectInfoById.json", method = RequestMethod.GET)
    public Object getProjectInfoById(@RequestParam(name = "id", required = true) int id) {
        log.info("getProjectInfoById params --- id = {}", id);
        if (id < 0) {
            return ApiResponse.buildFailure("项目Id错误,请确认后重试");
        }
        return projectOptManageBiz.getProjectInfoById(id);
    }

    /**
     * 更新项目信息
     * @param projectParam
     * @return
     */
    @RequestMapping(path = "/edit.json", method = RequestMethod.PUT)
    public Object updateProject(@RequestBody ProjectParam projectParam) {
        log.info("edit project params --- projectManageModel = {}", projectParam);
        if (projectParam.getBusinessLineId() < 0) {
            return ApiResponse.buildFailure(ErrorMessageConstant.BUSINESS_LINE_ID_ERROR);
        }
        if (StringUtils.isEmpty(projectParam.getProjectName())) {
            return ApiResponse.buildFailure("项目名不能为空");
        }
        if (StringUtils.isEmpty(projectParam.getGitAddress())) {
            return ApiResponse.buildFailure("git地址不能为空");
        }
        boolean matches = Pattern.matches("^ssh://git@git\\.sankuai\\.com.*\\.git$", projectParam.getGitAddress());
        if (!matches) {
            return ApiResponse.buildFailure("git地址格式不正确");
        }
        if (projectParam.getProjectType() < ProjectTypeEnum.PC.getId() ||
                projectParam.getProjectType() > ProjectTypeEnum.MRN.getId()) {
            return ApiResponse.buildFailure("项目类型不正确");
        }
        if (projectParam.getProjectLeader().size() == 0) {
            return ApiResponse.buildFailure("项目负责人不能为空");
        }
        if (projectParam.getProjectName().length() > LengthConstant.PROJECT_NAME_MAX_LENGTH){
            return ApiResponse.buildFailure("项目名超长，限制在"+ LengthConstant.PROJECT_NAME_MAX_LENGTH + "字符以内");
        }
        if (projectParam.getProjectLeader().size() > LengthConstant.PROJECT_LEADER_MAX_LENGTH){
            return ApiResponse.buildFailure("项目负责人已达到上线，最多"+ LengthConstant.PROJECT_LEADER_MAX_LENGTH + "个, 请调整后重试");
        }
        if (projectParam.getGitAddress().length() > LengthConstant.PROJECT_REPOSITORY_ADDRESS_MAX_LENGTH){
            return ApiResponse.buildFailure("项目地址超长，限制在"+ LengthConstant.PROJECT_REPOSITORY_ADDRESS_MAX_LENGTH + "字符以内");
        }
        return projectOptManageBiz.editProjectInfo(projectParam);
    }

    /**
     * 删除project
     * @param projectId
     * @return
     */
    @DeleteMapping(path = "/delete.json")
    public Object delProjectById(@RequestParam("projectId") int projectId){
        log.info("delProjectInfoById params --- id = {}", projectId);
        if (projectId < 0) {
            return ApiResponse.buildFailure("项目Id错误,请确认后重试");
        }
        return projectOptManageBiz.delProject(projectId);
    }

}
