package com.maoyan.coverage.admin.service.projectmanage;

import com.maoyan.coverage.admin.domain.model.job.ProjectInfoModel;
import com.maoyan.coverage.admin.domain.model.projectmanage.ProjectManageModel;
import com.maoyan.coverage.admin.domain.schema.projectmanage.ProjectManageDO;

import java.util.List;
import java.util.Map;

/**
 * @author yimingyu
 * @date 2021/07/22
 */
public interface IProjectManageService {


    List<ProjectManageModel> getProjectManageDOListByBusinessLineId(int businessLineId);

    int insertProjectManage (ProjectManageModel projectManageModel);

    int updateProjectManage (ProjectManageModel projectManageModel);

    int deleteProjectManage (Map<String, Object> delProjectMap);

    List<ProjectManageModel> getProjectManageByName(String projectManageName);

    ProjectManageModel getProjectManageById(int id);

    List<ProjectManageModel> getAllProjectManages(int businessLineId);

    List<ProjectManageModel> getProjectManageList(int businessLineId, int offset, int limit);

    List<ProjectManageModel> getAllProjectManagesWithType(int businessLineId, int projectType);

    List<ProjectManageModel> getProjectManageListWithType(int businessLineId, int offset, int limit, int projectType);

    ProjectInfoModel getProjectInfoModelByProjectId(int id);

    ProjectManageModel getSameProjectManageModel(int businessLineId, String projectName, String repositoryAddress,
                                                  String projectLeader, int type);
}
