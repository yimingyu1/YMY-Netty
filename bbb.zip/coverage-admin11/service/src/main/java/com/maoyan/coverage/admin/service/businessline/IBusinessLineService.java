package com.maoyan.coverage.admin.service.businessline;

import com.maoyan.coverage.admin.domain.model.businessline.BusinessLineModel;

import java.util.List;

/**
 * @author yimingyu
 * @date 2021/07/19
 */
public interface IBusinessLineService {

    int insetBusinessLine(BusinessLineModel businessLine);

    List<BusinessLineModel> getBusinessLineList(int offset, int limit);

    int updateBusinessLine(BusinessLineModel businessLine);

    int delBusinessLineById(BusinessLineModel businessLine);

    List<BusinessLineModel> getAllBusinessLines();

    BusinessLineModel getBusinessLineByName(String businessLineName);

    BusinessLineModel getBusinessLineById(int businessLineId);
}
