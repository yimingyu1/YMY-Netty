package com.maoyan.coverage.admin.service.projectmanage.impl;

import com.maoyan.coverage.admin.dao.projectmanage.read.IProjectManageDAO;
import com.maoyan.coverage.admin.dao.projectmanage.write.IWriteProjectManageDAO;
import com.maoyan.coverage.admin.domain.model.job.ProjectInfoModel;
import com.maoyan.coverage.admin.domain.model.projectmanage.ProjectManageModel;
import com.maoyan.coverage.admin.domain.schema.projectmanage.ProjectManageDO;
import com.maoyan.coverage.admin.service.projectmanage.IProjectManageService;
import com.maoyan.coverage.admin.service.projectmanage.ProjectManageConverter;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

/**
 * @author yimingyu
 * @date 2021/07/22
 */
@Service
public class ProjectManageServiceImpl implements IProjectManageService {

    @Resource
    private IProjectManageDAO projectManageDAO;

    @Resource
    private IWriteProjectManageDAO writeProjectManageDAO;

    @Override
    public List<ProjectManageModel> getProjectManageDOListByBusinessLineId(int businessLineId) {
        List<ProjectManageDO> projectManageDOListByBusinessLineId = projectManageDAO.getProjectManageDOListByBusinessLineId(businessLineId);
        return ProjectManageConverter.converter2ProjectManageModelBatch(projectManageDOListByBusinessLineId);
    }

    @Override
    public int insertProjectManage(ProjectManageModel projectManageModel) {
        return writeProjectManageDAO.insertProject(ProjectManageConverter.converter2ProjectManageDO(projectManageModel));
    }

    @Override
    public int updateProjectManage(ProjectManageModel projectManageModel) {
        return writeProjectManageDAO.updateProject(ProjectManageConverter.converter2ProjectManageDO(projectManageModel));
    }

    @Override
    public List<ProjectManageModel> getProjectManageByName(String projectManageName) {
        List<ProjectManageDO> projectMangeByName = projectManageDAO.getProjectMangeByName(projectManageName);
        return ProjectManageConverter.converter2ProjectManageModelBatch(projectMangeByName);
    }

    @Override
    public ProjectManageModel getProjectManageById(int id) {
        ProjectManageDO projectMangeById = projectManageDAO.getProjectMangeById(id);
        return ProjectManageConverter.converter2ProjectManageModel(projectMangeById);
    }

    @Override
    public int deleteProjectManage(Map<String, Object> delProjectMap) {
        return writeProjectManageDAO.deleteProject(delProjectMap);
    }

    @Override
    public List<ProjectManageModel> getAllProjectManages(int businessLineId) {
        List<ProjectManageDO> allProjectManages = projectManageDAO.getAllProjectManages(businessLineId);
        return ProjectManageConverter.converter2ProjectManageModelBatch(allProjectManages);
    }

    @Override
    public List<ProjectManageModel> getProjectManageList(int businessLineId, int offset, int limit) {
        List<ProjectManageDO> projectManageList = projectManageDAO.getProjectManageList(businessLineId, offset, limit);
        return ProjectManageConverter.converter2ProjectManageModelBatch(projectManageList);
    }

    @Override
    public List<ProjectManageModel> getAllProjectManagesWithType(int businessLineId, int projectType) {
        List<ProjectManageDO> allProjectManagesWithType = projectManageDAO.getAllProjectManagesWithType(businessLineId, projectType);
        return ProjectManageConverter.converter2ProjectManageModelBatch(allProjectManagesWithType);
    }

    @Override
    public List<ProjectManageModel> getProjectManageListWithType(int businessLineId, int offset, int limit, int projectType) {
        List<ProjectManageDO> projectManageListWithType = projectManageDAO.getProjectManageListWithType(businessLineId, offset, limit, projectType);
        return ProjectManageConverter.converter2ProjectManageModelBatch(projectManageListWithType);
    }

    @Override
    public ProjectInfoModel getProjectInfoModelByProjectId(int id) {
        ProjectManageDO projectManageDO = projectManageDAO.getProjectMangeById(id);
        return ProjectManageConverter.converterToProjectInfoModel(projectManageDO);
    }

    @Override
    public ProjectManageModel getSameProjectManageModel(int businessLineId, String projectName, String repositoryAddress, String projectLeader, int type) {
        ProjectManageDO projectManageDO = projectManageDAO.getSameProjectManageDOByModel(businessLineId, projectName, repositoryAddress, projectLeader, type);
        return ProjectManageConverter.converter2ProjectManageModel(projectManageDO);
    }
}
