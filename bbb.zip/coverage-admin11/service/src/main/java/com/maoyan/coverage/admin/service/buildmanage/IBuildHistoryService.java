package com.maoyan.coverage.admin.service.buildmanage;

import com.maoyan.coverage.admin.domain.model.buildhistory.BuildHistoryChartModel;
import com.maoyan.coverage.admin.domain.model.buildhistory.BuildHistoryListModel;
import com.maoyan.coverage.admin.domain.model.jobmanage.BuildHistoryModel;
import com.maoyan.coverage.admin.domain.schema.buildHistory.BuildHistoryDO;

import java.util.List;

/**
 * @author yimingyu
 * @date 2021/07/29
 */
public interface IBuildHistoryService {

    int insert(BuildHistoryDO buildHistoryDO);

    List<BuildHistoryListModel> getBuildHistoryListByJobId(int jobId);

    List<BuildHistoryChartModel> getBuildHistoryChartListByJobId(int jobId);

    List<BuildHistoryListModel> getBuildHistoryPageListByJobId(int offset, int limit, int jobId);

    BuildHistoryChartModel getNewestBuildHistoryByJobId(int jobId);

    BuildHistoryChartModel getBuildHistoryByBuildId(int buildId);

    BuildHistoryModel getBuildHistoryModelById(int buildHistoryId);

    int update(BuildHistoryModel buildHistoryDO);

    int updateJenkinsBuildNum(int buildId, int jenkinsBuildNum);
}
