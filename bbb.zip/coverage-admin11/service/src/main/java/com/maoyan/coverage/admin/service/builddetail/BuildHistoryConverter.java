package com.maoyan.coverage.admin.service.builddetail;

import com.alibaba.fastjson.JSONObject;
import com.maoyan.coverage.admin.domain.model.buildhistory.BuildHistoryDetailModel;
import com.maoyan.coverage.admin.domain.model.data.DataIndicatorsModel;
import com.maoyan.coverage.admin.domain.schema.buildHistory.BuildHistoryDetailDO;

/**
 * @author yimingyu
 * @date 2021/07/30
 */
public class BuildHistoryConverter {

    public static BuildHistoryDetailModel converter2BuildHistoryDetailModel(BuildHistoryDetailDO buildHistoryDetailDO){
        if (buildHistoryDetailDO == null){
            return null;
        }
        BuildHistoryDetailModel buildHistoryDetailModel = new BuildHistoryDetailModel();
        buildHistoryDetailModel.setBuildId(buildHistoryDetailDO.getBuildHistoryId());
        buildHistoryDetailModel.setDataIndicatorsModels(JSONObject.parseArray(buildHistoryDetailDO.getDataIndicators(), DataIndicatorsModel.class));
        buildHistoryDetailModel.setReportDetailUrl(buildHistoryDetailDO.getReportDetailUrl());
        return buildHistoryDetailModel;
    }
}
