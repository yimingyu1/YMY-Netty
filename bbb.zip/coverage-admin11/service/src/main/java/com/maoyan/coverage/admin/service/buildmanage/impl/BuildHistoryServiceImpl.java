package com.maoyan.coverage.admin.service.buildmanage.impl;

import com.maoyan.coverage.admin.dao.buildmanage.read.IBuildHistoryDAO;
import com.maoyan.coverage.admin.dao.jobmanage.write.IWriteJobBuildHistoryDAO;
import com.maoyan.coverage.admin.domain.model.buildhistory.BuildHistoryChartModel;
import com.maoyan.coverage.admin.domain.model.buildhistory.BuildHistoryListModel;
import com.maoyan.coverage.admin.domain.model.jobmanage.BuildHistoryModel;
import com.maoyan.coverage.admin.domain.schema.buildHistory.BuildHistoryDO;
import com.maoyan.coverage.admin.service.buildmanage.BuildHistoryConverter;
import com.maoyan.coverage.admin.service.buildmanage.IBuildHistoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author yimingyu
 * @date 2021/07/29
 */
@Service
public class BuildHistoryServiceImpl implements IBuildHistoryService {

    @Resource
    private IBuildHistoryDAO buildHistoryDAO;

    @Autowired
    IWriteJobBuildHistoryDAO iWriteJobBuildHistoryDAO;

    @Override
    public int insert(BuildHistoryDO buildHistoryDO) {
        return iWriteJobBuildHistoryDAO.insert(buildHistoryDO);
    }

    @Override
    public List<BuildHistoryListModel> getBuildHistoryListByJobId(int jobId) {
        List<BuildHistoryDO> buildHistoryByJobId = buildHistoryDAO.getBuildHistoryListByJobId(jobId);
        return BuildHistoryConverter.converter2BuildHistoryModelList(buildHistoryByJobId);
    }

    @Override
    public List<BuildHistoryChartModel> getBuildHistoryChartListByJobId(int jobId) {
        List<BuildHistoryDO> buildHistoryByJobId = buildHistoryDAO.getBuildHistoryListByJobId(jobId);
        return BuildHistoryConverter.converter2BuildHistoryChartModelList(buildHistoryByJobId);
    }

    @Override
    public List<BuildHistoryListModel> getBuildHistoryPageListByJobId(int offset, int limit, int jobId) {
        List<BuildHistoryDO> buildHistoryByJobId = buildHistoryDAO.getBuildHistoryPageListByJobId(offset, limit, jobId);
        return BuildHistoryConverter.converter2BuildHistoryModelList(buildHistoryByJobId);
    }

    @Override
    public BuildHistoryChartModel getNewestBuildHistoryByJobId(int jobId) {
        BuildHistoryDO newestBuildHistory = buildHistoryDAO.getNewestBuildHistoryByJobId(jobId);
        return BuildHistoryConverter.converter2BuildHistoryChartModel(newestBuildHistory);
    }

    @Override
    public BuildHistoryChartModel getBuildHistoryByBuildId(int buildId) {
        BuildHistoryDO buildHistoryByBuildId = buildHistoryDAO.getBuildHistoryByBuildId(buildId);
        return BuildHistoryConverter.converter2BuildHistoryChartModel(buildHistoryByBuildId);
    }

    @Override
    public BuildHistoryModel getBuildHistoryModelById(int buildHistoryId) {
        // DO -> Model
        return BuildHistoryConverter.converterToBuildHistoryModel(buildHistoryDAO.getBuildHistoryByBuildId(buildHistoryId));
    }

    @Override
    public int update(BuildHistoryModel buildHistoryModel) {
        // Model -> DO
        BuildHistoryDO buildHistoryDO = new BuildHistoryDO();
        buildHistoryDO.setId(buildHistoryModel.getId());
        buildHistoryDO.setJobBuildConfig(buildHistoryModel.getJobBuildConfig());
        buildHistoryDO.setBuildNum(buildHistoryModel.getBuildNum());
        buildHistoryDO.setBuildResult(buildHistoryModel.getBuildResult());
        buildHistoryDO.setBuildStatus(buildHistoryModel.getBuildStatus());
        buildHistoryDO.setBranchesCovered(buildHistoryModel.getBranchesCovered());
        buildHistoryDO.setBranches(buildHistoryModel.getBranches());
        buildHistoryDO.setLinesCovered(buildHistoryModel.getLinesCovered());
        buildHistoryDO.setLineNum(buildHistoryModel.getLineNum());
        buildHistoryDO.setCommit(buildHistoryModel.getCommit());
        buildHistoryDO.setStartTime(buildHistoryModel.getStartTime());
        buildHistoryDO.setEndTime(buildHistoryModel.getEndTime());
        buildHistoryDO.setBuildType(buildHistoryModel.getBuildType());
        buildHistoryDO.setBuilder(buildHistoryModel.getBuilder());
        buildHistoryDO.setBuildResult(buildHistoryModel.getBuildResult());
        buildHistoryDO.setJobConfigId(buildHistoryModel.getJobConfigId());
        return iWriteJobBuildHistoryDAO.update(buildHistoryDO);
    }

    @Override
    public int updateJenkinsBuildNum(int buildId, int jenkinsBuildNum) {
        return iWriteJobBuildHistoryDAO.updateJenkinsBuildNum(buildId, jenkinsBuildNum);
    }
}
