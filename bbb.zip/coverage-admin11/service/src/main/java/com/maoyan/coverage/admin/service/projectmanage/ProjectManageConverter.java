package com.maoyan.coverage.admin.service.projectmanage;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.maoyan.coverage.admin.common.utils.ShellUtils;
import com.maoyan.coverage.admin.domain.enums.ProjectTypeEnum;
import com.maoyan.coverage.admin.domain.model.job.ProjectInfoModel;
import com.maoyan.coverage.admin.domain.model.projectmanage.ProjectManageModel;
import com.maoyan.coverage.admin.domain.schema.projectmanage.ProjectManageDO;

import java.util.ArrayList;
import java.util.List;

/**
 * @author yimingyu
 * @date 2021/07/29
 */
public class ProjectManageConverter {

    public static ProjectManageModel converter2ProjectManageModel(ProjectManageDO projectManageDO) {
        if (projectManageDO == null) {
            return null;
        }
        ProjectManageModel projectManageModel = new ProjectManageModel();
        projectManageModel.setId(projectManageDO.getId());
        projectManageModel.setBusinessLineId(projectManageDO.getBusinessLineId());
        projectManageModel.setProjectName(projectManageDO.getProjectName());
        projectManageModel.setGitAddress(projectManageDO.getRepositoryAddress());
        projectManageModel.setProjectType(projectManageDO.getType());
        projectManageModel.setProjectLeader(JSONObject.parseArray(projectManageDO.getProjectLeader(), String.class));
        projectManageModel.setCreator(projectManageDO.getCreator());
        projectManageModel.setUpdater(projectManageDO.getUpdater());
        projectManageModel.setDeleted(projectManageDO.getDeleted());
        projectManageModel.setCreateTime(projectManageDO.getCreateTime());
        projectManageModel.setUpdateTime(projectManageDO.getUpdateTime());
        return projectManageModel;
    }

    public static List<ProjectManageModel> converter2ProjectManageModelBatch(List<ProjectManageDO> projectManageDOS) {
        List<ProjectManageModel> list = new ArrayList<>();
        if (projectManageDOS.size() == 0) {
            return list;
        }
        for (ProjectManageDO pmd : projectManageDOS
        ) {
            list.add(converter2ProjectManageModel(pmd));
        }
        return list;
    }

    public static ProjectManageDO converter2ProjectManageDO(ProjectManageModel projectManageModel) {
        if (projectManageModel == null) {
            return null;
        }
        ProjectManageDO projectManageDO = new ProjectManageDO();
        projectManageDO.setId(projectManageModel.getId());
        projectManageDO.setBusinessLineId(projectManageModel.getBusinessLineId());
        projectManageDO.setProjectName(projectManageModel.getProjectName());
        projectManageDO.setRepositoryAddress(projectManageModel.getGitAddress());
        projectManageDO.setType(projectManageModel.getProjectType());
        projectManageDO.setProjectLeader(JSONObject.toJSONString(projectManageModel.getProjectLeader()));
        projectManageDO.setCreator(projectManageModel.getCreator());
        projectManageDO.setUpdater(projectManageModel.getUpdater());
        projectManageDO.setDeleted(projectManageModel.getDeleted());
        projectManageDO.setCreateTime(projectManageModel.getCreateTime());
        projectManageDO.setUpdateTime(projectManageModel.getUpdateTime());
        return projectManageDO;
    }

    public static ProjectInfoModel converterToProjectInfoModel(ProjectManageDO projectManageDO) {
        ProjectInfoModel projectInfoModel = new ProjectInfoModel();
        projectInfoModel.setGitAddress(projectManageDO.getRepositoryAddress());
        JSONArray jsonArray = JSONArray.parseArray(projectManageDO.getProjectLeader());
        projectInfoModel.setProjectLeader(jsonArray.toJavaList(String.class));
        // 设置仓库名称
        projectInfoModel.setRepositoryName(ShellUtils.getRepositoryName(projectManageDO.getRepositoryAddress()));
        // 设置项目类型
        projectInfoModel.setProjectType(ProjectTypeEnum.typeMap.get(projectManageDO.getType()));
        return projectInfoModel;
    }
}
