package com.maoyan.coverage.admin.service.jobtimer;

import com.maoyan.coverage.admin.domain.model.JobTimerModel;
import com.maoyan.coverage.admin.domain.model.TimerConfigModel;
import com.maoyan.coverage.admin.domain.schema.JobTimerDO;

import java.util.List;

/**
 * @author lizhuoran05
 * @date 2021/7/20
 */
public interface JobTimerService {

    int insert(JobTimerModel jobTimerDO);

    int updateByJobConfigIdAndType(JobTimerModel jobTimerModel);

    JobTimerModel getJobTimerModelByJobConfigId(int jobConfigId);

    int deleteById(int id);

    List<JobTimerModel> getJobTimerModelsByClosed(int closed);

    List<JobTimerModel> getJobTimerModelsByJobConfigIdAndClosed(int jobConfigId, int closed);

    JobTimerModel getJobTimerModelByJobConfigIdAndType(int jobConfigId, int type);

    JobTimerModel getByJobConfigIdAndTypeAndClosed(int jobConfigId, int type, int closed);
}
