package com.maoyan.coverage.admin.service.buildmanage;

import com.alibaba.fastjson.JSONObject;
import com.dianping.cat.util.json.JsonObject;
import com.maoyan.coverage.admin.domain.model.buildhistory.BuildHistoryChartModel;
import com.maoyan.coverage.admin.domain.model.buildhistory.BuildHistoryListModel;
import com.maoyan.coverage.admin.domain.model.jobmanage.BuildHistoryModel;
import com.maoyan.coverage.admin.domain.model.jobmanage.JobManageModel;
import com.maoyan.coverage.admin.domain.schema.buildHistory.BuildHistoryDO;

import java.util.ArrayList;
import java.util.List;

/**
 * @author yimingyu
 * @date 2021/07/30
 */
public class BuildHistoryConverter {

    public static BuildHistoryListModel converter2BuildHistoryModel(BuildHistoryDO buildHistoryDO){
        if (buildHistoryDO == null){
            return null;
        }
        BuildHistoryListModel buildHistoryListModel = new BuildHistoryListModel();
        buildHistoryListModel.setId(buildHistoryDO.getId());
        buildHistoryListModel.setBuildNum(buildHistoryDO.getBuildNum());
        buildHistoryListModel.setBuildType(buildHistoryDO.getBuildType());
        buildHistoryListModel.setBuilder(buildHistoryDO.getBuilder());
        buildHistoryListModel.setStartTime(buildHistoryDO.getStartTime());
        buildHistoryListModel.setEndTime(buildHistoryDO.getEndTime());
        buildHistoryListModel.setCommit(buildHistoryDO.getCommit());
        buildHistoryListModel.setLinesCovered(buildHistoryDO.getLinesCovered());
        buildHistoryListModel.setLineNum(buildHistoryDO.getLineNum());
        buildHistoryListModel.setBranchesCovered(buildHistoryDO.getBranchesCovered());
        buildHistoryListModel.setBranches(buildHistoryDO.getBranches());
        buildHistoryListModel.setBuildResult(buildHistoryDO.getBuildResult());
        buildHistoryListModel.setBuildStatus(buildHistoryDO.getBuildStatus());
        buildHistoryListModel.setJenkinsBuildNum(buildHistoryDO.getJenkinsBuildNum());
        return buildHistoryListModel;
    }

    public static List<BuildHistoryListModel> converter2BuildHistoryModelList(List<BuildHistoryDO> buildHistoryDOS){
        List<BuildHistoryListModel> buildHistoryListModels = new ArrayList<>();
        if (buildHistoryDOS.size() == 0){
            return buildHistoryListModels;
        }
        for (BuildHistoryDO bhd: buildHistoryDOS
             ) {
            buildHistoryListModels.add(converter2BuildHistoryModel(bhd));
        }
        return buildHistoryListModels;
    }

    public static BuildHistoryChartModel converter2BuildHistoryChartModel(BuildHistoryDO buildHistoryDO){
        if (buildHistoryDO == null){
            return null;
        }
        BuildHistoryChartModel buildHistoryChartModel = new BuildHistoryChartModel();
        buildHistoryChartModel.setId(buildHistoryDO.getId());
        buildHistoryChartModel.setJobId(buildHistoryDO.getJobConfigId());
        buildHistoryChartModel.setBuildNum(buildHistoryDO.getBuildNum());
        buildHistoryChartModel.setLinesCovered(buildHistoryDO.getLinesCovered());
        buildHistoryChartModel.setLineNum(buildHistoryDO.getLineNum());
        buildHistoryChartModel.setBranchesCovered(buildHistoryDO.getBranchesCovered());
        buildHistoryChartModel.setBranches(buildHistoryDO.getBranches());
        buildHistoryChartModel.setBuildStatus(buildHistoryDO.getBuildStatus());
        buildHistoryChartModel.setBuildResult(buildHistoryDO.getBuildResult());
        buildHistoryChartModel.setJobManageModel(JSONObject.parseObject(buildHistoryDO.getJobBuildConfig(), JobManageModel.class));
        return buildHistoryChartModel;
    }

    public static List<BuildHistoryChartModel> converter2BuildHistoryChartModelList(List<BuildHistoryDO> buildHistoryDOS){
        List<BuildHistoryChartModel> buildHistoryChartModels = new ArrayList<>();
        if (buildHistoryDOS.size() == 0){
            return buildHistoryChartModels;
        }
        for (BuildHistoryDO bhd: buildHistoryDOS
        ) {
            buildHistoryChartModels.add(converter2BuildHistoryChartModel(bhd));
        }
        return buildHistoryChartModels;
    }

    public static BuildHistoryModel converterToBuildHistoryModel(BuildHistoryDO buildHistoryDO) {
        BuildHistoryModel buildHistoryModel = new BuildHistoryModel();

        buildHistoryModel.setId(buildHistoryDO.getId());
        buildHistoryModel.setJobConfigId(buildHistoryDO.getJobConfigId());
        buildHistoryModel.setJobBuildConfig(buildHistoryDO.getJobBuildConfig());
        buildHistoryModel.setBuildNum(buildHistoryDO.getBuildNum());
        buildHistoryModel.setBuildResult(buildHistoryDO.getBuildResult());
        buildHistoryModel.setBuildStatus(buildHistoryDO.getBuildStatus());
        buildHistoryModel.setBranchesCovered(buildHistoryDO.getBranchesCovered());
        buildHistoryModel.setBranches(buildHistoryDO.getBranches());
        buildHistoryModel.setLinesCovered(buildHistoryDO.getLinesCovered());
        buildHistoryModel.setLineNum(buildHistoryDO.getLineNum());
        buildHistoryModel.setCommit(buildHistoryDO.getCommit());
        buildHistoryModel.setStartTime(buildHistoryDO.getStartTime());
        buildHistoryModel.setEndTime(buildHistoryDO.getEndTime());
        buildHistoryModel.setBuildType(buildHistoryDO.getBuildType());
        buildHistoryModel.setBuilder(buildHistoryDO.getBuilder());
        buildHistoryModel.setBuildResult(buildHistoryDO.getBuildResult());

        return buildHistoryModel;
    }
}
