package com.maoyan.coverage.admin.service.job;

import com.maoyan.coverage.admin.domain.schema.JobTimerDO;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author lizhuoran05
 * @date 2021/7/19
 */
public interface TestJobService {

    List<JobTimerDO> selectAll();

}
