package com.maoyan.coverage.admin.service.jobmanage;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.maoyan.coverage.admin.common.utils.DateUtils;
import com.maoyan.coverage.admin.domain.constant.DateFormatStr;
import com.maoyan.coverage.admin.domain.enums.ProjectTypeEnum;
import com.maoyan.coverage.admin.domain.model.job.config.*;
import com.maoyan.coverage.admin.domain.model.jobmanage.*;
import com.maoyan.coverage.admin.domain.schema.jobconfig.JobConfigDO;
import org.apache.commons.lang3.StringUtils;

import java.util.*;

/**
 * @date 2021/7/29
 */
public class JobManageConverter {

    public static JobBaseConfigModel convertToJobBaseConfigModel(String jobBasicConfig) {
        if (jobBasicConfig.equals("")) {
            return null;
        }
        return JSONObject.parseObject(jobBasicConfig, JobBaseConfigModel.class);
    }

    public static JobConfigModel convertToJobConfigModel(JobConfigDO jobConfigDO) {
        if (jobConfigDO == null) {
            return null;
        }
        JobConfigModel jobConfigModel = new JobConfigModel();
        jobConfigModel.setBasicConfig(jobConfigDO.getJobBaseConfig());
        jobConfigModel.setTestConfig(jobConfigDO.getJobTestConfig());
        jobConfigModel.setJobName(jobConfigDO.getJobName());
        jobConfigModel.setProjectConfigId(jobConfigDO.getProjectConfigId());
        jobConfigModel.setType(ProjectTypeEnum.typeMap.get(jobConfigDO.getType()));
        return jobConfigModel;
    }

    public static ServerTestConfigModel convertToServerTestConfigModel(String jobTestConfig) {
        ServerTestConfigModel serverTestConfigModel = new ServerTestConfigModel();

        JobTestConfig2ServerModel jobTestConfig2ServerModel = JSONObject.parseObject(jobTestConfig, JobTestConfig2ServerModel.class);

        serverTestConfigModel.setReleaseId(jobTestConfig2ServerModel.getReleaseId());
        serverTestConfigModel.setTestEnv(jobTestConfig2ServerModel.getTestEnv());

        // yyyy/MM/dd-HH:mm:ss 这种格式的
        List<String> testTimeList = jobTestConfig2ServerModel.getTestTime();
        if (testTimeList.size() == 2) {
            serverTestConfigModel.setTestStartTime(DateUtils.format2Date(DateFormatStr.DATE_FORMAT_DO, testTimeList.get(0)));
            serverTestConfigModel.setTestEndTime(DateUtils.format2Date(DateFormatStr.DATE_FORMAT_DO, testTimeList.get(1)));
        }

        // 多ip逗号分割
        List<String> ipList = jobTestConfig2ServerModel.getServerIp();
        List<String> portList = jobTestConfig2ServerModel.getAgentPort();
        HashMap<String, String> ipAndPort = new HashMap<>();
        if (ipList.size() != portList.size()) {
            throw new IllegalArgumentException("convertToServerTestConfigModel 异常，ip 数量和 port 数量不相等");
        }
        for (int i = 0; i < ipList.size(); i++) {
            ipAndPort.put(ipList.get(i), portList.get(i));
        }
        serverTestConfigModel.setIpAndPortMap(ipAndPort);
        return serverTestConfigModel;
    }

    public static WebTestConfigModel convertToWebTestConfigModel(String jobTestConfig) {
        WebTestConfigModel webTestConfigModel = new WebTestConfigModel();

        JobTestConfig2WebModel jobTestConfig2WebModel = JSONObject.parseObject(jobTestConfig, JobTestConfig2WebModel.class);

        webTestConfigModel.setTestEnv(jobTestConfig2WebModel.getTestEnv());

        ArrayList<String> deployHostList = new ArrayList<>(jobTestConfig2WebModel.getDeployHost());

        List<String> testTime = jobTestConfig2WebModel.getTestTime();
        webTestConfigModel.setTestStartTime(testTime.get(0));
        webTestConfigModel.setTestEndTime(testTime.get(1));
        webTestConfigModel.setDeployHost(deployHostList);
        return webTestConfigModel;
    }

    public static MRNTestConfigModel convertToMRNTestConfigModel(String jobTestConfig) {
        MRNTestConfigModel mrnTestConfigModel = new MRNTestConfigModel();

        JobTestConfig2MRNModel jobTestConfig2MRNModel = JSONObject.parseObject(jobTestConfig, JobTestConfig2MRNModel.class);

        mrnTestConfigModel.setReleaseEnv(jobTestConfig2MRNModel.getReleaseEnv());
        List<String> testTime = jobTestConfig2MRNModel.getTestTime();
        mrnTestConfigModel.setTestStartTime(testTime.get(0));
        mrnTestConfigModel.setTestEndTime(testTime.get(1));

        return mrnTestConfigModel;
    }

    public static AndroidTestConfigModel convertToAndroidTestConfigModel(String jobTestConfig) {
        AndroidTestConfigModel androidTestConfigModel = new AndroidTestConfigModel();

        JobTestConfig2AndroidModel jobTestConfig2AndroidModel = JSONObject.parseObject(jobTestConfig, JobTestConfig2AndroidModel.class);

        androidTestConfigModel.setBuildNum(jobTestConfig2AndroidModel.getBuildNum());
        androidTestConfigModel.setTestVersion(jobTestConfig2AndroidModel.getTestVersion());

        List<String> testTimeList = jobTestConfig2AndroidModel.getTestTime();
        if (testTimeList.size() == 2) {
            androidTestConfigModel.setTestStartTime(DateUtils.format2Date(DateFormatStr.DATE_FORMAT_DO, testTimeList.get(0)));
            androidTestConfigModel.setTestEndTime(DateUtils.format2Date(DateFormatStr.DATE_FORMAT_DO, testTimeList.get(1)));
        }

        return androidTestConfigModel;
    }

    public static IOSTestConfigModel convertToIOSTestConfigModel(String jobTestConfig) {
        IOSTestConfigModel iosTestConfigModel = new IOSTestConfigModel();

        JobTestConfig2iOSModel jobTestConfig2iOSModel = JSONObject.parseObject(jobTestConfig, JobTestConfig2iOSModel.class);

        iosTestConfigModel.setProjectVersion(jobTestConfig2iOSModel.getProjectVersion());
        iosTestConfigModel.setTestVersion(jobTestConfig2iOSModel.getTestVersion());

        return iosTestConfigModel;
    }

    public static AppletTestConfigModel convertToAppletTestConfigModel(String jobTestConfig) {
        AppletTestConfigModel appletTestConfigModel = new AppletTestConfigModel();

        JobTestConfig2AppletModel jobTestConfig2AppletModel = JSONObject.parseObject(jobTestConfig, JobTestConfig2AppletModel.class);

        appletTestConfigModel.setCurrentCommit(jobTestConfig2AppletModel.getCommit());
        // 测试时间
        List<String> testTime = jobTestConfig2AppletModel.getTestTime();
        appletTestConfigModel.setTestStartTime(testTime.get(0));
        appletTestConfigModel.setTestEndTime(testTime.get(1));

        appletTestConfigModel.setTestEnv(jobTestConfig2AppletModel.getTestEnv());
        return appletTestConfigModel;
    }

    public static JobManageModel converter2JobManageModel(JobConfigDO jobConfigDO) {
        if (jobConfigDO == null) {
            return null;
        }
        JobManageModel jobManageModel = new JobManageModel();
        jobManageModel.setId(jobConfigDO.getId());
        jobManageModel.setProjectConfigId(jobConfigDO.getProjectConfigId());
        jobManageModel.setJobType(jobConfigDO.getType());
        jobManageModel.setJobName(jobConfigDO.getJobName());
        jobManageModel.setJobBaseConfig(JSONObject.parseObject(jobConfigDO.getJobBaseConfig(), JobBaseConfigModel.class));
        jobManageModel.setJobTestConfig(jobConfigDO.getJobTestConfig());
        jobManageModel.setDeleted(jobConfigDO.getDeleted());
        jobManageModel.setCreator(jobConfigDO.getCreator());
        jobManageModel.setUpdater(jobConfigDO.getUpdater());
        jobManageModel.setCreateTime(jobConfigDO.getCreateTime());
        jobManageModel.setUpdateTime(jobConfigDO.getUpdateTime());
        jobManageModel.setJobTestType(jobConfigDO.getJobType());
        jobManageModel.setJobAutoTestConfig(JSONObject.parseObject(jobConfigDO.getJobAutoTestConfig(), JobAutoTestConfigModel.class));
        return jobManageModel;
    }

    public static List<JobManageModel> converter2JobManageModelBatch(List<JobConfigDO> jobConfigDOS) {
        List<JobManageModel> list = new ArrayList<>();
        if (jobConfigDOS.size() == 0) {
            return list;
        }
        for (JobConfigDO jobConfigDO : jobConfigDOS
        ) {
            list.add(converter2JobManageModel(jobConfigDO));
        }
        return list;
    }

    public static JobConfigDO converter2JobConfigDO(JobManageModel jobManageModel) {
        if (jobManageModel == null) {
            return null;
        }
        JobConfigDO jobConfigDO = new JobConfigDO();
        jobConfigDO.setId(jobManageModel.getId());
        jobConfigDO.setProjectConfigId(jobManageModel.getProjectConfigId());
        jobConfigDO.setType(jobManageModel.getJobType());
        jobConfigDO.setJobName(jobManageModel.getJobName());
        jobConfigDO.setJobBaseConfig(JSONObject.toJSONString(jobManageModel.getJobBaseConfig()));
        jobConfigDO.setJobTestConfig(jobManageModel.getJobTestConfig());
        jobConfigDO.setDeleted(jobManageModel.getDeleted());
        jobConfigDO.setCreator(jobManageModel.getCreator());
        jobConfigDO.setUpdater(jobManageModel.getUpdater());
        jobConfigDO.setCreateTime(jobManageModel.getCreateTime());
        jobConfigDO.setUpdateTime(jobManageModel.getUpdateTime());
        jobConfigDO.setJobType(jobManageModel.getJobTestType());
        jobConfigDO.setJobAutoTestConfig(JSONObject.toJSONString(jobManageModel.getJobAutoTestConfig()));
        return jobConfigDO;
    }

}
