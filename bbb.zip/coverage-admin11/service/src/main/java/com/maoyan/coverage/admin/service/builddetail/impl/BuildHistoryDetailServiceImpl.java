package com.maoyan.coverage.admin.service.builddetail.impl;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.maoyan.coverage.admin.dao.builddetail.read.IBuildDetailDAO;
import com.maoyan.coverage.admin.dao.builddetail.write.IWriteBuildDetailDAO;
import com.maoyan.coverage.admin.domain.model.buildhistory.BuildHistoryDetailModel;
import com.maoyan.coverage.admin.domain.schema.buildHistory.BuildHistoryDetailDO;
import com.maoyan.coverage.admin.service.builddetail.BuildHistoryConverter;
import com.maoyan.coverage.admin.service.builddetail.IBuildHistoryDetailService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * @author yimingyu
 * @date 2021/07/30
 */
@Service
public class BuildHistoryDetailServiceImpl implements IBuildHistoryDetailService {

    @Resource
    private IBuildDetailDAO buildDetailDAO;

    @Resource
    private IWriteBuildDetailDAO iWriteBuildDetailDAO;


    @Override
    public BuildHistoryDetailModel getBuildDetailByBuildId(int buildId) {
        BuildHistoryDetailDO buildDetailByBuildId = buildDetailDAO.getBuildDetailByBuildId(buildId);
        return BuildHistoryConverter.converter2BuildHistoryDetailModel(buildDetailByBuildId);
    }

    @Override
    public int insert(BuildHistoryDetailModel buildHistoryDetailModel) {
        BuildHistoryDetailDO buildHistoryDetailDO = new BuildHistoryDetailDO();
        buildHistoryDetailDO.setBuildHistoryId(buildHistoryDetailModel.getBuildId());
        // JSONArray.toJSONString
        buildHistoryDetailDO.setDataIndicators(JSONArray.toJSONString(buildHistoryDetailModel.getDataIndicatorsModels()));
        buildHistoryDetailDO.setReportDetailUrl(buildHistoryDetailModel.getReportDetailUrl());

        return iWriteBuildDetailDAO.insert(buildHistoryDetailDO);
    }
}
