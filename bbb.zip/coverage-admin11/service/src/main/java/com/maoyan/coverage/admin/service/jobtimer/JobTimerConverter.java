package com.maoyan.coverage.admin.service.jobtimer;

import com.google.common.collect.Lists;
import com.maoyan.coverage.admin.domain.model.JobTimerModel;
import com.maoyan.coverage.admin.domain.schema.JobTimerDO;

import java.util.ArrayList;
import java.util.List;

/**
 * @author lizhuoran05
 * @date 2021/7/27
 */
public class JobTimerConverter {

    public static JobTimerModel convertToModel(JobTimerDO jobTimerDO) {
        if (jobTimerDO == null) {
            return null;
        }
        JobTimerModel jobTimerModel = new JobTimerModel();
        jobTimerModel.setTimerValue(jobTimerDO.getTimerValue());
        jobTimerModel.setTimerType(jobTimerDO.getTimerType());
        jobTimerModel.setJobConfigId(jobTimerDO.getJobConfigId());
        jobTimerModel.setClosed(jobTimerDO.getClosed());
        jobTimerModel.setType(jobTimerDO.getType());
        return jobTimerModel;
    }

    public static List<JobTimerModel> convertToModels(List<JobTimerDO> jobTimerDOList) {
        if (jobTimerDOList.isEmpty()) {
            return Lists.newArrayList();
        }
        List<JobTimerModel> jobTimerModels = new ArrayList<>();
        jobTimerDOList.forEach(jobTimerDO -> {
            JobTimerModel jobTimerModel = new JobTimerModel();
            jobTimerModel.setTimerValue(jobTimerDO.getTimerValue());
            jobTimerModel.setTimerType(jobTimerDO.getTimerType());
            jobTimerModel.setJobConfigId(jobTimerDO.getJobConfigId());
            jobTimerModel.setClosed(jobTimerDO.getClosed());
            jobTimerModel.setType(jobTimerDO.getType());
            jobTimerModels.add(jobTimerModel);
        });
        return jobTimerModels;
    }

}
