package com.maoyan.coverage.admin.service.jobtimer.impl;

import com.maoyan.coverage.admin.dao.jobtimer.JobTimerDAO;
import com.maoyan.coverage.admin.domain.model.JobTimerModel;
import com.maoyan.coverage.admin.domain.schema.JobTimerDO;
import com.maoyan.coverage.admin.service.jobtimer.JobTimerConverter;
import com.maoyan.coverage.admin.service.jobtimer.JobTimerService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author lizhuoran05
 * @date 2021/7/20
 */
@Service
public class JobTimerServiceImpl implements JobTimerService {

    @Resource
    JobTimerDAO jobTimerDAO;

    @Override
    public int insert(JobTimerModel jobTimerModel) {
        JobTimerDO jobTimerDO = new JobTimerDO();
        jobTimerDO.setClosed(jobTimerModel.getClosed());
        jobTimerDO.setJobConfigId(jobTimerModel.getJobConfigId());
        jobTimerDO.setTimerType(jobTimerModel.getTimerType());
        jobTimerDO.setTimerValue(jobTimerModel.getTimerValue());
        jobTimerDO.setType(jobTimerModel.getType());
        return jobTimerDAO.insert(jobTimerDO);
    }

    @Override
    public int updateByJobConfigIdAndType(JobTimerModel jobTimerModel) {
        JobTimerDO jobTimerDO = new JobTimerDO();
        jobTimerDO.setClosed(jobTimerModel.getClosed());
        jobTimerDO.setJobConfigId(jobTimerModel.getJobConfigId());
        jobTimerDO.setTimerType(jobTimerModel.getTimerType());
        jobTimerDO.setTimerValue(jobTimerModel.getTimerValue());
        jobTimerDO.setType(jobTimerModel.getType());
        return jobTimerDAO.updateByJobConfigIdAndType(jobTimerDO);
    }

    @Override
    public JobTimerModel getJobTimerModelByJobConfigId(int jobConfigId) {
        return JobTimerConverter.convertToModel(jobTimerDAO.getJobTimerDOByJobConfigId(jobConfigId));
    }

    @Override
    public int deleteById(int id) {
        return jobTimerDAO.deleteById(id);
    }

    @Override
    public List<JobTimerModel> getJobTimerModelsByClosed(int closed) {
        return JobTimerConverter.convertToModels(jobTimerDAO.getJobTimerDOByClosed(closed));
    }

    @Override
    public List<JobTimerModel> getJobTimerModelsByJobConfigIdAndClosed(int jobConfigId, int closed) {
        return JobTimerConverter.convertToModels(jobTimerDAO.getJobTimerDOByJobConfigIdAndClosed(jobConfigId, closed));
    }

    @Override
    public JobTimerModel getJobTimerModelByJobConfigIdAndType(int jobConfigId, int type) {
        return JobTimerConverter.convertToModel(jobTimerDAO.getJobTimerDOByJobConfigIdAndType(jobConfigId, type));
    }

    @Override
    public JobTimerModel getByJobConfigIdAndTypeAndClosed(int jobConfigId, int type, int closed) {
        return JobTimerConverter.convertToModel(jobTimerDAO.getJobTimerDOByJobConfigIdAndTypeAndClosed(jobConfigId, type, closed));
    }


}
