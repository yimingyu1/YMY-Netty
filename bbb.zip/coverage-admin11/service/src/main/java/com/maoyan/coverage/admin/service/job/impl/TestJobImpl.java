package com.maoyan.coverage.admin.service.job.impl;

import com.maoyan.coverage.admin.dao.jobtimer.JobTimerDAO;
import com.maoyan.coverage.admin.domain.schema.JobTimerDO;
import com.maoyan.coverage.admin.service.job.TestJobService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author lizhuoran05
 * @date 2021/7/19
 */
@Service
public class TestJobImpl implements TestJobService {

    @Resource
    JobTimerDAO jobTimerDAO;

    @Override
    public List<JobTimerDO> selectAll() {
        return jobTimerDAO.selectAll();
    }
}
