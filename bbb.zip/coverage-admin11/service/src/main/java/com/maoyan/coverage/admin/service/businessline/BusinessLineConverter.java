package com.maoyan.coverage.admin.service.businessline;

import com.maoyan.coverage.admin.domain.model.businessline.BusinessLineModel;
import com.maoyan.coverage.admin.domain.schema.businessline.BusinessLineDO;

import java.util.ArrayList;
import java.util.List;

/**
 * @author yimingyu
 * @date 2021/07/29
 */
public class BusinessLineConverter {

    public static BusinessLineModel converter2BusinessLineModel(BusinessLineDO businessLineDO){
        if (businessLineDO == null){
            return null;
        }
        BusinessLineModel businessLineModel = new BusinessLineModel();
        businessLineModel.setId(businessLineDO.getId());
        businessLineModel.setBusinessLine(businessLineDO.getBusinessLine());
        businessLineModel.setCreator(businessLineDO.getCreator());
        businessLineModel.setUpdater(businessLineDO.getUpdater());
        businessLineModel.setDeleted(businessLineDO.getDeleted());
        businessLineModel.setCreateTime(businessLineDO.getCreateTime());
        businessLineModel.setUpdateTime(businessLineDO.getUpdateTime());
        return businessLineModel;
    }

    public static List<BusinessLineModel> converter2BusinessLineModelBatch(List<BusinessLineDO> businessLineDOS){
        List<BusinessLineModel> businessLineModels = new ArrayList<>();
        if (businessLineDOS.size() == 0){
            return businessLineModels;
        }
        for (BusinessLineDO businessLineDO: businessLineDOS
             ) {
            businessLineModels.add(converter2BusinessLineModel(businessLineDO));
        }
        return businessLineModels;
    }

    public static BusinessLineDO converter2BusinessLineDO(BusinessLineModel businessLineModel){
        if (businessLineModel == null){
            return null;
        }
        BusinessLineDO businessLineDO = new BusinessLineDO();
        businessLineDO.setId(businessLineModel.getId());
        businessLineDO.setBusinessLine(businessLineModel.getBusinessLine());
        businessLineDO.setCreator(businessLineModel.getCreator());
        businessLineDO.setUpdater(businessLineModel.getUpdater());
        businessLineDO.setDeleted(businessLineModel.getDeleted());
        businessLineDO.setCreateTime(businessLineModel.getCreateTime());
        businessLineDO.setUpdateTime(businessLineModel.getUpdateTime());
        return businessLineDO;
    }

}
