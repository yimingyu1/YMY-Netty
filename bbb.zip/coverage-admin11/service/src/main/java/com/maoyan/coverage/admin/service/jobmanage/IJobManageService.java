package com.maoyan.coverage.admin.service.jobmanage;

import com.maoyan.coverage.admin.domain.model.job.config.*;
import com.maoyan.coverage.admin.domain.model.jobmanage.JobBaseConfigModel;
import com.maoyan.coverage.admin.domain.model.jobmanage.JobConfigModel;
import com.maoyan.coverage.admin.domain.model.jobmanage.JobDetailConfigModel;
import com.maoyan.coverage.admin.domain.model.jobmanage.JobManageModel;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

/**
 * @author yimingyu
 * @date 2021/07/27
 */
public interface IJobManageService {

    List<JobManageModel> getJobManageListByProjectId(int projectId, int jobType);
    List<JobManageModel> getJobManageListByProjectId(int projectId);

    int insertJobConfig(JobManageModel jobConfigDO);

    JobManageModel getJobConfigByName(String jobName);

    JobManageModel getJobConfigById(int id);

    List<JobManageModel> getJobManageListWithLimit(int projectId, int jobType, int offset, int limit);

    int updateJobConfig(JobManageModel jobConfigDO);

    int deleteJobConfig(int id, String updater, LocalDateTime updateTime);

    int deleteJobBranch(Map<String, Object> delJobMap);

    String getJobNameByJobConfigId(int id);

    int getProjectTypeByJobConfigId(int id);

    JobBaseConfigModel getJobBaseConfigModelByJobConfigId(int id);

    JobConfigModel getJobConfigModelByJobConfigId(int id);

    ServerTestConfigModel getServerTestConfigModelByJobConfigId(int id);

    AppletTestConfigModel getAppletTestConfigModelByJobConfigId(int id);

    WebTestConfigModel getWebTestConfigModelByJobConfigId(int id);

    MRNTestConfigModel getMRNTestConfigModelByJobConfigId(int id);

    AndroidTestConfigModel getAndroidTestConfigModelByJobConfigId(int id);

    IOSTestConfigModel getIOSTestConfigModelByJobConfigId(int id);

    JobDetailConfigModel<ServerTestConfigModel> getServerJobDetailConfigModelByJobConfigId(int id);

    JobDetailConfigModel<WebTestConfigModel> getWebJobDetailConfigModelByJobConfigId(int id);

    JobDetailConfigModel<AndroidTestConfigModel> getAndroidJobDetailConfigModelByJobConfigId(int id);

    JobDetailConfigModel<IOSTestConfigModel> getIOSJobDetailConfigModelByJobConfigId(int id);

    JobDetailConfigModel<MRNTestConfigModel> getMRNJobDetailConfigModelByJobConfigId(int id);

    JobDetailConfigModel<AppletTestConfigModel> getAppletJobDetailConfigModelByJobConfigId(int id);

    String getBuildHistoryProjectManageModelByBuildId(int buildId);

    List<Integer> getAllJobConfigId();
}
