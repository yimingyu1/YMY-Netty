package com.maoyan.coverage.admin.service.builddetail;

import com.maoyan.coverage.admin.domain.model.buildhistory.BuildHistoryDetailModel;

/**
 * @author yimingyu
 * @date 2021/07/30
 */
public interface IBuildHistoryDetailService {

    BuildHistoryDetailModel getBuildDetailByBuildId(int buildId);

    int insert(BuildHistoryDetailModel buildHistoryDetailModel);
}
