package com.maoyan.coverage.admin.service.businessline.impl;

import com.maoyan.coverage.admin.dao.businessLine.read.IBusinessLineDAO;
import com.maoyan.coverage.admin.dao.businessLine.write.IWriteBusinessLineDAO;
import com.maoyan.coverage.admin.domain.model.businessline.BusinessLineModel;
import com.maoyan.coverage.admin.domain.schema.businessline.BusinessLineDO;
import com.maoyan.coverage.admin.service.businessline.BusinessLineConverter;
import com.maoyan.coverage.admin.service.businessline.IBusinessLineService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

/**
 * @author yimingyu
 * @date 2021/07/19
 */
@Service
public class BusinessLineServiceImpl implements IBusinessLineService {

    @Resource
    private IBusinessLineDAO businessLineDAO;
    @Resource
    private IWriteBusinessLineDAO writeBusinessLineDAO;

    @Override
    public int insetBusinessLine(BusinessLineModel businessLine) {
        BusinessLineDO businessLineDO = BusinessLineConverter.converter2BusinessLineDO(businessLine);
        return writeBusinessLineDAO.insertBusinessLine(businessLineDO);
    }



    @Override
    public List<BusinessLineModel> getBusinessLineList(int offset, int limit) {
        List<BusinessLineDO> businessLineList = businessLineDAO.getBusinessLineList(offset, limit);
        return BusinessLineConverter.converter2BusinessLineModelBatch(businessLineList);
    }

    @Override
    public int updateBusinessLine(BusinessLineModel businessLine) {
        BusinessLineDO businessLineDO = BusinessLineConverter.converter2BusinessLineDO(businessLine);
        return writeBusinessLineDAO.updateBusinessLine(businessLineDO);
    }

    @Override
    public int delBusinessLineById(BusinessLineModel businessLine) {
        BusinessLineDO businessLineDO = BusinessLineConverter.converter2BusinessLineDO(businessLine);
        return writeBusinessLineDAO.deleteBusinessLineById(businessLineDO);
    }

    @Override
    public List<BusinessLineModel> getAllBusinessLines() {
        List<BusinessLineDO> allBusinessLines = businessLineDAO.getAllBusinessLines();
        return BusinessLineConverter.converter2BusinessLineModelBatch(allBusinessLines);
    }

    @Override
    public BusinessLineModel getBusinessLineByName(String businessLineName) {
        BusinessLineDO businessLineByName = businessLineDAO.getBusinessLineByName(businessLineName);
        return BusinessLineConverter.converter2BusinessLineModel(businessLineByName);
    }

    @Override
    public BusinessLineModel getBusinessLineById(int businessLineId) {
        BusinessLineDO businessLineById = businessLineDAO.getBusinessLineById(businessLineId);
        return BusinessLineConverter.converter2BusinessLineModel(businessLineById);
    }
}
