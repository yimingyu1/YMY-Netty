package com.maoyan.coverage.admin.service.jobmanage.impl;

import com.maoyan.coverage.admin.dao.jobmanage.read.IJobManageDAO;
import com.maoyan.coverage.admin.dao.jobmanage.write.IWriteJobManageDAO;
import com.maoyan.coverage.admin.domain.model.job.config.*;
import com.maoyan.coverage.admin.domain.model.jobmanage.JobBaseConfigModel;
import com.maoyan.coverage.admin.domain.model.jobmanage.JobConfigModel;
import com.maoyan.coverage.admin.domain.model.jobmanage.JobDetailConfigModel;
import com.maoyan.coverage.admin.domain.model.jobmanage.JobManageModel;
import com.maoyan.coverage.admin.domain.schema.jobconfig.JobConfigDO;
import com.maoyan.coverage.admin.service.jobmanage.IJobManageService;
import com.maoyan.coverage.admin.service.jobmanage.JobManageConverter;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

/**
 * @author yimingyu
 * @date 2021/07/27
 */
@Service
public class JobManageServiceImpl implements IJobManageService {

    @Resource
    private IJobManageDAO jobManageDAO;

    @Resource
    private IWriteJobManageDAO writeJobManageDAO;

    @Override
    public List<JobManageModel> getJobManageListByProjectId(int projectId, int jobType) {
        List<JobConfigDO> jobConfigListByProjectConfigId = jobManageDAO.getJobConfigListByProjectConfigIdAndJobType(projectId, jobType);
        return JobManageConverter.converter2JobManageModelBatch(jobConfigListByProjectConfigId);
    }
    @Override
    public List<JobManageModel> getJobManageListByProjectId(int projectId) {
        List<JobConfigDO> jobConfigListByProjectConfigId = jobManageDAO.getJobConfigListByProjectConfigId(projectId);
        return JobManageConverter.converter2JobManageModelBatch(jobConfigListByProjectConfigId);
    }

    @Override
    public int insertJobConfig(JobManageModel jobManageModel) {
        JobConfigDO jobConfig = JobManageConverter.converter2JobConfigDO(jobManageModel);
        int res = writeJobManageDAO.insertJob(jobConfig);
        if (res > 0){
            return jobConfig.getId();
        }
        return res;
    }

    @Override
    public JobManageModel getJobConfigByName(String jobName)
    {
        JobConfigDO jobConfigByName = jobManageDAO.getJobConfigByName(jobName);
        return JobManageConverter.converter2JobManageModel(jobConfigByName);
    }

    @Override
    public JobManageModel getJobConfigById(int id) {
        JobConfigDO jobConfigById = jobManageDAO.getJobConfigById(id);
        return JobManageConverter.converter2JobManageModel(jobConfigById);
    }

    @Override
    public List<JobManageModel> getJobManageListWithLimit(int projectId, int jobType, int offset, int limit) {
        List<JobConfigDO> jobConfigListWithLimit = jobManageDAO.getJobConfigListWithLimit(projectId, jobType, offset, limit);
        return JobManageConverter.converter2JobManageModelBatch(jobConfigListWithLimit);
    }

    @Override
    public int updateJobConfig(JobManageModel jobManageModel) {
        return writeJobManageDAO.updateJob(JobManageConverter.converter2JobConfigDO(jobManageModel));
    }

    @Override
    public int deleteJobConfig(int id, String updater, LocalDateTime updateTime) {
        return writeJobManageDAO.deleteJob(id, updater, updateTime);
    }

    @Override
    public String getJobNameByJobConfigId(int id) {
        return jobManageDAO.getJobNameByJobConfigId(id);
    }

    @Override
    public int getProjectTypeByJobConfigId(int id) {
        return jobManageDAO.getProjectTypeByJobConfigId(id);
    }

    @Override
    public JobBaseConfigModel getJobBaseConfigModelByJobConfigId(int id) {
        return JobManageConverter.convertToJobBaseConfigModel(jobManageDAO.getJobBasicConfigModelByJobConfigId(id));

    }

    @Override
    public JobConfigModel getJobConfigModelByJobConfigId(int id) {
        return JobManageConverter.convertToJobConfigModel(jobManageDAO.getJobConfigById(id));
    }

    @Override
    public ServerTestConfigModel getServerTestConfigModelByJobConfigId(int id) {
        String jobTestConfig = jobManageDAO.getJobTestConfigByJobConfigId(id);
        return JobManageConverter.convertToServerTestConfigModel(jobTestConfig);
    }

    @Override
    public AppletTestConfigModel getAppletTestConfigModelByJobConfigId(int id) {
        String jobTestConfig = jobManageDAO.getJobTestConfigByJobConfigId(id);
        return JobManageConverter.convertToAppletTestConfigModel(jobTestConfig);
    }

    @Override
    public WebTestConfigModel getWebTestConfigModelByJobConfigId(int id) {
        String jobTestConfig = jobManageDAO.getJobTestConfigByJobConfigId(id);
        return JobManageConverter.convertToWebTestConfigModel(jobTestConfig);
    }

    @Override
    public MRNTestConfigModel getMRNTestConfigModelByJobConfigId(int id) {
        String jobTestConfig = jobManageDAO.getJobTestConfigByJobConfigId(id);
        return JobManageConverter.convertToMRNTestConfigModel(jobTestConfig);
    }

    @Override
    public AndroidTestConfigModel getAndroidTestConfigModelByJobConfigId(int id) {
        String jobTestConfig = jobManageDAO.getJobTestConfigByJobConfigId(id);
        return JobManageConverter.convertToAndroidTestConfigModel(jobTestConfig);
    }

    @Override
    public IOSTestConfigModel getIOSTestConfigModelByJobConfigId(int id) {
        String jobTestConfig = jobManageDAO.getJobTestConfigByJobConfigId(id);
        return JobManageConverter.convertToIOSTestConfigModel(jobTestConfig);
    }

    @Override
    public JobDetailConfigModel<ServerTestConfigModel> getServerJobDetailConfigModelByJobConfigId(int id) {
        JobDetailConfigModel<ServerTestConfigModel> jobDetailConfigModel = new JobDetailConfigModel<>();
        // 查询数据库
        JobConfigModel jobConfigModel = getJobConfigModelByJobConfigId(id);
        // 基础配置
        JobBaseConfigModel jobBasicConfigModel = JobManageConverter.convertToJobBaseConfigModel(jobConfigModel.getBasicConfig());
        // 测试配置
        jobDetailConfigModel.setTestConfig(JobManageConverter.convertToServerTestConfigModel(jobConfigModel.getTestConfig()));

        jobDetailConfigModel.setType(jobConfigModel.getType());
        jobDetailConfigModel.setProjectConfigId(jobConfigModel.getProjectConfigId());
        jobDetailConfigModel.setJobName(jobConfigModel.getJobName());
        jobDetailConfigModel.setBasicConfig(jobBasicConfigModel);

        return jobDetailConfigModel;
    }

    @Override
    public JobDetailConfigModel<WebTestConfigModel> getWebJobDetailConfigModelByJobConfigId(int id) {
        JobDetailConfigModel<WebTestConfigModel> jobDetailConfigModel = new JobDetailConfigModel<>();
        // 查询数据库
        JobConfigModel jobConfigModel = getJobConfigModelByJobConfigId(id);
        // 基础配置
        JobBaseConfigModel jobBasicConfigModel = JobManageConverter.convertToJobBaseConfigModel(jobConfigModel.getBasicConfig());
        // 测试配置
        jobDetailConfigModel.setTestConfig(JobManageConverter.convertToWebTestConfigModel(jobConfigModel.getTestConfig()));

        jobDetailConfigModel.setType(jobConfigModel.getType());
        jobDetailConfigModel.setProjectConfigId(jobConfigModel.getProjectConfigId());
        jobDetailConfigModel.setJobName(jobConfigModel.getJobName());
        jobDetailConfigModel.setBasicConfig(jobBasicConfigModel);

        return jobDetailConfigModel;
    }

    @Override
    public JobDetailConfigModel<AndroidTestConfigModel> getAndroidJobDetailConfigModelByJobConfigId(int id) {
        JobDetailConfigModel<AndroidTestConfigModel> jobDetailConfigModel = new JobDetailConfigModel<>();
        // 查询数据库
        JobConfigModel jobConfigModel = getJobConfigModelByJobConfigId(id);
        // 基础配置
        JobBaseConfigModel jobBasicConfigModel = JobManageConverter.convertToJobBaseConfigModel(jobConfigModel.getBasicConfig());
        // 测试配置
        jobDetailConfigModel.setTestConfig(JobManageConverter.convertToAndroidTestConfigModel(jobConfigModel.getTestConfig()));

        jobDetailConfigModel.setType(jobConfigModel.getType());
        jobDetailConfigModel.setProjectConfigId(jobConfigModel.getProjectConfigId());
        jobDetailConfigModel.setJobName(jobConfigModel.getJobName());
        jobDetailConfigModel.setBasicConfig(jobBasicConfigModel);

        return jobDetailConfigModel;
    }

    @Override
    public JobDetailConfigModel<IOSTestConfigModel> getIOSJobDetailConfigModelByJobConfigId(int id) {
        JobDetailConfigModel<IOSTestConfigModel> jobDetailConfigModel = new JobDetailConfigModel<>();
        // 查询数据库
        JobConfigModel jobConfigModel = getJobConfigModelByJobConfigId(id);
        // 基础配置
        JobBaseConfigModel jobBasicConfigModel = JobManageConverter.convertToJobBaseConfigModel(jobConfigModel.getBasicConfig());
        // 测试配置
        jobDetailConfigModel.setTestConfig(JobManageConverter.convertToIOSTestConfigModel(jobConfigModel.getTestConfig()));

        jobDetailConfigModel.setType(jobConfigModel.getType());
        jobDetailConfigModel.setProjectConfigId(jobConfigModel.getProjectConfigId());
        jobDetailConfigModel.setJobName(jobConfigModel.getJobName());
        jobDetailConfigModel.setBasicConfig(jobBasicConfigModel);

        return jobDetailConfigModel;
    }

    @Override
    public JobDetailConfigModel<MRNTestConfigModel> getMRNJobDetailConfigModelByJobConfigId(int id) {
        JobDetailConfigModel<MRNTestConfigModel> jobDetailConfigModel = new JobDetailConfigModel<>();
        // 查询数据库
        JobConfigModel jobConfigModel = getJobConfigModelByJobConfigId(id);
        // 基础配置
        JobBaseConfigModel jobBasicConfigModel = JobManageConverter.convertToJobBaseConfigModel(jobConfigModel.getBasicConfig());
        // 测试配置
        jobDetailConfigModel.setTestConfig(JobManageConverter.convertToMRNTestConfigModel(jobConfigModel.getTestConfig()));

        jobDetailConfigModel.setType(jobConfigModel.getType());
        jobDetailConfigModel.setProjectConfigId(jobConfigModel.getProjectConfigId());
        jobDetailConfigModel.setJobName(jobConfigModel.getJobName());
        jobDetailConfigModel.setBasicConfig(jobBasicConfigModel);

        return jobDetailConfigModel;
    }

    @Override
    public JobDetailConfigModel<AppletTestConfigModel> getAppletJobDetailConfigModelByJobConfigId(int id) {
        JobDetailConfigModel<AppletTestConfigModel> jobDetailConfigModel = new JobDetailConfigModel<>();
        // 查询数据库
        JobConfigModel jobConfigModel = getJobConfigModelByJobConfigId(id);
        // 基础配置
        JobBaseConfigModel jobBasicConfigModel = JobManageConverter.convertToJobBaseConfigModel(jobConfigModel.getBasicConfig());
        // 测试配置
        jobDetailConfigModel.setTestConfig(JobManageConverter.convertToAppletTestConfigModel(jobConfigModel.getTestConfig()));

        jobDetailConfigModel.setType(jobConfigModel.getType());
        jobDetailConfigModel.setProjectConfigId(jobConfigModel.getProjectConfigId());
        jobDetailConfigModel.setJobName(jobConfigModel.getJobName());
        jobDetailConfigModel.setBasicConfig(jobBasicConfigModel);

        return jobDetailConfigModel;
    }

    @Override
    public String getBuildHistoryProjectManageModelByBuildId(int buildId) {
        return jobManageDAO.getBuildHistoryProjectManageModelByBuildId(buildId);
    }

    @Override
    public List<Integer> getAllJobConfigId() {
        return jobManageDAO.getAllJobConfigId();
    }

    @Override
    public int deleteJobBranch(Map<String, Object> delJobMap) {
        return writeJobManageDAO.deleteJobBranch(delJobMap);
    }
}
