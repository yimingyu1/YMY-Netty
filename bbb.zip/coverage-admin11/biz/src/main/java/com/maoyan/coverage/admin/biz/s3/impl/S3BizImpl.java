package com.maoyan.coverage.admin.biz.s3.impl;

import com.google.common.collect.Lists;
import com.maoyan.coverage.admin.biz.s3.S3Biz;
import com.maoyan.coverage.admin.common.PropUtil;
import com.maoyan.coverage.admin.common.S3Util;
import com.maoyan.coverage.admin.common.utils.DateUtils;
import com.maoyan.coverage.admin.common.utils.PathUtils;
import com.maoyan.coverage.admin.common.utils.ProcessUtils;
import com.maoyan.coverage.admin.common.utils.XMPubUtil;
import com.maoyan.coverage.admin.domain.constant.S3UrlPrefixConstant;
import com.maoyan.coverage.admin.domain.enums.CoverageTypeEnum;
import com.maoyan.coverage.admin.domain.enums.ProjectTypeEnum;
import com.maoyan.coverage.admin.domain.enums.S3EnvEnum;
import com.maoyan.coverage.admin.domain.enums.TestEnvEnum;
import com.maoyan.coverage.admin.domain.model.job.msg.ReportUploadFailedMsgModel;
import com.maoyan.coverage.admin.domain.param.s3.S3UploadReportsReq;
import com.maoyan.coverage.admin.biz.s3.S3UtilBiz;
import com.maoyan.coverage.admin.domain.param.s3.S3UploadDataReq;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import sun.rmi.runtime.Log;

import javax.annotation.Resource;
import java.io.File;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * Created by lihongmei03 on 2020-11-30
 */

@Service
@Slf4j
public class S3BizImpl implements S3Biz {
    public static final Logger LOGGER = LoggerFactory.getLogger(S3BizImpl.class);

    @Resource
    private S3UtilBiz s3UtilBiz;
    
    private S3Util s3Util = new S3Util();
    
    private String s3urlPrefix = PropUtil.getProperty("env.mss.prefix");

    /**
     * 上传报告的最小单元方法
     */
    private String uploadReports(int jobId, int buildNum, String targetPath, String localReportPath) {
        LOGGER.info("[S3]: job {} 上传报告, buildNum: {}", jobId, buildNum);
        long startTime = System.currentTimeMillis();

        // 递归统计文件夹下文件总数，后续如影响效率可考虑去掉
        ArrayList<File> sumFileNumList = new ArrayList<>();
        statisticsReportNum(new File(localReportPath), sumFileNumList);

        // 并行上传
        HashMap<String, File> uploadFailedReportMap = multiThreadUploadReport(sumFileNumList, targetPath, localReportPath);

        // 存在上传失败的, 重试 1 次
        if (uploadFailedReportMap.size() != 0) {
            LOGGER.warn("[S3]: job {} 上传报告时存在上传失败的情况, 共有 {} 个文件上传失败, 开始重试", jobId, uploadFailedReportMap.size());
            retryUploadReport(uploadFailedReportMap, jobId, buildNum, 1);
        }
        LOGGER.info("[S3]: job {} 上传报告完成, buildNum: {}, 共耗时: {} ms", jobId, buildNum, (System.currentTimeMillis() - startTime));
        return s3urlPrefix + targetPath;
    }

    /**
     * 安卓: android/coverage_report/${projectName}/job_${jobId}/build_${buildNum}
     * iOS: ios/coverage_report/${projectName}/job_${jobId}/build_${buildNum}
     */
    @Override
    public String uploadReports(ProjectTypeEnum projectType, String projectName, Integer jobId, Integer buildNum, String localReportPath) {
        String projectTypePath = PathUtils.projectTypeToPath(projectType);
        // s3 目标存储路径
        String targetPath = projectTypePath + "coverage_report/" + projectName + "/job_" + jobId + "/build_" + buildNum + "/";
        return uploadReports(jobId, buildNum, targetPath, localReportPath);
    }

    /**
     * 服务端调用
     * 服务端: server/coverage_report/${env}/${projectName}/job_${jobId}/build_${buildNum}
     */
    @Override
    public String uploadReportsWithEnv(ProjectTypeEnum projectType, String projectName, Integer jobId, Integer buildNum, String localReportPath, String s3Env) {
        String projectTypePath = PathUtils.projectTypeToPath(projectType);
        // s3 目标存储路径
        String targetPath = projectTypePath + "coverage_report/" + (s3Env.equals("test") ? "test" : "staging") + "/" +  projectName + "/job_" + jobId + "/build_" + buildNum + "/";
        return uploadReports(jobId, buildNum, targetPath, localReportPath);
    }

    private void statisticsReportNum(File file, ArrayList<File> sumFileList) {
        if (file != null && file.isDirectory()) {
            File[] fs = file.listFiles();
            for (File f : fs) {
                if (f.isDirectory()) {
                    statisticsReportNum(f, sumFileList);
                } else {
                    sumFileList.add(f);
                }
            }
        }
    }

    /**
     * 多线程上传报告
     *
     * @param reportFileList
     */
    private HashMap<String, File> multiThreadUploadReport(ArrayList<File> reportFileList, String targetPath, String localReportPath) {
        // 每 200 条数据开一条线程
        int threadSize = 200;
        // 需要的线程数量
        int threadNum = reportFileList.size() / threadSize + 1;
        LOGGER.info("[S3]: 多线程上传报告, 共准备开启线程 {} 个", threadNum);

        // 文件的数量与线程的数量是否能整除
        boolean special = reportFileList.size() % threadSize == 0;
        // 线程池
        ExecutorService executorService = Executors.newFixedThreadPool(threadNum);
        // 任务集合
        List<Callable<HashMap<String, File>>> tasks = new ArrayList<>();
        Callable<HashMap<String, File>> task = null;
        List<File> subFileList = null;
        // 分解数据
        for (int i = 0; i < threadNum; i++) {
            if (i == threadNum - 1) {
                if (special) {
                    break;
                }
                // 全给最后一个
                subFileList = reportFileList.subList(threadSize * i, reportFileList.size());
            } else {
                subFileList = reportFileList.subList(threadSize * i, threadSize * (i + 1));
            }
            final List<File> willProcessFileList = subFileList;
            task = () -> listUploadReport(willProcessFileList, targetPath, localReportPath);
            // 添加
            tasks.add(task);
        }

        HashMap<String, File> allUploadFailedMap = new HashMap<>();

        try {
            List<Future<HashMap<String, File>>> results = executorService.invokeAll(tasks);
            //  汇总结果
            for (Future<HashMap<String, File>> future : results) {
                allUploadFailedMap.putAll(future.get());
            }
            return allUploadFailedMap;
        } catch (Exception e) {
            LOGGER.error("上传报告时出现问题，请注意", e);
            ReportUploadFailedMsgModel reportUploadFailedMsgModel = new ReportUploadFailedMsgModel();
            reportUploadFailedMsgModel.setTargetPath(targetPath);
            XMPubUtil.sendToDeveloper(reportUploadFailedMsgModel.getMsg());
            return null;
        } finally {
            executorService.shutdown();
        }
    }

    /**
     * 文件遍历上传
     *
     * @param files
     */
    private HashMap<String, File> listUploadReport(List<File> files, String targetPath, String localReportPath) {
        int filesSize = files.size();
        LOGGER.info("线程 {} 开始处理, 共需处理 {} 条数据", Thread.currentThread().getName(), filesSize);
        HashMap<String, File> uploadFailedList = new HashMap<>();
        for (int i = 0; i < files.size(); i++) {
            File file = files.get(i);
            String targetS3Path = targetPath + (file.getAbsolutePath().split(localReportPath)[1]);
            try {
                if (s3UtilBiz.putReportFileV2(file, targetS3Path)) {
                    ProcessUtils.show(Thread.currentThread().getName(), i, filesSize);
                }
            } catch (Exception e) {
                LOGGER.error("线程上传报告时出现问题", e);
                uploadFailedList.put(targetS3Path, file);
            }
        }

        return uploadFailedList;
    }

    private void retryUploadReport(HashMap<String, File> uploadFailedReportMap, Integer
            jobId, Integer buildNum, Integer retry) {
        int retryCount = 0;

        while (retryCount < retry) {
            uploadFailedReportMap.keySet().forEach(filePath -> {
                try {
                    if (s3UtilBiz.putReportFileV2(uploadFailedReportMap.get(filePath), filePath)) {
                        // 上传成功, 从上传失败的 map 中移除
                        uploadFailedReportMap.remove(filePath);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            });
            retryCount++;
        }


        if (uploadFailedReportMap.size() != 0) {
            throw new RuntimeException("job" + jobId + " buildNum" + buildNum + " 报告上传失败");
        }
    }

    @Override
    public Boolean uploadEcFileWithEnv(String filePath, String applicationId, String version, String
            buildNum, String variantName, String env) {
        Boolean uploadStatus = true;
        // ec 文件统一使用前缀，存在对应的 ec 路径下
        String path = s3Util.coverageTypeMapping(CoverageTypeEnum.ANDROID.getType()) + "coverage_data/" + applicationId + "/" + version + "/" + buildNum + "/ec/";
        try {
            File uploadFile = new File(filePath);
            uploadStatus = s3UtilBiz.putObjectFileWithEnv(uploadFile, path, env);
            if (uploadStatus) {
                LOGGER.info("文件上传成功, 文件保存至:" + path + uploadFile.getName());
                // 删除临时文件
                boolean isDelete = uploadFile.delete();
                if (!isDelete) {
                    LOGGER.error("临时文件删除失败:" + filePath);
                }
            }
        } catch (Exception e) {
            LOGGER.error("文件上传失败:" + e.getMessage());
            uploadStatus = false;
        }
        return uploadStatus;
    }

    @Override
    public Boolean uploadCommitFileWithEnv(String filePath, String applicationId, String version, String buildNum, String variantName, String env) {
        Boolean uploadStatus = true;
        // commit 文件统一使用前缀，存在对应的 commit 路径下
        String path = s3Util.coverageTypeMapping(CoverageTypeEnum.ANDROID.getType()) + "coverage_data/" + applicationId + "/" + version + "/" + buildNum + "/commit/";
        try {
            File uploadFile = new File(filePath);
            uploadStatus = s3UtilBiz.putObjectFileWithEnv(uploadFile, path, env);
            if (uploadStatus) {
                LOGGER.info("文件上传成功, 文件保存至:" + path + uploadFile.getName());
                // 删除临时文件
                boolean isDelete = uploadFile.delete();
                if (!isDelete) {
                    LOGGER.error("临时文件删除失败:" + filePath);
                }
            }
        } catch (Exception e) {
            LOGGER.error("文件上传失败:" + e.getMessage());
            uploadStatus = false;
        }
        return uploadStatus;
    }

    public Boolean uploadMergeclassFileWithEnv(String filePath, String projectName, String branch, String commit, String
            env) {
        Boolean uploadStatus;
        String todayStr = DateUtils.getTodayStr();
        String path = s3Util.coverageTypeMapping(CoverageTypeEnum.SERVER.getType()) + "coverage_data/" + env + "/" + projectName + "/" + branch + "/" + todayStr + "/" + commit + "/"+"mergeclass/";
        try {
            File uploadFile = new File(filePath);
            uploadStatus = s3UtilBiz.putObjectFileV2(uploadFile, path);
            if (uploadStatus) {
                LOGGER.info("文件上传成功, 文件保存至:" + path + uploadFile.getName());
                // 删除临时文件
                boolean isDelete = uploadFile.delete();
                if (!isDelete) {
                    LOGGER.error("临时文件删除失败:" + filePath);
                }
            }
        } catch (Exception e) {
            LOGGER.error("文件上传失败:" + e.getMessage());
            uploadStatus = false;
        }
        return uploadStatus;
    }

    @Override
    public Boolean uploadExecFileWithEnvV2(String filePath, String projectName, String branch, String commit, String env) {
        return uploadExecFileWithEnvV2(filePath, projectName, branch, commit, env, true);
    }
    public Boolean uploadExecFileWithEnvV2(String filePath, String projectName, String branch, String commit, String env, boolean deleteLocalFile){
        Boolean uploadStatus;
        String todayStr = DateUtils.getTodayStr();
        String path = s3Util.coverageTypeMapping(CoverageTypeEnum.SERVER.getType()) + "coverage_data/" + env + "/" + projectName + "/" + branch + "/" + todayStr + "/" + commit + "/exec/";
        try {
            File uploadFile = new File(filePath);
            uploadStatus = s3UtilBiz.putObjectFileV2(uploadFile, path);
            if (uploadStatus) {
                LOGGER.info("文件上传成功, 文件保存至:" + path + uploadFile.getName());
                if (deleteLocalFile) {
                    // 删除临时文件
                    boolean isDelete = uploadFile.delete();
                    if (!isDelete) {
                        LOGGER.error("临时文件删除失败:" + filePath);
                    }
                }
            }
        } catch (Exception e) {
            LOGGER.error("文件上传失败:" + e.getMessage());
            uploadStatus = false;
        }
        return uploadStatus;
    }


    @Override
    public Boolean uploadGcdaZipWithEnv(String localFilePath, String applicationId, String version, String
            buildNum, String uuid, int coverageType, String env) {
        Boolean uploadStatus;
        String path = s3Util.coverageTypeMapping(coverageType) + "coverage_data/" + applicationId + "/" + version + "/" + buildNum + "/gcda/" + uuid + "/";
        try {
            File uploadFile = new File(localFilePath);
            uploadStatus = s3UtilBiz.putObjectFileWithEnv(uploadFile, path, env);
            if (uploadStatus) {
                LOGGER.info("文件上传成功, 文件保存至:" + path + uploadFile.getName());
                // 删除临时文件
                boolean isDelete = uploadFile.delete();
                if (!isDelete) {
                    LOGGER.error("临时文件删除失败:" + localFilePath);
                }
            }
        } catch (Exception e) {
            LOGGER.error("文件上传失败:" + e.getMessage());
            uploadStatus = false;
        }
        return uploadStatus;
    }

    @Override
    public Boolean uploadGcnoZipWithEnv(String localFilePath, String applicationId, String version, String buildNum,
                                        int coverageType, String env) {
        Boolean uploadStatus;
        String path = s3Util.coverageTypeMapping(coverageType) + "coverage_data/" + applicationId + "/" + version + "/" + buildNum + "/gcno/";
        try {
            File uploadFile = new File(localFilePath);
            uploadStatus = s3UtilBiz.putObjectFileWithEnv(uploadFile, path, env);
            if (uploadStatus) {
                LOGGER.info("文件上传成功, 文件保存至:" + path + uploadFile.getName());
                // 删除临时文件
                boolean isDelete = uploadFile.delete();
                if (!isDelete) {
                    LOGGER.error("临时文件删除失败:" + localFilePath);
                }
            }
        } catch (Exception e) {
            LOGGER.error("文件上传失败:" + e.getMessage());
            uploadStatus = false;
        }
        return uploadStatus;
    }

    @Override
    public Boolean uploadSrcOrClassZipWithEnv(String localFilePath, String applicationId, String version, String
            buildNum, String variantName, String env, String fileType) {
        Boolean uploadStatus;
        String path = s3Util.coverageTypeMapping(CoverageTypeEnum.ANDROID.getType()) + "coverage_data/" + applicationId + "/" + version + "/" + buildNum + "/" + fileType + "/";
        try {
            File uploadFile = new File(localFilePath);
            uploadStatus = s3UtilBiz.putObjectFileWithEnv(uploadFile, path, env);
            if (uploadStatus) {
                LOGGER.info("文件上传成功, 文件保存至:" + path + uploadFile.getName());
                // 删除临时文件
                boolean isDelete = uploadFile.delete();
                if (!isDelete) {
                    LOGGER.error("临时文件删除失败:" + localFilePath);
                }
            }
        } catch (Exception e) {
            LOGGER.error("文件上传失败:" + e.getMessage());
            uploadStatus = false;
        }
        return uploadStatus;
    }

    @Override
    public Boolean uploadObjectWithEnv(S3UploadDataReq s3UploadDataReq) {
        Boolean uploadStatus = true;
        //参数处理
        int coverageType = s3UploadDataReq.getCoverageType();
        String projectName = s3UploadDataReq.getProjectName();
        String content = s3UploadDataReq.getContent();
        String fileName = s3UploadDataReq.getFileName();
        String env = s3UploadDataReq.getEnv();
        String objectName = s3Util.coverageTypeMapping(coverageType) + "coverage_data/" + env + "/" + projectName + "/" + fileName;
        try {
            uploadStatus = s3UtilBiz.putObjectWithEnv(content, objectName, TestEnvEnum.STAGING.getEnv());
        } catch (Exception e) {
            LOGGER.error("文件上传失败:" + e.getMessage());
            uploadStatus = false;
        }
        return uploadStatus;
    }

    @Override
    public Boolean uploadObject(S3UploadDataReq s3UploadDataReq) {
        Boolean uploadStatus = true;
        //参数处理
        int coverageType = s3UploadDataReq.getCoverageType();
        String projectName = s3UploadDataReq.getProjectName();
        String content = s3UploadDataReq.getContent();
        String fileName = s3UploadDataReq.getFileName();
        String env = s3UploadDataReq.getEnv();
        String path = s3Util.coverageTypeMapping(coverageType) + "coverage_data/" + env + "/"+ projectName + "/" + fileName;
        try {
            uploadStatus = s3UtilBiz.putObject(content, path);
        } catch (Exception e) {
            LOGGER.error("文件上传失败:" + e.getMessage());
            uploadStatus = false;
        }
        return uploadStatus;
    }

    @Override
    public List<String> getObjectListWithEnv(String projectName, int coverageType, String beginTime, String
            endTime, String projectVersion, String env) {
        List<String> objectList = Lists.newArrayList();
        List<String> objectListRes = Lists.newArrayList();
        String filePrefix;
        try {
            if (projectVersion == null) {
                filePrefix = s3Util.coverageTypeMapping(coverageType) + "coverage_data/" + env + "/" + projectName;
            } else {
                filePrefix = s3Util.coverageTypeMapping(coverageType) + "coverage_data/" + env + "/" + projectName + "/" + projectVersion + "/";
            }
            // 解析查询时间段
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
            String[] beginTimeArr = beginTime.split("-");
            String beginTimeStr = beginTimeArr[0].replace("/", "-") + " " + beginTimeArr[1];
            String[] endTimeArr = endTime.split("-");
            String endTimeStr = endTimeArr[0].replace("/", "-") + " " + endTimeArr[1];
            Date beginTimeDate = sdf.parse(beginTimeStr);
            Date endTimeDate = sdf.parse(endTimeStr);

            //filePrefix = "data/braavos";
            //筛选包含指定时间的object
            objectList = s3UtilBiz.getObjectListWithTestEnv(filePrefix, TestEnvEnum.STAGING.getEnv());
            for (String object : objectList) {
                //处理时间：上传文件格式2likp5vr-$2020-11-30-18$-upload normally.json，开始结束时间2020/12/03-10:00
                String filterTime = object.split("\\$")[1] + ":00";
                StringBuffer buffer = new StringBuffer(filterTime);
                int indexNum = filterTime.lastIndexOf("-");
                buffer.replace(indexNum, indexNum + 1, " ");
                String uploadTime = buffer.toString();
                Date uploadTimeDate = sdf.parse(uploadTime);
                if (uploadTimeDate.getTime() >= beginTimeDate.getTime() && endTimeDate.getTime() >= uploadTimeDate.getTime()) {
                    objectListRes.add(object);
                }
            }
        } catch (Exception e) {
            LOGGER.error("文件查询失败:" + e.getMessage());
        }
        return objectListRes;
    }

    @Override
    public List<String> getObjectListWithEnvV2(String projectName, int coverageType, String beginTime, String
            endTime, String projectVersion, String env) {
        List<String> objectList = Lists.newArrayList();
        List<String> objectListRes = Lists.newArrayList();
        String filePrefix;
        try {
            if (projectVersion == null) {
                filePrefix = s3Util.coverageTypeMapping(coverageType) + "coverage_data/" + env + "/" + projectName;
            } else {
                filePrefix = s3Util.coverageTypeMapping(coverageType) + "coverage_data/" + env + "/" + projectName + "/" + projectVersion + "/";
            }
            // 解析查询时间段
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
            String[] beginTimeArr = beginTime.split("-");
            String beginTimeStr = beginTimeArr[0].replace("/", "-") + " " + beginTimeArr[1];
            String[] endTimeArr = endTime.split("-");
            String endTimeStr = endTimeArr[0].replace("/", "-") + " " + endTimeArr[1];
            Date beginTimeDate = sdf.parse(beginTimeStr);
            Date endTimeDate = sdf.parse(endTimeStr);

            //filePrefix = "data/braavos";
            //筛选包含指定时间的object
            objectList = s3UtilBiz.getObjectListV2(filePrefix);
            for (String object : objectList) {
                //处理时间：上传文件格式2likp5vr-$2020-11-30-18$-upload normally.json，开始结束时间2020/12/03-10:00
                String filterTime = object.split("\\$")[1] + ":00";
                StringBuffer buffer = new StringBuffer(filterTime);
                int indexNum = filterTime.lastIndexOf("-");
                buffer.replace(indexNum, indexNum + 1, " ");
                String uploadTime = buffer.toString();
                Date uploadTimeDate = sdf.parse(uploadTime);
                if (uploadTimeDate.getTime() >= beginTimeDate.getTime() && endTimeDate.getTime() >= uploadTimeDate.getTime()) {
                    objectListRes.add(object);
                }
            }
        } catch (Exception e) {
            LOGGER.error("文件查询失败:" + e.getMessage());
        }
        return objectListRes;
    }

    /**
     * 安卓端和 iOS 端使用
     * 因为安卓端和iOS端当插件被集成到包中
     * 数据都会发送到线上
     *
     * 当覆盖率平台服务，在本地或测试环境调试时，还是需要到测试环境去拉数据
     */
    @Override
    public List<String> searchObjectListWithEnv(int coverageType, String prefix, String testEnv) {
        String fullPrefix = s3Util.coverageTypeMapping(coverageType) + "coverage_data/" + prefix;
        return s3UtilBiz.getObjectListWithTestEnv(fullPrefix, testEnv);
    }

    /**
     * 服务端使用
     * 拉取数据时，需要拼接环境前缀
     */
    @Override
    public List<String> searchObjectListWithEnvV2(int coverageType, String prefix, String testEnv) {
        String fullPrefix = s3Util.coverageTypeMapping(coverageType) + "coverage_data/" + testEnv + "/" + prefix;
        return s3UtilBiz.getObjectListV2(fullPrefix);
    }

    @Override
    public void batchDownloadFileWithEnv(List<String> objectNameList, String localDirPath, String testEnv) {
        try {
            objectNameList.forEach(objectUrl -> {
                String fileName = getFileNameInS3(objectUrl);
                // 拼接本地文件路径
                String localFilePath = localDirPath + "/" + fileName;
                s3UtilBiz.downloadObjectWithEnv(objectUrl, localFilePath, testEnv);
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void batchDownloadFileWithEnvAndCommit(List<String> objectNameList, String localDirPath, String testEnv) {
        try {
            objectNameList.forEach(objectUrl -> {
                String fileName = getFileNameInS3(objectUrl);
                String commit= fileName.split("-")[0];
                // 拼接本地文件路径
                String localFilePath = localDirPath + "/" +commit+"/"+ fileName;
                log.info("存储s3下载的classes.zip文件的路径 " + localFilePath);
                s3UtilBiz.downloadObjectV2(objectUrl, localFilePath);
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 获取文件的名字，直接通过 / 进行切割，最后一个就是文件的名字
     *
     * @param objectUrl s3 的 objectUrl
     * @return 文件的名字
     */
    private String getFileNameInS3(String objectUrl) {
        String[] pathArray = objectUrl.split("/");
        return pathArray[pathArray.length - 1];
    }
}
