package com.maoyan.coverage.admin.biz.job;

import com.maoyan.coverage.admin.common.utils.ShellUtils;
import com.maoyan.coverage.admin.domain.enums.CoverageTypeEnum;
import com.maoyan.coverage.admin.domain.enums.TestEnvEnum;
import com.maoyan.coverage.admin.domain.model.data.BelowThresholdFileModel;
import com.maoyan.coverage.admin.domain.model.data.DataIndicatorsModel;
import com.maoyan.coverage.admin.domain.model.data.IOSBuildResultDataModel;
import com.maoyan.coverage.admin.domain.model.job.JobBuildModel;
import com.maoyan.coverage.admin.domain.model.job.WorkSpacePathModel;
import com.maoyan.coverage.admin.domain.model.job.config.IOSTestConfigModel;
import com.maoyan.coverage.admin.domain.model.job.s3.SearchAndroidFileModel;
import com.maoyan.coverage.admin.domain.model.job.s3.SearchIOSFileModel;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import com.opencsv.CSVParser;
import com.opencsv.CSVReader;
import java.math.BigDecimal;
import java.io.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Service
public class IOSJobBiz extends BaseJobBiz {

    public void build(JobBuildModel<IOSTestConfigModel> jobBuildModel) {
        System.out.println("ios 端Job");

        Integer reportType = jobBuildModel.getBaseConfig().getReportType();
        if(reportType == 1){
            // 全量
            downloadFile(jobBuildModel);
            //上传报告
            String path = uploadReportFile(jobBuildModel);

            //执行脚本，生成html报告
            ShellUtils gcovHtml = new ShellUtils();
            gcovHtml.gcovrHtml(path);
            //执行脚本，生成csv报告
            ShellUtils gcovCsv = new ShellUtils();
            gcovCsv.gcovrCsv(path);

            IOSBuildResultDataModel buildResultDataModel = new IOSBuildResultDataModel();
            buildResultDataModel.setCommit("这是一条测试的commit");
            buildResultDataModel.setReportUrl(path);
            ArrayList<DataIndicatorsModel> dataIndicators = new ArrayList<>();

            DataIndicatorsModel dataIndicatorsModelLine = new DataIndicatorsModel();
            DataIndicatorsModel dataIndicatorsModelBranch = new DataIndicatorsModel();

            dataIndicatorsModelLine = CSVReadCovAndTotal(path + "/coverage.csv","LINE");
            dataIndicatorsModelBranch = CSVReadCovAndTotal(path + "/coverage.csv","BRANCH");

            ArrayList<BelowThresholdFileModel> belowThresholdFilesLine = new ArrayList<>();
            ArrayList<BelowThresholdFileModel> belowThresholdFilesBranch = new ArrayList<>();

            belowThresholdFilesLine = csvReadAll(path,"LINE");
            belowThresholdFilesBranch = csvReadAll(path,"BRANCH");

            dataIndicatorsModelLine.setBelowThresholdFiles(belowThresholdFilesLine);
            dataIndicatorsModelBranch.setBelowThresholdFiles(belowThresholdFilesBranch);
            //行指标及低于阀值文件
            dataIndicators.add(dataIndicatorsModelLine);
            //分支指标及低于阀值文件
            dataIndicators.add(dataIndicatorsModelBranch);
            buildResultDataModel.setDataIndicators(dataIndicators);
            //数据构造完成调用
            buildSuccess(jobBuildModel,buildResultDataModel);
        }

        if(reportType == 0){
            //增量
            downloadFile(jobBuildModel);
            //上传报告
            String path = uploadReportFile(jobBuildModel);
            //执行脚本，生成info中间文件
            ShellUtils lcovInfo = new ShellUtils();
            lcovInfo.lcovInfo(path);
            //执行脚本，生成覆盖率报告
            ShellUtils lcovHtml = new ShellUtils();
            lcovHtml.lcovHtml(path);
            IOSBuildResultDataModel buildResultDataModel = new IOSBuildResultDataModel();
            buildResultDataModel.setCommit("这是一条测试的commit");
            buildResultDataModel.setReportUrl(path);
            ArrayList<DataIndicatorsModel> dataIndicators = new ArrayList<>();

            DataIndicatorsModel dataIndicatorsModelLine = new DataIndicatorsModel();
            DataIndicatorsModel dataIndicatorsModelBranch = new DataIndicatorsModel();
            dataIndicatorsModelLine = incrementCount(path + "/result.info","LINE");
            dataIndicatorsModelBranch = incrementCount(path + "/result.info","BRANCH");

            ArrayList<BelowThresholdFileModel> belowThresholdFilesLine = new ArrayList<>();
            ArrayList<BelowThresholdFileModel> belowThresholdFilesBranch = new ArrayList<>();

            belowThresholdFilesLine = incrementalFilterFiles(path,"LINE");
            belowThresholdFilesBranch = incrementalFilterFiles(path,"BRANCH");

            dataIndicatorsModelLine.setBelowThresholdFiles(belowThresholdFilesLine);
            dataIndicatorsModelBranch.setBelowThresholdFiles(belowThresholdFilesBranch);
            //行指标及低于阀值文件
            dataIndicators.add(dataIndicatorsModelLine);
            //分支指标及低于阀值文件
            dataIndicators.add(dataIndicatorsModelBranch);
            buildResultDataModel.setDataIndicators(dataIndicators);
            //数据构造完成调用
            buildSuccess(jobBuildModel,buildResultDataModel);
        }

    }


    private void downloadFile(JobBuildModel<IOSTestConfigModel> jobBuildModel) {
        IOSTestConfigModel iosTestConfigModel = jobBuildModel.getTestConfig();
        WorkSpacePathModel workSpacePathModel = jobBuildModel.getWorkSpacePath();

        // 构建搜索对象
        SearchIOSFileModel searchGcdaFileModel = new SearchIOSFileModel.Builder()
                .addProjectVersion(iosTestConfigModel.getProjectVersion())
                .addTestVersion(iosTestConfigModel.getTestVersion())
                .addFileType("gcda")
                .build();

        SearchIOSFileModel searchGcnoFileModel = new SearchIOSFileModel.Builder()
                .addProjectVersion(iosTestConfigModel.getProjectVersion())
                .addTestVersion(iosTestConfigModel.getTestVersion())
                .addFileType("gcno")
                .build();

        List<String> gcdaFileList = screenFile(searchGcdaFileModel);

        List<String> gcnoFileList = screenFile(searchGcnoFileModel);

        s3Biz.batchDownloadFileWithEnv(gcdaFileList, workSpacePathModel.getDataWorkSpacePath(), TestEnvEnum.STAGING.getEnv());
        s3Biz.batchDownloadFileWithEnv(gcnoFileList, workSpacePathModel.getDataWorkSpacePath(), TestEnvEnum.STAGING.getEnv());
    }

    private List<String> screenFile(SearchIOSFileModel searchIOSFileModel) {
        String prefix = searchIOSFileModel.getMaoyanIOSProjectName() + "/" + searchIOSFileModel.getTestVersion() + "/" + searchIOSFileModel.getProjectVersion() + "/" + searchIOSFileModel.getFileType();
        // TODO 目前iOS端的文件还都在s3测试环境
        return s3Biz.searchObjectListWithEnv(CoverageTypeEnum.iOS.getType(), prefix, TestEnvEnum.STAGING.getEnv());
    }

    /**
     * 全量部分
     * 收集低于阀值的覆盖率数据
     */
    public ArrayList<BelowThresholdFileModel> csvReadAll(String path, String flag) {
        if (path == null || flag == null) {
            return null;
        }

        BigDecimal linePercent = new BigDecimal("0");//行覆盖率
        BigDecimal branchPercent = new BigDecimal("0");//分支覆盖率
        BigDecimal threshold = new BigDecimal("0.6");//阀值
        ArrayList<String> lineRecorderList = new ArrayList<String>();
        ArrayList<String> branchRecorderList = new ArrayList<String>();
        ArrayList<BelowThresholdFileModel> belowThresholdFilesLine = new ArrayList<BelowThresholdFileModel>();
        ArrayList<BelowThresholdFileModel> belowThresholdFilesBranch = new ArrayList<BelowThresholdFileModel>();
        //统计低于阀值的行和分支文件名
        BelowThresholdFileModel belowThresholdFileModelLine = new BelowThresholdFileModel();
        BelowThresholdFileModel belowThresholdFileModelBranch = new BelowThresholdFileModel();

        try {
            DataInputStream in = new DataInputStream(new FileInputStream(new File(path)));
            CSVReader csvReader = new CSVReader
                    (new InputStreamReader(in, "UTF-8"),
                            CSVParser.DEFAULT_SEPARATOR,
                            CSVParser.DEFAULT_QUOTE_CHARACTER,
                            CSVParser.DEFAULT_ESCAPE_CHARACTER,
                            0);
            String[] dataRow;//每一行记录
            //去掉表头
            if ((dataRow = csvReader.readNext()) != null) {
                int length = dataRow.length;
                while ((dataRow = csvReader.readNext()) != null) {
                    if (dataRow.length == 0) {
                        break;
                    }
                    //输出整个列表
                    //System.out.println(Arrays.deepToString(dataRow));
                    linePercent = checkIsEmpty(dataRow[3]);
                    if (linePercent.compareTo(threshold) == -1) {
                        if (dataRow[0] != null) {
                            lineRecorderList.add(dataRow[0]);
                            belowThresholdFileModelLine.setName(dataRow[0]);
                            if (dataRow[1] != null || dataRow[2] != null) {
                                belowThresholdFileModelLine.setTotal(Integer.valueOf(dataRow[1]));
                                belowThresholdFileModelLine.setCovered(Integer.valueOf(dataRow[2]));
                            }
                        }
                        belowThresholdFilesLine.add(belowThresholdFileModelLine);
                    }
                    branchPercent = checkIsEmpty(dataRow[length - 1]);
                    if (branchPercent.compareTo(threshold) == -1) {
                        if (dataRow[0] != null) {
                            branchRecorderList.add(dataRow[0]);
                            belowThresholdFileModelBranch.setName(dataRow[0]);
                            if (dataRow[4] != null || dataRow[5] != null) {
                                belowThresholdFileModelBranch.setTotal(Integer.valueOf(dataRow[4]));
                                belowThresholdFileModelBranch.setCovered(Integer.valueOf(dataRow[5]));
                            }
                        }
                        belowThresholdFilesBranch.add(belowThresholdFileModelBranch);
                    }
                }
            }
            csvReader.close();
            if (flag.compareTo("LINE") == 0) {
                lineRecorderList = dataLogger(lineRecorderList, path);
                int i = 0;
                for (String aa : lineRecorderList) {
                    belowThresholdFilesLine.get(i).setUrl(path + aa);
                    i += 1;
                }
                return belowThresholdFilesLine;
            } else if (flag.compareTo("BRANCH") == 0) {
                branchRecorderList = dataLogger(branchRecorderList, path);
                int i = 0;
                for (String aa : branchRecorderList) {
                    belowThresholdFilesBranch.get(i).setUrl(path + aa);
                    i += 1;
                }
                return belowThresholdFilesBranch;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 全量部分
     * 记录器
     * 用来记录低于阀值的行或分支
     */
    public ArrayList<String> dataLogger(ArrayList<String> fileList, String filePath) {
        if (fileList.size() == 0 || filePath == null) {
            return null;
        }

        ArrayList<String> resFilesList = new ArrayList<String>();
        File file = new File(filePath);

        if (!file.exists()) {
            System.out.println("FilePath is error");
            return null;
        }
        String[] files = file.list();

        resFilesList.add("example-html-details.html");
        for (String fileName : fileList) {
            for (String resFile : files) {
                if (resFile.indexOf("example-html-details." + fileName) != -1) {
                    resFilesList.add(resFile);
                    continue;
                }
            }
        }
        return resFilesList;
    }

    /**
     * 全量部分
     * 判断数据是否为空
     */
    public BigDecimal checkIsEmpty(String data) {
        if (data.equals("")) {
            return new BigDecimal("0");
        }
        return new BigDecimal(data);
    }


    /**
     * 全量部分
     * 获取总行数、总分支数、行覆盖数、分支覆盖数
     */
    public DataIndicatorsModel CSVReadCovAndTotal(String path, String flag) {
        if (path == null || flag == null) {
            return null;
        }

        BigDecimal lineTotal = new BigDecimal("0");//总行数
        BigDecimal lineCovered = new BigDecimal("0");//行覆盖数
        BigDecimal branchTotal = new BigDecimal("0");//总分支数
        BigDecimal branchCovered = new BigDecimal("0");//分支覆盖数
        DataIndicatorsModel dataIndicatorsModelsLine = new DataIndicatorsModel();
        DataIndicatorsModel dataIndicatorsModelsBranch = new DataIndicatorsModel();

        try {
            DataInputStream in = new DataInputStream(new FileInputStream(new File(path)));
            CSVReader csvReader = new CSVReader
                    (new InputStreamReader(in, "UTF-8"),
                            CSVParser.DEFAULT_SEPARATOR,
                            CSVParser.DEFAULT_QUOTE_CHARACTER,
                            CSVParser.DEFAULT_ESCAPE_CHARACTER,
                            0);
            String[] dataRow;//每一行记录

            //去掉表头
            if ((dataRow = csvReader.readNext()) != null) {
                while ((dataRow = csvReader.readNext()) != null) {
                    //统计总行数
                    lineTotal = tallyRegister(dataRow[1], lineTotal);
                    //统计行覆盖数
                    lineCovered = tallyRegister(dataRow[2], lineCovered);
                    //统计分支数
                    branchTotal = tallyRegister(dataRow[4], branchTotal);
                    //统计分支覆盖数
                    branchCovered = tallyRegister(dataRow[5], branchCovered);
                    //输出整个列表
                    //System.out.println(Arrays.deepToString(dataRow));
                }
            }
            csvReader.close();
            if (flag.compareTo("LINE") == 0) {
                dataIndicatorsModelsLine.setKey("LINE");
                dataIndicatorsModelsLine.setName("行覆盖率");
                dataIndicatorsModelsLine.setCovered(lineCovered.intValue());
                dataIndicatorsModelsLine.setTotal(lineTotal.intValue());
                return dataIndicatorsModelsLine;
            } else if (flag.compareTo("BRANCH") == 0) {
                dataIndicatorsModelsBranch.setKey("BRANCH");
                dataIndicatorsModelsBranch.setName("分支覆盖率");
                dataIndicatorsModelsBranch.setCovered(branchCovered.intValue());
                dataIndicatorsModelsBranch.setTotal(branchTotal.intValue());
                return dataIndicatorsModelsBranch;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }


    /**
     * 全量部分
     * 计数器
     * 用来计算总行数、总分支数、行覆盖数、分支覆盖数
     */
    public BigDecimal tallyRegister(String data, BigDecimal lineTotal) {
        if (data.equals("")) {
            data = "0";
        }
        BigDecimal tmpLineTotal = new BigDecimal(data);
        lineTotal = lineTotal.add(tmpLineTotal);
        return lineTotal;
    }

    /**
     * 增量部分
     * 从每行文件中筛选数字
     * @param data
     * @return
     */
    public static BigDecimal filterNumbers(String data){
        if(data == null){return null;}
        String regEx="[^0-9]";
        Pattern pattern = Pattern.compile(regEx);
        Matcher matcher = pattern.matcher(data);
        return new BigDecimal(matcher.replaceAll(""));
    }


    /**
     * 增量部分
     * 统计总行数、总分支数、行覆盖数、分支覆盖数
     * @param
     *
     */
    public DataIndicatorsModel incrementCount(String path, String flag) {
        if (path == null || flag == null) {
            return null;
        }
        File file = new File(path);
        BufferedReader reader = null;
        try {
            reader = new BufferedReader(new FileReader(file));
            String fileLineData = null;
            BigDecimal lineNum = new BigDecimal("0");//行数
            BigDecimal lineCoveredNum = new BigDecimal("0");//行覆盖数
            BigDecimal lineTotal = new BigDecimal("0");//总行数
            BigDecimal lineCovered = new BigDecimal("0");//总行覆盖数
            BigDecimal branchNum = new BigDecimal("0");//分支数
            BigDecimal branchCoveredNum = new BigDecimal("0");//分支覆盖数
            BigDecimal branchTotal = new BigDecimal("0");//总分支数
            BigDecimal branchCovered = new BigDecimal("0");//总分支覆盖数
            DataIndicatorsModel dataIndicatorsModelsLine = new DataIndicatorsModel();
            DataIndicatorsModel dataIndicatorsModelsBranch = new DataIndicatorsModel();

            Integer index = -1;
            while ((fileLineData = reader.readLine()) != null) {

                //统计行数和总行数
                index = fileLineData.indexOf("LF");
                if(index != -1){
                    lineNum = filterNumbers(fileLineData);
                    lineTotal = lineTotal.add(lineNum);
                }

                //统计行覆盖率和总行覆盖率
                index = fileLineData.indexOf("LH");
                if(index != -1){
                    lineCoveredNum = filterNumbers(fileLineData);
                    lineCovered = lineCovered.add(lineCoveredNum);
                }

                //统计分支数和总分支数
                index = fileLineData.indexOf("BRF");
                if(index != -1){
                    branchNum = filterNumbers(fileLineData);
                    branchTotal = branchTotal.add(branchNum);
                }

                //统计分支覆盖数和总分支覆盖数
                index = fileLineData.indexOf("BRH");
                if(index != -1){
                    branchCoveredNum = filterNumbers(fileLineData);
                    branchCovered = branchCovered.add(branchCoveredNum);
                }

            }
            reader.close();

            if (flag.compareTo("LINE") == 0) {
                dataIndicatorsModelsLine.setKey("LINE");
                dataIndicatorsModelsLine.setName("行覆盖率");
                dataIndicatorsModelsLine.setCovered(lineCovered.intValue());
                dataIndicatorsModelsLine.setTotal(lineTotal.intValue());
                return dataIndicatorsModelsLine;
            } else if (flag.compareTo("BRANCH") == 0) {
                dataIndicatorsModelsBranch.setKey("BRANCH");
                dataIndicatorsModelsBranch.setName("分支覆盖率");
                dataIndicatorsModelsBranch.setCovered(branchCovered.intValue());
                dataIndicatorsModelsBranch.setTotal(branchTotal.intValue());
                return dataIndicatorsModelsBranch;
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e1) {
                }
            }
        }
        return null;
    }

    /**
     * 增量部分
     * 筛选低于阀值的行覆盖文件和分支覆盖文件
     * @param path
     * @param flag
     */
    public ArrayList<BelowThresholdFileModel> incrementalFilterFiles(String path, String flag) {
        if (path == null || flag == null) {
            return null;
        }
        File file = new File(path);
        BufferedReader reader = null;
        try {
            reader = new BufferedReader(new FileReader(file));
            String fileLineData = null;
            BigDecimal lineNum = new BigDecimal("0");//行数
            BigDecimal lineCoveredNum = new BigDecimal("0");//行覆盖数
            BigDecimal branchNum = new BigDecimal("0");//分支数
            BigDecimal branchCoveredNum = new BigDecimal("0");//分支覆盖数

            BigDecimal linePercent = new BigDecimal("0");//行覆盖率
            BigDecimal branchPercent = new BigDecimal("0");//分支覆盖率
            BigDecimal threshold = new BigDecimal("0.3");//阀值
            ArrayList<String> lineRecorderList = new ArrayList<String>();
            ArrayList<String> branchRecorderList = new ArrayList<String>();
            ArrayList<BelowThresholdFileModel> belowThresholdFilesLine = new ArrayList<BelowThresholdFileModel>();
            ArrayList<BelowThresholdFileModel> belowThresholdFilesBranch = new ArrayList<BelowThresholdFileModel>();
            //统计低于阀值的行和分支文件名
            BelowThresholdFileModel belowThresholdFileModelLine = new BelowThresholdFileModel();
            BelowThresholdFileModel belowThresholdFileModelBranch = new BelowThresholdFileModel();

            Integer index = -1;
            String belowThresholdFileName = null;

            while ((fileLineData = reader.readLine()) != null) {
                if(fileLineData.equals("end_of_record")){
                    linePercent = lineCoveredNum.divide(lineNum,3,BigDecimal.ROUND_HALF_UP);
                    if(branchNum.compareTo(BigDecimal.ZERO) == 0){
                        branchPercent = BigDecimal.ZERO;
                    }else {
                        branchPercent = branchCoveredNum.divide(branchNum,3,BigDecimal.ROUND_HALF_UP);
                    }
                    if(linePercent.compareTo(threshold) == -1){
                        //低于阀值行覆盖率文件记录
                        belowThresholdFileModelLine.setName(belowThresholdFileName);
                        belowThresholdFileModelLine.setTotal(lineNum.intValue());
                        belowThresholdFileModelLine.setCovered(lineCoveredNum.intValue());
                        //需要补充url

                        belowThresholdFilesLine.add(belowThresholdFileModelLine);
                    }
                    if(branchPercent.compareTo(threshold) == -1){
                        //低于阀值分支覆盖率文件记录
                        belowThresholdFileModelBranch.setName(belowThresholdFileName);
                        belowThresholdFileModelBranch.setTotal(branchNum.intValue());
                        belowThresholdFileModelBranch.setCovered(branchCoveredNum.intValue());
                        //需要补充url

                        belowThresholdFilesBranch.add(belowThresholdFileModelBranch);
                    }
                    //数据还原
                    belowThresholdFileName = null;
                    lineNum = BigDecimal.ZERO;
                    lineCoveredNum = BigDecimal.ZERO;
                    branchNum = BigDecimal.ZERO;
                    branchCoveredNum = BigDecimal.ZERO;
                    linePercent = BigDecimal.ZERO;
                    branchPercent = BigDecimal.ZERO;
                    continue;
                }
                //文件名
                index = fileLineData.indexOf("SF");
                if(index != -1){
                    belowThresholdFileName = fileLineData.substring(2);
                }
                //统计行数
                index = fileLineData.indexOf("LF");
                if(index != -1){
                    lineNum = filterNumbers(fileLineData);
                }
                //统计行覆盖率
                index = fileLineData.indexOf("LH");
                if(index != -1){
                    lineCoveredNum = filterNumbers(fileLineData);
                }
                //统计分支数
                index = fileLineData.indexOf("BRF");
                if(index != -1){
                    branchNum = filterNumbers(fileLineData);
                }
                //统计分支覆盖数
                index = fileLineData.indexOf("BRH");
                if(index != -1){
                    branchCoveredNum = filterNumbers(fileLineData);
                }
            }
            reader.close();
            if (flag.compareTo("LINE") == 0) {

                return belowThresholdFilesLine;
            }else if (flag.compareTo("BRANCH") == 0) {

                return belowThresholdFilesLine;
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException e1) { }
            }
        }
        return null;
    }


}

