package com.maoyan.coverage.admin.biz.job;

import com.maoyan.coverage.admin.common.exception.UserInputException;
import com.maoyan.coverage.admin.common.utils.ZipUtils;
import com.maoyan.coverage.admin.domain.enums.CoverageTypeEnum;
import com.maoyan.coverage.admin.domain.enums.TestEnvEnum;
import com.maoyan.coverage.admin.domain.model.job.JobBuildModel;
import com.maoyan.coverage.admin.domain.model.job.ProjectInfoModel;
import com.maoyan.coverage.admin.domain.model.job.WorkSpacePathModel;
import com.maoyan.coverage.admin.domain.model.job.config.AndroidTestConfigModel;
import com.maoyan.coverage.admin.domain.model.job.path.AndroidWorkSpacePathModel;
import com.maoyan.coverage.admin.domain.model.job.s3.EcFileNameModel;
import com.maoyan.coverage.admin.domain.model.job.s3.SearchAndroidFileModel;
import com.maoyan.coverage.admin.domain.model.jobmanage.JobBaseConfigModel;
import com.maoyan.coverage.admin.domain.model.job.result.AndroidJobBuildResultModel;
import com.meituan.jacoco.report.MtJacocoReport;
import com.meituan.jacoco.report.model.BranchCodePath;
import com.meituan.jacoco.report.model.JobBuildPath;
import org.jacoco.core.analysis.IBundleCoverage;
import org.joda.time.LocalDateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.io.*;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.List;


@Service
public class AndroidJobBiz extends BaseJobBiz {

    private Logger logger = LoggerFactory.getLogger(AndroidJobBiz.class);

    /**
     * 安卓端构建逻辑，当用户点击立即构建时或者定时构建到时间时会出发此逻辑
     *
     * @param jobBuildModel 安卓端构建逻辑中会用到的参数
     *                      {@link JobBuildModel} 构建逻辑中会使用到的参数
     *                      包括：{@link WorkSpacePathModel}: 工作区路径对象，包括代码存放位置，本地报告存放位置，data存放位置
     *                      {@link JobBaseConfigModel}: Job 的基础配置
     *                      {@link ProjectInfoModel}: 项目的配置信息
     *                      {@link AndroidTestConfigModel}: 安卓端会使用到的对象
     *                      buildHistoryId: 构建历史Id
     */
    public void build(JobBuildModel<AndroidTestConfigModel> jobBuildModel) throws IOException {
        long startTime = System.currentTimeMillis();
        AndroidWorkSpacePathModel androidWorkSpacePathModel = downloadFile(jobBuildModel);

        String ecPath = androidWorkSpacePathModel.getEcFilePath();
        String clsPath = androidWorkSpacePathModel.getClassPath();
        String srcPath = androidWorkSpacePathModel.getSrcPath();
        String dstPath = jobBuildModel.getWorkSpacePath().getDataWorkSpacePath() + "src";
        ZipUtils.unzip(srcPath, dstPath);
        String outputPath = jobBuildModel.getWorkSpacePath().getReportWorkSpacePath();
        String commitPath = androidWorkSpacePathModel.getCommitPath();

        JobBuildPath jobBuildPath = new JobBuildPath();
        jobBuildPath.setEcPath(ecPath);
        jobBuildPath.setClsPath(clsPath);
        jobBuildPath.setSrcPath(dstPath);
        jobBuildPath.setOutputPath(outputPath);

        Integer reportType = jobBuildModel.getBaseConfig().getReportType();
        String commitId = loadContentByPath(commitPath);

        MtJacocoReport mtJacocoReport = new MtJacocoReport();
        if (reportType == 1) {
            // 全量
            IBundleCoverage bundleCoverage = mtJacocoReport.generate(jobBuildPath);
            AndroidJobBuildResultModel androidJobBuildResultModel = new AndroidJobBuildResultModel();
            androidJobBuildResultModel.setS3Env("prod");
            androidJobBuildResultModel.setCommit(commitId);
            androidJobBuildResultModel.setCoverageResult(bundleCoverage);

            buildSuccess(jobBuildModel, androidJobBuildResultModel);
        } else if (reportType == 0) {
            // 增量
            String currentBranchCodePath = cloneCurrentBranchCode(jobBuildModel.getProjectInfo(), jobBuildModel.getBaseConfig(), jobBuildModel.getWorkSpacePath());
            String originBranchCodePath = cloneOriginBranchCode(jobBuildModel.getProjectInfo(), jobBuildModel.getBaseConfig(), jobBuildModel.getWorkSpacePath());
            BranchCodePath branchCodePath = new BranchCodePath();
            branchCodePath.setCurrentBranchCodePath(currentBranchCodePath);
            branchCodePath.setOriginBranchCodePath(originBranchCodePath);
            IBundleCoverage bundleCoverage = mtJacocoReport.generate(jobBuildPath, branchCodePath);
            AndroidJobBuildResultModel androidJobBuildResultModel = new AndroidJobBuildResultModel();
            androidJobBuildResultModel.setS3Env("prod");
            androidJobBuildResultModel.setCommit(commitId);
            androidJobBuildResultModel.setCoverageResult(bundleCoverage);

            buildSuccess(jobBuildModel, androidJobBuildResultModel);
        } else {
            throw new RuntimeException("不存在的报告类型");
        }
        logger.info("Job: [Android] Job {} 构建完成, BuildNum: {}, 共耗时 {} ms", jobBuildModel.getJobConfigId(), jobBuildModel.getBuildNum(), System.currentTimeMillis() - startTime);
    }


    /**
     * 下载本次构建需要的 ec、class、src、commit
     */
    private AndroidWorkSpacePathModel downloadFile(JobBuildModel<AndroidTestConfigModel> jobBuildModel) {
        long startTime = System.currentTimeMillis();
        logger.info("Job: [Android] Job {} 开始下载构建所需的文件, 当前时间: {}", jobBuildModel.getJobConfigId(), LocalDateTime.now());

        AndroidTestConfigModel androidTestConfigModel = jobBuildModel.getTestConfig();
        WorkSpacePathModel workSpacePathModel = jobBuildModel.getWorkSpacePath();

        // 构建搜索对象
        SearchAndroidFileModel searchAndroidSrcFileModel = new SearchAndroidFileModel.Builder()
                .addBuildNum(String.valueOf(androidTestConfigModel.getBuildNum()))
                .addTestVersion(androidTestConfigModel.getTestVersion())
                .addFileType("src")
                .build();

        SearchAndroidFileModel searchAndroidClassFileModel = new SearchAndroidFileModel.Builder()
                .addBuildNum(String.valueOf(androidTestConfigModel.getBuildNum()))
                .addTestVersion(androidTestConfigModel.getTestVersion())
                .addFileType("class")
                .build();

        SearchAndroidFileModel searchAndroidEcFileModel = new SearchAndroidFileModel.Builder()
                .addBuildNum(String.valueOf(androidTestConfigModel.getBuildNum()))
                .addTestVersion(androidTestConfigModel.getTestVersion())
                .addFileType("ec")
                .addTestTime(androidTestConfigModel.getTestStartTime(), androidTestConfigModel.getTestEndTime())
                .build();

        SearchAndroidFileModel searchAndroidCommitFileModel = new SearchAndroidFileModel.Builder()
                .addBuildNum(String.valueOf(androidTestConfigModel.getBuildNum()))
                .addTestVersion(androidTestConfigModel.getTestVersion())
                .addFileType("commit")
                .build();

        List<String> ecFileList = screenFile(searchAndroidEcFileModel);
        System.out.println("ecFileList：" + ecFileList);
        List<String> classFileList = screenFile(searchAndroidClassFileModel);
        List<String> srcFileList = screenFile(searchAndroidSrcFileModel);
        List<String> commitFileList = screenFile(searchAndroidCommitFileModel);

        // 批量下载
        s3Biz.batchDownloadFileWithEnv(ecFileList, workSpacePathModel.getDataWorkSpacePath() + "ec", TestEnvEnum.STAGING.getEnv());
        s3Biz.batchDownloadFileWithEnv(classFileList, workSpacePathModel.getDataWorkSpacePath(), TestEnvEnum.STAGING.getEnv());
        s3Biz.batchDownloadFileWithEnv(srcFileList, workSpacePathModel.getDataWorkSpacePath(), TestEnvEnum.STAGING.getEnv());
        s3Biz.batchDownloadFileWithEnv(commitFileList, workSpacePathModel.getDataWorkSpacePath(), TestEnvEnum.STAGING.getEnv());

        logger.info("Job: [Android] Job {} 下载文件完成, 供耗时 {} ms", jobBuildModel.getJobConfigId(), (System.currentTimeMillis() - startTime));

        AndroidWorkSpacePathModel androidWorkSpacePathModel = new AndroidWorkSpacePathModel();
        if (classFileList.size() > 1 || srcFileList.size() > 1) {
            throw new IllegalArgumentException("安卓端查询 class 或 src 路径超过 1 个");
        }
        String classObjectPath = classFileList.get(0);
        String srcObjectPath = srcFileList.get(0);
        String commitObjectPath = commitFileList.get(0);

        String[] classObjectPathArray = classObjectPath.split("/");
        String[] srcObjectPathArray = srcObjectPath.split("/");
        String[] commitObjectPathArray = commitObjectPath.split("/");

        androidWorkSpacePathModel.setEcFilePath(workSpacePathModel.getDataWorkSpacePath() + "ec");
        androidWorkSpacePathModel.setClassPath(workSpacePathModel.getDataWorkSpacePath() + classObjectPathArray[classObjectPathArray.length - 1]);
        androidWorkSpacePathModel.setSrcPath(workSpacePathModel.getDataWorkSpacePath() + srcObjectPathArray[srcObjectPathArray.length - 1]);
        androidWorkSpacePathModel.setCommitPath(workSpacePathModel.getDataWorkSpacePath() + commitObjectPathArray[commitObjectPathArray.length - 1]);

        return androidWorkSpacePathModel;
    }

    /**
     * 筛选文件
     *
     * @param searchAndroidFileModel 安卓端ec文件搜索对象
     * @return 经筛选过后的 exec 文件名
     */
    private List<String> screenFile(SearchAndroidFileModel searchAndroidFileModel) {
        // {projectNaem}/{testVersion}/{buildNum}/src/{XXX}.zip
        // {projectNaem}/{testVersion}/{buildNum}/class/{XXX}.zip
        // {projectNaem}/{testVersion}/{buildNum}/ec/{XXX}.ec

        String prefix = searchAndroidFileModel.getMaoyanAndroidProjectName() + "/" + searchAndroidFileModel.getTestVersion() + "/" + searchAndroidFileModel.getBuildNum() + "/" + searchAndroidFileModel.getFileType();

        if (searchAndroidFileModel.getFileType().equals("ec") && searchAndroidFileModel.getTestStartTime() != null && searchAndroidFileModel.getTestEndTime() != null) {
            // 注意，注意：目前在查询数据的时候，都是从线上去查数据，因为上传文件的接口已经上线，内容都存在S3的线上环境，所以只能去哪里拉取
            List<String> ecObjectNameList = s3Biz.searchObjectListWithEnv(CoverageTypeEnum.ANDROID.getType(), prefix, TestEnvEnum.STAGING.getEnv());
            List<String> retEcObjectNameList = new ArrayList<>();

            long testStartTimeStamp = searchAndroidFileModel.getTestStartTime().toInstant(ZoneOffset.of("+8")).toEpochMilli();
            long testEndTimeStamp = searchAndroidFileModel.getTestEndTime().toInstant(ZoneOffset.of("+8")).toEpochMilli();

            for (String ecObjectName : ecObjectNameList) {
                EcFileNameModel ecFileNameModel = EcFileNameModel.format(ecObjectName);
                long ecFileUploadTime = ecFileNameModel.getUploadTime();
                if (ecFileUploadTime >= testStartTimeStamp && testEndTimeStamp >= ecFileUploadTime) {
                    retEcObjectNameList.add(ecObjectName);
                }
            }

            if (retEcObjectNameList.size() == 0) {
                throw new UserInputException("未拉取到覆盖率文件，请检查测试时间、测试版本、buildNum是否正确，并使用覆盖率包测试");
            }

            return retEcObjectNameList;
        } else {
            List<String> ecObjectNameList = s3Biz.searchObjectListWithEnv(CoverageTypeEnum.ANDROID.getType(), prefix, TestEnvEnum.STAGING.getEnv());

            if (ecObjectNameList.size() == 0) {
                if (searchAndroidFileModel.getFileType().equals("ec")) {
                    throw new UserInputException("未拉取到覆盖率文件，请检查测试时间、测试版本、buildNum是否正确，并使用覆盖率包测试");
                } else {
                    throw new UserInputException("未拉取到" + searchAndroidFileModel.getFileType() + "文件，请联系工作人员");
                }
            }

            return ecObjectNameList;
        }
    }

    public static String loadContentByPath(String path) throws IOException {
        InputStream is = new FileInputStream(path);
        BufferedReader in = new BufferedReader(new InputStreamReader(is));
        StringBuffer buffer = new StringBuffer();
        String line = "";
        while ((line = in.readLine()) != null) {
            buffer.append(line);
        }
        in.close();
        return buffer.toString();

    }

}
