package com.maoyan.coverage.admin.biz.s3;

import com.maoyan.coverage.admin.domain.enums.ProjectTypeEnum;
import com.maoyan.coverage.admin.domain.param.s3.S3UploadReportsReq;
import com.maoyan.coverage.admin.domain.param.s3.S3UploadDataReq;

import java.util.List;

/**
 * Created by lihongmei03 on 2020-11-30
 */
public interface S3Biz {

    /**
     * 安卓和iOS使用上传报告
     *
     * @return s3 报告文件夹的地址
     */
    String uploadReports(ProjectTypeEnum projectType, String projectName, Integer jobId, Integer buildNum, String localReportPath);

    /**
     * 服务端使用上传报告
     *
     * @return s3 报告文件夹的地址
     */
    String uploadReportsWithEnv(ProjectTypeEnum projectType, String projectName, Integer jobId, Integer buildNum, String localReportPath, String s3Env);


    /**
     * 用于客户端的文件上传
     * 目前的上传流程：客户端 -(ecFile)-> coverageAdmin -(ecFile)-> S3
     *
     * @param filePath      ec文件在本地的路径
     * @param applicationId APP的applicationId在主APP的build.gradle中可以查询
     * @param version       APP的版本
     * @param variantName   构建variant：commondebug/commonrelease非必须字段取值小写
     * @param env           上传环境
     * @return
     */
    Boolean uploadEcFileWithEnv(String filePath, String applicationId, String version, String buildNum, String variantName, String env);

    Boolean uploadCommitFileWithEnv(String filePath, String applicationId, String version, String buildNum, String variantName, String env);

    /**
     * 用于服务端mergeclass文件上传
     * @param filePath 本地文件路径
     * @param projectName 项目名字(英文名字，Code中的项目名字，如coverage-admin)
     * @param branch 分支名
     * @param  commit commit名
     * @param env 上传环境
     * @return
     */
    Boolean uploadMergeclassFileWithEnv(String filePath, String projectName, String branch, String commit, String env);

    /**
     * 用于服务端exec文件上传
     * @param filePath 本地文件路径
     * @param projectName 项目名字(英文名字，Code中的项目名字，如coverage-admin)
     * @param branch 分支名
     * @param commit commit名
     * @param env 环境前缀
     * @return
     */
    Boolean uploadExecFileWithEnvV2(String filePath, String projectName, String branch, String commit, String env);


    /**
     * 用于iOS端gcda.zip文件上传
     * @param localFilePath 本地文件路径
     * @param applicationId applicationId
     * @param version version
     * @param buildNum buildNum
     * @param uuid uuid
     * @param coverageType coverageType (后续可去掉，冗余参数)
     * @param env 上传环境
     * @return
     */
    Boolean uploadGcdaZipWithEnv(String localFilePath, String applicationId, String version, String buildNum, String uuid, int coverageType, String env);

    /**
     * 用于iOS端gcno.zip文件上传
     * @param localFilePath 本地文件路径
     * @param applicationId applicationId
     * @param version version
     * @param buildNum buildNum
     * @param coverageType coverageType (后续可去掉，冗余参数)
     * @param env 上传环境
     * @return
     */
    Boolean uploadGcnoZipWithEnv(String localFilePath, String applicationId, String version, String buildNum, int coverageType, String env);

    /**
     * 用于安卓端源码或者class压缩文件上传
     * @param localFilePath 本地文件路径
     * @param applicationId applicationId
     * @param version version
     * @param buildNum buildNum
     * @param variantName variantName
     * @param env 上传环境
     * @param fileType 文件类型：SRC或者CLASS
     * @return
     */
    Boolean uploadSrcOrClassZipWithEnv(String localFilePath, String applicationId, String version, String buildNum, String variantName, String env, String fileType);

    /**
     * 用于前端 .json 文件上传
     * @param s3UploadDataReq s3UploadDataReq
     * @return
     */
    Boolean uploadObjectWithEnv(S3UploadDataReq s3UploadDataReq);

    /**
     * 用于前端 .json 文件上传
     * @param s3UploadDataReq s3UploadDataReq
     * @return
     */
    Boolean uploadObject(S3UploadDataReq s3UploadDataReq);


    /**
     * 用于前端查询目标范围的文件在s3上的全路径名
     * @param projectName 项目名称
     * @param coverageType coverageType
     * @param beginTime 测试开始时间
     * @param endTime 测试结束时间
     * @param projectVersion 项目版本 (冗余参数，目前没有使用)
     * @param env S3的环境
     * @return
     */
    List<String> getObjectListWithEnv(String projectName, int coverageType, String beginTime, String endTime, String projectVersion, String env);

    /**
     * 用于前端查询目标范围的文件在s3上的全路径名
     * @param projectName 项目名称
     * @param coverageType coverageType
     * @param beginTime 测试开始时间
     * @param endTime 测试结束时间
     * @param projectVersion 项目版本 (冗余参数，目前没有使用)
     * @param env S3的环境
     * @return
     */
    List<String> getObjectListWithEnvV2(String projectName, int coverageType, String beginTime, String endTime, String projectVersion, String env);

    /**
     * 安卓端、iOS端会使用的搜索ObjectUrl的方法
     * @param coverageType 覆盖率类型
     * @param prefix 前缀
     * @param testEnv 测试环境，用于确定从哪个bucket取
     * @return List<String>
     */
    List<String> searchObjectListWithEnv(int coverageType, String prefix, String testEnv);

    /**
     * 服务端会使用的搜索ObjectUrl的方法
     * @param coverageType 覆盖率类型
     * @param prefix 前缀
     * @param testEnv 测试环境，测试环境前缀
     * @return List<String>
     */
    List<String> searchObjectListWithEnvV2(int coverageType, String prefix, String testEnv);

    /**
     * 批量下载目标文件
     * @param objectNameList objectNameList
     * @param localDirPath 存放的本地的<b>文件夹</b>路径
     * @param testEnv 测试环境
     */
    void batchDownloadFileWithEnv(List<String> objectNameList, String localDirPath, String testEnv);

    void batchDownloadFileWithEnvAndCommit(List<String> objectNameList, String localDirPath, String testEnv);


}
