package com.maoyan.coverage.admin.biz.job;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.maoyan.coverage.admin.biz.build.BuildHistoryManageBiz;
import com.maoyan.coverage.admin.biz.job.schedule.InterfaceJob;
import com.maoyan.coverage.admin.biz.jobmanage.JobOptManageBiz;
import com.maoyan.coverage.admin.biz.projectmanage.ProjectOptManageBiz;
import com.maoyan.coverage.admin.biz.s3.S3UtilBiz;
import com.maoyan.coverage.admin.common.PropUtil;
import com.maoyan.coverage.admin.common.S3Util;
import com.maoyan.coverage.admin.common.exception.DeveloperConfigException;
import com.maoyan.coverage.admin.common.exception.UserInputException;
import com.maoyan.coverage.admin.common.utils.*;
import com.maoyan.coverage.admin.domain.enums.CoverageTypeEnum;
import com.maoyan.coverage.admin.domain.enums.JobBuildResultEnum;
import com.maoyan.coverage.admin.domain.enums.JobBuildStatusEnum;
import com.maoyan.coverage.admin.domain.model.job.JobBuildModel;
import com.maoyan.coverage.admin.domain.model.job.ProjectInfoModel;
import com.maoyan.coverage.admin.domain.model.job.config.ServerTestConfigModel;
import com.maoyan.coverage.admin.domain.model.job.msg.BuildFailedToDeveloperMsgModel;
import com.maoyan.coverage.admin.domain.model.job.result.ServerJobBuildResultModel;
import com.maoyan.coverage.admin.domain.model.jobmanage.BuildHistoryModel;
import com.maoyan.coverage.admin.domain.model.jobmanage.JobConfigModel;
import com.maoyan.coverage.admin.domain.model.jobmanage.JobManageModel;
import com.maoyan.coverage.admin.service.buildmanage.IBuildHistoryService;
import com.maoyan.coverage.admin.service.jobmanage.IJobManageService;
import com.maoyan.coverage.jacocoplus.core.analysis.IBundleCoverage;
import com.maoyan.coverage.jacocoplus.core.tools.ExecFileLoader;
import com.maoyan.coverage.jacocoplus.report.DirectorySourceFileLocator;
import com.maoyan.coverage.jacocoplus.report.FileMultiReportOutput;
import com.maoyan.coverage.jacocoplus.report.IReportVisitor;
import com.maoyan.coverage.jacocoplus.report.html.HTMLFormatter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.CharEncoding;
import org.apache.commons.lang.StringUtils;
import org.jacoco.core.data.ExecutionDataWriter;
import org.jacoco.core.runtime.RemoteControlReader;
import org.jacoco.core.runtime.RemoteControlWriter;
import org.quartz.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import javax.annotation.Resource;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.*;

/**
 * @author yimingyu
 * @date 2021/11/08
 */
@Service
@Slf4j
public class InterfaceJobBiz extends BaseJobBiz{


    @Autowired
    private IJobManageService jobManageService;

    @Autowired
    private IBuildHistoryService buildHistoryService;

    @Autowired
    private JobOptManageBiz jobOptManageBiz;

    @Autowired
    private ProjectOptManageBiz projectOptManageBiz;

    @Autowired
    private BuildHistoryManageBiz buildHistoryBiz;

    @Value("${interfaceJenkins.intervalTime}")
    private Integer intervalTime;

    @Value("${interfaceJenkins.cycleThresholdTime}")
    private Integer cycleThresholdTime;

    @Autowired
    private Scheduler scheduler;

    @Resource
    private S3UtilBiz s3UtilBiz;

    private S3Util s3Util = new S3Util();

    private String commitId;

    private String branch;

    /**
     * 1.dump服务器中已有的代码覆盖率数据并上传到s3
     * 2.清空覆盖率数据
     * 3.开启接口测试jenkins构建
     * 4.更新数据库jenkins_build_num
     * 5.创建新的job，每30秒查询一次构建结果
     * 6.构建完成后dump exec (不上传到s3） & load mergeclasses & load sources
     * 7.解析覆盖率数据生成报告，上传s3，更新数据库
     */
    public void build(JobBuildModel<ServerTestConfigModel> jobBuildModel) throws SchedulerException {
        // dump服务器中已有的代码覆盖率数据并上传到s3 & 清空覆盖率数据
        dumpOption(jobBuildModel, "", "", true);
        String jenkinsRef = getJenkinsRefByJobId(jobBuildModel.getJobConfigId());
        // 开始构建接口自动化job并返回buildId
        Integer jenkinsBuildId = JenkinsUtils.build(jenkinsRef);
        // 更新数据库中的jenkinsBuildNum
        updateJenkinsBuildNum(jobBuildModel.getBuildHistoryId(), jenkinsBuildId);
        // 创建新的job,定时查询构建结果
        String jenkinsJobName = JenkinsUtils.isExistJenkinsPath(jenkinsRef);
        LocalDateTime now = LocalDateTime.now();
        long timeStamp = now.toInstant(ZoneOffset.of("+8")).toEpochMilli();
        long thresholdTimeStamp = now.plusMinutes(cycleThresholdTime).toInstant(ZoneOffset.of("+8")).toEpochMilli();
        JobDataMap jobDataMap = new JobDataMap();
        jobDataMap.put("jenkinsRef", jenkinsRef);
        jobDataMap.put("jenkinsBuildId", jenkinsBuildId);
        jobDataMap.put("jobBuildModel", jobBuildModel);
        jobDataMap.put("commitId", commitId);
        jobDataMap.put("thresholdTimeStamp", thresholdTimeStamp);
        scheduler.scheduleJob(buildJobDetail(InterfaceJob.class,
                jenkinsJobName + "job_" + timeStamp, jenkinsJobName, jobDataMap),
                buildTrigger(intervalTime, jenkinsJobName + "trigger" + timeStamp, jenkinsJobName));
        log.info("开启轮询构建结果的job， jobName = {}, 每隔 {} 秒轮训一次", jenkinsJobName + "job" + timeStamp, intervalTime);
        scheduler.start();
    }

    /**
     *      * 该方法的作用
     *      * 1.dump机器中现有的覆盖率并上传到s3，再清空覆盖数据, 保证现有覆盖率数据不丢失以及接口覆盖率数据的准确
     *      * 2.额外判定：上传s3但是不删除本地文件
     * @param jobBuildModel
     * @param extraFilePath
     * @param extraFileName
     * @param isClearFile
     * @return 返回exec文件所在的文件夹
     */
    public String dumpOption(JobBuildModel<ServerTestConfigModel> jobBuildModel, String extraFilePath,
                           String extraFileName, boolean isClearFile){
        Set<Map.Entry<String, String>> IpAndPortEntry = jobBuildModel.getTestConfig().getIpAndPortMap().entrySet();
        String projectName = ShellUtils.getRepositoryName(jobBuildModel.getProjectInfo().getGitAddress());
        getNewestReleaseInfo(jobBuildModel.getTestConfig().getReleaseId(),
                jobBuildModel.getTestConfig().getTestEnv());
        for (Map.Entry<String, String> entry : IpAndPortEntry
             ) {
            String addr = entry.getKey();
            int port = Integer.parseInt(entry.getValue());
            FileOutputStream fileOutputStream = null;
            File folder = new File(jobBuildModel.getWorkSpacePath().getDataWorkSpacePath() + extraFilePath);
            if (!folder.exists()){
                folder.mkdirs();
            }
            Socket socket = null;
            try {
                String fileName = jobBuildModel.getWorkSpacePath().getDataWorkSpacePath() + extraFilePath + "/"
                        + commitId + "-" + addr + "-" + extraFileName+ LocalDateTime.now().toInstant(ZoneOffset.of("+8")).toEpochMilli()
                        + ".exec";
                fileOutputStream = new FileOutputStream(fileName);
                final ExecutionDataWriter localWriter = new ExecutionDataWriter(fileOutputStream);
                socket = new Socket(InetAddress.getByName(addr), port);
                final RemoteControlWriter writer = new RemoteControlWriter(socket.getOutputStream());
                final RemoteControlReader reader = new RemoteControlReader(socket.getInputStream());
                reader.setSessionInfoVisitor(localWriter);
                reader.setExecutionDataVisitor(localWriter);
                writer.visitDumpCommand(true, false);
                if (!reader.read()) {
                    throw new IOException("Socket closed unexpectedly.");
                }
                File execFile = new File(fileName);
                if (!jobBuildModel.getBaseConfig().getCurrentBranch().equalsIgnoreCase(branch)) {
                    throw new UserInputException("dump失败，请检查服务器部署分支与创建job所填分支是否一致");
                }
                // 将原有的覆盖率数据dump下来上传到s3
                if (execFile.exists()) {
                    if (isClearFile) {
                        s3Biz.uploadExecFileWithEnvV2(execFile.getAbsolutePath(), projectName, jobBuildModel.getBaseConfig().getCurrentBranch(), commitId, jobBuildModel.getTestConfig().getTestEnv());
                    }
                    // 无需上传接口自动化生成的exec文件
//                    else {
//                        ((S3BizImpl)s3Biz).uploadExecFileWithEnvV2(execFile.getAbsolutePath(), projectName, jobBuildModel.getBaseConfig().getCurrentBranch(), commitId, jobBuildModel.getTestConfig().getTestEnv(), false);
//                    }
                }
                // 清空服务器中已存在覆盖率数据
                writer.visitDumpCommand(false, true);
                socket.close();
                fileOutputStream.close();
            }catch (Exception e) {
                log.error("[Server]: dump 时出现问题", e);
                if (e instanceof UserInputException) {
                    throw new UserInputException(e.getMessage());
                }
                if (e instanceof DeveloperConfigException) {
                    throw new DeveloperConfigException(e.getMessage());
                }
                if (e.getMessage().contains("Connection refused")) {
                    throw new UserInputException("请检查项目是否用代码覆盖率模版或ip及端口号填写正确");
                }
                if (e.getMessage().contains("Connection timed out")) {
                    throw new UserInputException("端口已被占用，请检查ip及端口号是否填写正确");
                }
                throw new RuntimeException(e);
            }
        }
        return jobBuildModel.getWorkSpacePath().getDataWorkSpacePath() + extraFilePath;

    }

    /**
     * 获取plus中最新发布成功的commitId & branch
     * @param releaseId
     * @param env
     */
    public void getNewestReleaseInfo(int releaseId, String env){
        JSONArray jsonArray = getPlusJobList(releaseId);
        Optional<Object> newestReleaseCommitId = jsonArray.stream().filter(releaseItem
                -> ((JSONObject) releaseItem).get("Status").equals("Success")
                && ((JSONObject) releaseItem).get("Env").equals(env)
                && StringUtils.isNotEmpty(((JSONObject) releaseItem).getString("Commit")))
                .findFirst();
        JSONObject releaseItem = (JSONObject)newestReleaseCommitId.get();
        commitId = String.valueOf(releaseItem.get("Commit")).substring(0, 11);
        branch = String.valueOf(releaseItem.get("Label"));
    }

    public JSONArray getPlusJobList(int releaseId){
        String plusurl = "http://plus.sankuai.com/release/" + releaseId + "/joblist";
        String response = HttpUtils.get(plusurl);
        return JSONArray.parseArray(response);
    }

    /**
     * 根据jobId获取jenkinsRef
     * @param jobId
     * @return
     */
    public String getJenkinsRefByJobId(int jobId){
        JobManageModel jobConfig = jobManageService.getJobConfigById(jobId);
        return jobConfig.getJobAutoTestConfig().getJenkinsRef();
    }

    /**
     * 更新构建历史表中的
     * @param buildHistoryId
     * @param JenkinsBuildNumber
     * @return
     */
    public void updateJenkinsBuildNum(int buildHistoryId, int JenkinsBuildNumber){
        int rest = buildHistoryService.updateJenkinsBuildNum(buildHistoryId, JenkinsBuildNumber);
        if (rest > 0){
            log.info("update jenkinsBuildNum success, new jenkinsBuildNum is {}", JenkinsBuildNumber);
        } else {
            throw new RuntimeException("更新JenkinsBuildNum失败");
        }
    }

    public JobDetail buildJobDetail(Class<? extends InterruptableJob> jobClass, String jobName, String jobGroup, JobDataMap jobDataMap){
        return JobBuilder.newJob(jobClass)
                .withIdentity(jobName, jobGroup)
                .usingJobData(jobDataMap)
                .build();
    }

    public SimpleTrigger buildTrigger(int intervalTime, String triggerName, String triggerGroup){
        return TriggerBuilder.newTrigger()
                .withIdentity(triggerName, triggerGroup)
                .withSchedule(SimpleScheduleBuilder.simpleSchedule().withIntervalInSeconds(intervalTime).repeatForever())
                .build();
    }

    /**
     * 拉取mergeclasses文件到 WorkSpacePathModel.dataWorkSpacePath/commit + jobName/mergeclasses
     * @param jobBuildModel
     * @param extraFilePath
     * @throws FileNotFoundException
     * @return 返回class文件存放的目录
     */
    public String loadNewestClasses(JobBuildModel<ServerTestConfigModel> jobBuildModel, String extraFilePath) throws FileNotFoundException {
        List<String> objectList = Lists.newArrayList();
        String projectName = jobBuildModel.getProjectInfo().getRepositoryName();
        String todayStr = DateUtils.getTodayStr();
        String TestEnv = jobBuildModel.getTestConfig().getTestEnv();
        String filePrefix = s3Util.coverageTypeMapping(CoverageTypeEnum.SERVER.getType()) + "coverage_data/" +
                TestEnv + "/" + projectName + "/" + branch + "/" + todayStr + "/" + commitId + "/" + "mergeclass/";
        objectList = s3UtilBiz.getObjectListV2(filePrefix);
        String mergeClassesPath = jobBuildModel.getWorkSpacePath().getDataWorkSpacePath() + extraFilePath + "/" + "mergeclasses";
        String mergeClassesZipPath = jobBuildModel.getWorkSpacePath().getDataWorkSpacePath() + commitId + "-mergeclasses.zip";
        if (CollectionUtils.isEmpty(objectList)){
            String iplistnew = mapToString(jobBuildModel.getTestConfig().getIpAndPortMap());
            // 拉取 class 文件 WorkSpacePathModel.dataWorkSpacePath/commit + jobName/mergeclasses
            ShellUtils.dumpmergeclass(iplistnew, mergeClassesPath);
            FileOutputStream fos1 = new FileOutputStream(new File(mergeClassesZipPath));
            ZipUtils.toZip(mergeClassesPath, fos1, true);
            s3Biz.uploadMergeclassFileWithEnv(mergeClassesZipPath, projectName, branch,
                    commitId, TestEnv);
        } else {
           // 从s3拉取classes.zip并解压到 WorkSpacePathModel.dataWorkSpacePath/commit + jobName/mergeclasses
            s3Biz.batchDownloadFileWithEnvAndCommit(objectList, jobBuildModel.getWorkSpacePath().getDataWorkSpacePath(), TestEnv);
            log.info("获取存储s3下载的classes.zip文件的路径 " + jobBuildModel.getWorkSpacePath().getDataWorkSpacePath() + commitId + "/" + commitId + "-mergeclasses.zip");
            log.info("classes.zip文件解压后的位置 " + jobBuildModel.getWorkSpacePath().getDataWorkSpacePath() + extraFilePath + "/");
            ZipUtils.unzip(jobBuildModel.getWorkSpacePath().getDataWorkSpacePath() + commitId + "/" + commitId + "-mergeclasses.zip",
                    jobBuildModel.getWorkSpacePath().getDataWorkSpacePath() + extraFilePath + "/");
            log.info("获取classes.zip文件解压后的位置 " + mergeClassesPath);
            File dir = new File(mergeClassesPath);
            if (!dir.isDirectory()) {
                throw new UserInputException("mergeclasses文件夹为空，请检查与被测服务器是否建立信任关系或mergeclasses在服务器存放位置是否正确");
            }
        }
        return mergeClassesPath;

    }


    /**
     * 获取iplist字符串
     *
     * @param ipAndPortMap – ip和port的map
     * @return string
     */
    public String mapToString(Map<String, String> ipAndPortMap) {
        StringBuilder iplistString = new StringBuilder();
        List<String> iplist = new ArrayList<String>();
        for (String address : ipAndPortMap.keySet()) {
            iplist.add(address);
        }
        for (int i = 0; i < iplist.size(); i++) {
            if (i > 0) {
                iplistString.append(",");
            }
            iplistString.append(iplist.get(i));
        }
        return iplistString.toString();
    }

    /**
     * 加载execPath文件夹下所有的exec文件到execFileLoader对象中
     * @param execFileLoader
     * @param execPath
     * @throws IOException
     */
    public void loadExec(ExecFileLoader execFileLoader, String execPath) throws IOException {
        File file = new File(execPath);
        if (!file.exists()){
            throw new RuntimeException(execPath + "目录不存在");
        }
        File[] files = file.listFiles();
        if (files != null) {
            for (File f : files
            ) {
                if (f.isDirectory()) {
                    loadExec(execFileLoader, f.getAbsolutePath());
                } else if (f.isFile() && f.getName().endsWith(".exec")) {
                    execFileLoader.load(f);
                }
            }
        }
    }

    /**
     * 生成覆盖率报告
     * @param bundleCoverage
     * @param execFileLoader
     * @param sourcePath
     * @param reportPath
     * @throws IOException
     */
    public void createCoverageReport(IBundleCoverage bundleCoverage, ExecFileLoader execFileLoader,
                                     String sourcePath, String reportPath) throws IOException {
        HTMLFormatter htmlFormatter = new HTMLFormatter();
        IReportVisitor visitor = htmlFormatter.createVisitor(new FileMultiReportOutput(new File(reportPath)));
        visitor.visitInfo(execFileLoader.getSessionInfoStore().getInfos(), execFileLoader.getExecutionDataStore().getContents());
        visitor.visitBundle(bundleCoverage, new DirectorySourceFileLocator(new File(sourcePath), CharEncoding.UTF_8, 4));
        visitor.visitEnd();
    }

    public void successEndOpt(IBundleCoverage bundleCoverage, JobBuildModel<ServerTestConfigModel> jobBuildModel, String extraPath) {
        jobBuildModel.getWorkSpacePath().setCodeWorkSpacePath(jobBuildModel.getWorkSpacePath().getCodeWorkSpacePath() + extraPath + "/");
        ServerJobBuildResultModel serverJobJavaBuildResultModel = new ServerJobBuildResultModel();
        serverJobJavaBuildResultModel.setCoverageResult(bundleCoverage);
        serverJobJavaBuildResultModel.setS3Env(jobBuildModel.getTestConfig().getTestEnv());
        serverJobJavaBuildResultModel.setCommit(commitId);
        buildSuccess(jobBuildModel, serverJobJavaBuildResultModel);
    }

    public void failEndOpt(JobBuildModel<ServerTestConfigModel> jobBuildModel, Exception error, String jenkinsJobName) {
        int buildHistoryId = jobBuildModel.getBuildHistoryId();
        BuildHistoryModel buildHistoryModel = buildHistoryBiz.getBuildHistoryModelById(buildHistoryId);
        // 更新结束时间
        buildHistoryModel.setEndTime(LocalDateTime.now());
        // 更新状态
        buildHistoryModel.setBuildStatus(JobBuildStatusEnum.END.getType());
        buildHistoryModel.setBuildResult(JobBuildResultEnum.FAIL.getType());
        buildHistoryBiz.update(buildHistoryModel);
        // 发送大象通知
        sendBuildErrorMsgToDeveloper(error, jobBuildModel, jenkinsJobName);
    }

    /**
     * 停止并clean轮询jenkins job
     * @param triggerKey
     * @param jobKey
     * @throws SchedulerException
     */
    public void stopAndCleanJob(TriggerKey triggerKey, JobKey jobKey) throws SchedulerException {
        scheduler.pauseTrigger(triggerKey);
        scheduler.unscheduleJob(triggerKey);
        scheduler.deleteJob(jobKey);
    }

    /**
     * 发送错误信息给开发者
     */
    protected void sendBuildErrorMsgToDeveloper(Exception error, JobBuildModel<ServerTestConfigModel> jobBuildModel,
                                                String jenkinsJobName){
        String frontBaseUrl = PropUtil.getProperty("front.domain");
        int jobConfigId = jobBuildModel.getJobConfigId();
        JobConfigModel jobConfigModel = jobOptManageBiz.getJobConfigModelByJobConfigId(jobConfigId);
        ProjectInfoModel projectInfoModel = projectOptManageBiz.getProjectInfoModelByProjectId(jobConfigModel.getProjectConfigId());

        BuildFailedToDeveloperMsgModel failedDeveloperMsgModel = new BuildFailedToDeveloperMsgModel();
        failedDeveloperMsgModel.setJobId(jobConfigId);
        failedDeveloperMsgModel.setJobName(jobConfigModel.getJobName());
        failedDeveloperMsgModel.setBuildHistoryUrl(frontBaseUrl + "/#/jobhistory?jobId=" + jobBuildModel.getJobConfigId());
        failedDeveloperMsgModel.setProjectName(ShellUtils.getRepositoryName(projectInfoModel.getGitAddress()));
        failedDeveloperMsgModel.setError(buildErrorMsg(error));
        failedDeveloperMsgModel.setBuildNum(jobBuildModel.getBuildNum());
        failedDeveloperMsgModel.setRemarks(error instanceof DeveloperConfigException ? error.getMessage() : "");
        failedDeveloperMsgModel.setInfo("Jenkins Job:[" + jenkinsJobName + "]构建出现异常");
        XMPubUtil.sendToDeveloper(failedDeveloperMsgModel.getMsg());

    }

    private String buildErrorMsg(Exception error) {
        return error.getClass() + ":" + error.getMessage() + "\n" + Arrays.toString(error.getStackTrace());
    }







}
