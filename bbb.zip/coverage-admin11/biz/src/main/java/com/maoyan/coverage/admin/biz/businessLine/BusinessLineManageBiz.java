package com.maoyan.coverage.admin.biz.businessLine;

import com.maoyan.coverage.admin.common.utils.ApiResponseCoverage;
import com.maoyan.coverage.admin.common.utils.DateUtils;
import com.maoyan.coverage.admin.domain.constant.DateFormatStr;
import com.maoyan.coverage.admin.domain.constant.ErrorMessageConstant;
import com.maoyan.coverage.admin.domain.model.businessline.BusinessLineModel;
import com.maoyan.coverage.admin.domain.model.Paging;
import com.maoyan.coverage.admin.domain.model.projectmanage.ProjectManageModel;
import com.maoyan.coverage.admin.domain.vo.businessline.BusinessLineVO;
import com.maoyan.coverage.admin.domain.vo.businessline.CBusinessLineVO;
import com.maoyan.coverage.admin.service.businessline.IBusinessLineService;
import com.maoyan.coverage.admin.service.projectmanage.IProjectManageService;
import com.meituan.mobile.movie.common.response.ApiResponse;
import com.sankuai.meituan.auth.util.UserUtils;
import com.sankuai.meituan.auth.vo.User;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.*;

/**
 * @author yimingyu
 * @date 2021/07/19
 */
@Service
@Slf4j
public class BusinessLineManageBiz {

    @Resource
    private IBusinessLineService businessLineService;

    @Resource
    private IProjectManageService projectManageService;

    /**
     * 添加业务线
     *
     * @param businessLineName
     * @return
     */
    public ApiResponse<Object> addBusinessLine(String businessLineName) {
        User user = UserUtils.getUser();
        log.info("user = {}", user);
        if (user == null) {
            return ApiResponse.buildFailure(ErrorMessageConstant.USER_NOT_LOGIN);
        }
        BusinessLineModel blm = businessLineService.getBusinessLineByName(businessLineName);
        if (blm != null) {
            return ApiResponse.buildFailure("业务线名不能重复");
        }
        LocalDateTime localDateTime = LocalDateTime.now();
        BusinessLineModel businessLineModel = new BusinessLineModel();
        businessLineModel.setBusinessLine(businessLineName);
        businessLineModel.setCreator(user.getLogin());
        businessLineModel.setUpdater(user.getLogin());
        businessLineModel.setDeleted(0);
        businessLineModel.setCreateTime(localDateTime);
        businessLineModel.setUpdateTime(localDateTime);
        int rest = businessLineService.insetBusinessLine(businessLineModel);
        if (rest > 0) {
            return ApiResponse.buildSuccess();
        }
        return ApiResponse.buildFailure("内部错误，添加业务线失败");
    }

    /**
     * 获取业务线列表
     *
     * @param offset
     * @param limit
     * @return
     */
    public ApiResponse<Object> getBusinessLineList(int offset, int limit, boolean isAllBusinessLine) {
        List<BusinessLineModel> allBusinessLineModelS = businessLineService.getAllBusinessLines();
        int total = allBusinessLineModelS.size();
        Paging paging = new Paging();
        paging.setOffset(offset);
        paging.setTotal(total);
        paging.setLimit(limit);
        paging.setHasMore(offset + limit < total);
        List<BusinessLineVO> businessLineVOS = new ArrayList<>();
        Map<String, Object> map = new HashMap<>();
        if (total == 0) {
            map.put("businessLineList", businessLineVOS);
            return ApiResponseCoverage.buildSuccess(map, paging);
        }
        if (offset >= total && !isAllBusinessLine){
            return ApiResponse.buildFailure(ErrorMessageConstant.PAGE_ERROR_NO_DATA);
        }
        List<BusinessLineModel> businessLineModelList = null;
        if (isAllBusinessLine){
            businessLineModelList = allBusinessLineModelS;
            paging.setLimit(total);
            paging.setHasMore(false);
        } else {
            businessLineModelList = businessLineService.getBusinessLineList(offset, limit);
        }
        for (BusinessLineModel businessLine : businessLineModelList
        ) {
            BusinessLineVO businessLineVO = new BusinessLineVO();
            businessLineVO.setId(businessLine.getId());
            businessLineVO.setBusinessLineName(businessLine.getBusinessLine());
            businessLineVO.setCreator(businessLine.getCreator());
            businessLineVO.setCreateTime(DateUtils.format2Str(businessLine.getCreateTime(), DateFormatStr.DATE_FORMAT_VO));
            businessLineVOS.add(businessLineVO);
        }
        map.put("businessLineList", businessLineVOS);
        return ApiResponseCoverage.buildSuccess(map, paging);
    }

    /**
     * 更新业务线名
     *
     * @param businessLineId
     * @param businessLineName
     * @return
     */
    public ApiResponse<Object> updateBusinessLine(int businessLineId, String businessLineName) {
        User user = UserUtils.getUser();
        if (user == null) {
            return ApiResponse.buildFailure(ErrorMessageConstant.USER_NOT_LOGIN);
        }
        BusinessLineModel blm = businessLineService.getBusinessLineByName(businessLineName);
        if (blm != null && blm.getId() != businessLineId) {
            return ApiResponse.buildFailure("业务线名不能重复");
        }
        BusinessLineModel businessLineModel = new BusinessLineModel();
        businessLineModel.setId(businessLineId);
        businessLineModel.setBusinessLine(businessLineName);
        businessLineModel.setUpdateTime(LocalDateTime.now());
        businessLineModel.setUpdater(user.getLogin());
        int rest = businessLineService.updateBusinessLine(businessLineModel);
        if (rest > 0) {
            return ApiResponse.buildSuccess();
        }
        return ApiResponse.buildFailure("您更新的业务线不存在,请确认后重试");
    }

    /**
     * 删除业务线
     *
     * @param businessLineId
     * @return
     */
    public ApiResponse<Object> deleteBusinessLineById(int businessLineId) {
        User user = UserUtils.getUser();
        if (user == null) {
            return ApiResponse.buildFailure(ErrorMessageConstant.USER_NOT_LOGIN);
        }
        BusinessLineModel blm = businessLineService.getBusinessLineById(businessLineId);
        if (blm == null) {
            return ApiResponse.buildFailure("您删除的业务线不存在,请确认后重试");
        }
        if (!user.getLogin().equals(blm.getCreator())){
            return ApiResponse.buildFailure("您不是该业务线的创建者，无法删除该业务线");
        }
        List<ProjectManageModel> projectManageModelList = projectManageService.getProjectManageDOListByBusinessLineId(businessLineId);
        if (projectManageModelList.size() > 0) {
            return ApiResponse.buildFailure("当前业务线下存在项目，无法删除");
        }
        BusinessLineModel businessLineModel = new BusinessLineModel();
        businessLineModel.setId(businessLineId);
        businessLineModel.setUpdateTime(LocalDateTime.now());
        businessLineModel.setUpdater(user.getLogin());
        businessLineModel.setDeleted(1);
        int rest = businessLineService.delBusinessLineById(businessLineModel);
        if (rest > 0) {
            return ApiResponse.buildSuccess();
        }
        return ApiResponse.buildFailure("您删除的业务线不存在,请确认后重试");
    }

    /**
     * 获取所有的业务线id、业务线名
     * @return
     */
    public ApiResponse<Object> getAllBusinessLines2ChaoYue(){
        List<BusinessLineModel> allBusinessLines = businessLineService.getAllBusinessLines();
        List<CBusinessLineVO> cBusinessLineVOS = new ArrayList<>();
        if (!CollectionUtils.isEmpty(allBusinessLines)){
            for (BusinessLineModel businessLine: allBusinessLines
                 ) {
                CBusinessLineVO cBusinessLineVO = new CBusinessLineVO();
                cBusinessLineVO.setId(businessLine.getId());
                cBusinessLineVO.setBusinessLineName(businessLine.getBusinessLine());
                cBusinessLineVOS.add(cBusinessLineVO);
            }
        }
        return ApiResponse.buildSuccess(cBusinessLineVOS);
    }


}
