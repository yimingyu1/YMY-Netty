package com.maoyan.coverage.admin.biz.job;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.maoyan.coverage.admin.common.PropUtil;
import com.maoyan.coverage.admin.common.exception.UserInputException;
import com.maoyan.coverage.admin.common.utils.HttpUtils;
import com.maoyan.coverage.admin.common.utils.XMPubUtil;
import com.maoyan.coverage.admin.domain.enums.ProjectTypeEnum;
import com.maoyan.coverage.admin.domain.enums.ReportTypeEnum;
import com.maoyan.coverage.admin.domain.enums.TestEnvEnum;
import com.maoyan.coverage.admin.domain.model.data.DataIndicatorsModel;
import com.maoyan.coverage.admin.domain.model.data.FrontBuildResultDataModel;
import com.maoyan.coverage.admin.domain.model.job.JobBuildModel;
import com.maoyan.coverage.admin.domain.model.job.ProjectInfoModel;
import com.maoyan.coverage.admin.domain.model.job.config.AppletTestConfigModel;
import com.maoyan.coverage.admin.domain.model.job.config.MRNTestConfigModel;
import com.maoyan.coverage.admin.domain.model.job.config.TestConfigModel;
import com.maoyan.coverage.admin.domain.model.job.config.WebTestConfigModel;
import com.maoyan.coverage.admin.domain.model.job.front.FullBuildModel;
import com.maoyan.coverage.admin.domain.model.job.front.IncrementBuildModel;
import com.maoyan.coverage.admin.domain.model.jobmanage.JobBaseConfigModel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

@Service
public class FrontJobBiz extends BaseJobBiz {

    private final Logger logger = LoggerFactory.getLogger(FrontJobBiz.class);

    private final String NODE_DOMAIN = PropUtil.getProperty("node.domain");

    /**
     * 与前端 Node 服务链接超时时间 ms
     */
    private final Integer CONNECT_TIME_OUT = 1000 * 60 * 10;

    /**
     * 前端 job 构建时间，暂定最大 10 分钟
     */
    private final Integer READ_TIME_OUT = 1000 * 60 * 10;

    /**
     * PC i版 Job类型调用
     */
    public void webJobBuild(JobBuildModel<WebTestConfigModel> jobBuildModel) {
        long startTime = System.currentTimeMillis();
        JobBaseConfigModel jobBaseConfigModel = jobBuildModel.getBaseConfig();
        ReportTypeEnum reportType = getReportType(jobBaseConfigModel.getReportType());

        FrontBuildResultDataModel buildResult = null;
        if (reportType.equals(ReportTypeEnum.FULL_REPORT)) {
            // 全量 job
            FullBuildModel param = buildWebFullModel(jobBuildModel);
            buildResult = fullBuild(JSONArray.toJSON(param).toString());

        } else if (reportType.equals(ReportTypeEnum.INCREMENT_REPORT)) {
            // 增量 job
            IncrementBuildModel param = buildWebIncrementModel(jobBuildModel);
            buildResult = incrementBuild(JSONArray.toJSON(param).toString());
        } else {
            throw new RuntimeException("不存在的报告类型");
        }

        buildSuccess(jobBuildModel, buildResult);

        logger.info("Job: [Web] Job {} 构建完成, BuildNum: {}, 供耗时 {} ms", jobBuildModel.getJobConfigId(), jobBuildModel.getBuildNum(), System.currentTimeMillis() - startTime);
    }

    public void mrnJobBuild(JobBuildModel<MRNTestConfigModel> jobBuildModel) {
        long startTime = System.currentTimeMillis();

        JobBaseConfigModel jobBaseConfigModel = jobBuildModel.getBaseConfig();
        ReportTypeEnum reportType = getReportType(jobBaseConfigModel.getReportType());

        FrontBuildResultDataModel buildResult = null;
        if (reportType.equals(ReportTypeEnum.FULL_REPORT)) {
            // 全量 job
            FullBuildModel param = buildMRNFullModel(jobBuildModel);
            buildResult = fullBuild(JSONArray.toJSON(param).toString());

        } else if (reportType.equals(ReportTypeEnum.INCREMENT_REPORT)) {
            // 增量 job
            IncrementBuildModel param = buildMRNIncrementModel(jobBuildModel);
            buildResult = incrementBuild(JSONArray.toJSON(param).toString());
        } else {
            throw new RuntimeException("不存在的报告类型");
        }

        buildSuccess(jobBuildModel, buildResult);

        logger.info("Job: [MRN] Job {} 构建完成, BuildNum: {}, 供耗时 {} ms", jobBuildModel.getJobConfigId(), jobBuildModel.getBuildNum(), System.currentTimeMillis() - startTime);
    }

    public void appletJobBuild(JobBuildModel<AppletTestConfigModel> jobBuildModel) {
        long startTime = System.currentTimeMillis();

        JobBaseConfigModel jobBaseConfigModel = jobBuildModel.getBaseConfig();
        ReportTypeEnum reportType = getReportType(jobBaseConfigModel.getReportType());

        FrontBuildResultDataModel buildResult = null;
        if (reportType.equals(ReportTypeEnum.INCREMENT_REPORT)) {
            // 增量 job
            IncrementBuildModel param = buildAppletIncrementModel(jobBuildModel);
            buildResult = incrementBuild(JSONArray.toJSON(param).toString());
        } else {
            throw new RuntimeException("Job: [小程序] 不支持的报告类型");
        }

        buildSuccess(jobBuildModel, buildResult);

        logger.info("Job: [小程序] Job {} 构建完成, BuildNum: {}, 供耗时 {} ms", jobBuildModel.getJobConfigId(), jobBuildModel.getBuildNum(), System.currentTimeMillis() - startTime);
    }

    private IncrementBuildModel buildWebIncrementModel(JobBuildModel<WebTestConfigModel> jobBuildModel) {
        WebTestConfigModel webTestConfigModel = jobBuildModel.getTestConfig();

        IncrementBuildModel incrementBuildModel = buildIncrementModel(jobBuildModel);
        incrementBuildModel.setProjectName(buildWebProjectName(jobBuildModel));
        // web 端特有的参数
        incrementBuildModel.setTestStartTime(webTestConfigModel.getTestStartTime());
        incrementBuildModel.setTestEndTime(webTestConfigModel.getTestEndTime());
        // 使用的S3环境
        incrementBuildModel.setTestEnv(webTestConfigModel.getTestEnv());

        return incrementBuildModel;
    }

    private FullBuildModel buildWebFullModel(JobBuildModel<WebTestConfigModel> jobBuildModel) {
        WebTestConfigModel webTestConfigModel = jobBuildModel.getTestConfig();

        FullBuildModel fullBuildModel = buildFullModel(jobBuildModel);
        fullBuildModel.setProjectName(buildWebProjectName(jobBuildModel));
        // web 端特有的参数
        fullBuildModel.setTestStartTime(webTestConfigModel.getTestStartTime());
        fullBuildModel.setTestEndTime(webTestConfigModel.getTestEndTime());
        fullBuildModel.setTestEnv(webTestConfigModel.getTestEnv());
        return fullBuildModel;
    }

    private String buildWebProjectName(JobBuildModel<WebTestConfigModel> jobBuildModel) {
        WebTestConfigModel webTestConfigModel = jobBuildModel.getTestConfig();
        ProjectInfoModel projectInfoModel = jobBuildModel.getProjectInfo();
        ArrayList<String> deployHostList = webTestConfigModel.getDeployHost();
        // ${projectName}/${deployHost}
        // ${projectName}/:${deployHost1}:${deployHost2}
        // ${projectName}
        if (deployHostList.size() == 1) {
            return projectInfoModel.getRepositoryName() + "/" + deployHostList.get(0);
        } else if (deployHostList.size() > 1) {
            StringBuilder hostStrBuilder = new StringBuilder();
            deployHostList.forEach(deployHos -> {
                hostStrBuilder.append(":").append(deployHos);
            });
            return projectInfoModel.getRepositoryName() + "/" + hostStrBuilder.toString();
        } else {
            return projectInfoModel.getRepositoryName();
        }
    }

    private FullBuildModel buildMRNFullModel(JobBuildModel<MRNTestConfigModel> jobBuildModel) {
        MRNTestConfigModel mrnTestConfigModel = jobBuildModel.getTestConfig();

        FullBuildModel fullBuildModel = buildFullModel(jobBuildModel);
        fullBuildModel.setProjectName(buildMRNProjectName(jobBuildModel));
        fullBuildModel.setTestStartTime(mrnTestConfigModel.getTestStartTime());
        fullBuildModel.setTestEndTime(mrnTestConfigModel.getTestEndTime());
        // 环境前缀
        fullBuildModel.setTestEnv(TestEnvEnum.TEST.getEnv());

        return fullBuildModel;
    }

    private IncrementBuildModel buildMRNIncrementModel(JobBuildModel<MRNTestConfigModel> jobBuildModel) {
        MRNTestConfigModel mrnTestConfigModel = jobBuildModel.getTestConfig();

        IncrementBuildModel incrementBuildModel = buildIncrementModel(jobBuildModel);
        incrementBuildModel.setProjectName(buildMRNProjectName(jobBuildModel));
        incrementBuildModel.setTestStartTime(mrnTestConfigModel.getTestStartTime());
        incrementBuildModel.setTestEndTime(mrnTestConfigModel.getTestEndTime());
        // 环境前缀
        incrementBuildModel.setTestEnv(TestEnvEnum.TEST.getEnv());

        return incrementBuildModel;
    }

    private String buildMRNProjectName(JobBuildModel<MRNTestConfigModel> jobBuildModel) {
        MRNTestConfigModel mrnTestConfigModel = jobBuildModel.getTestConfig();
        ProjectInfoModel projectInfoModel = jobBuildModel.getProjectInfo();
        // ${projectName}/${releaseEnv}
        return projectInfoModel.getRepositoryName() + "/" + mrnTestConfigModel.getReleaseEnv();
    }


    private IncrementBuildModel buildAppletIncrementModel(JobBuildModel<AppletTestConfigModel> jobBuildModel) {
        AppletTestConfigModel appletTestConfigModel = jobBuildModel.getTestConfig();
        ProjectInfoModel projectInfoModel = jobBuildModel.getProjectInfo();
        JobBaseConfigModel jobBaseConfigModel = jobBuildModel.getBaseConfig();

        IncrementBuildModel incrementBuildModel = buildIncrementModel(jobBuildModel);

        if (appletTestConfigModel.getCurrentCommit() != null) {
            incrementBuildModel.setProjectName(projectInfoModel.getRepositoryName() + "/" + jobBaseConfigModel.getCurrentBranch() + "/" + appletTestConfigModel.getCurrentCommit());
        } else {
            incrementBuildModel.setProjectName(projectInfoModel.getRepositoryName() + "/" + jobBaseConfigModel.getCurrentBranch());
        }

        incrementBuildModel.setTestStartTime(appletTestConfigModel.getTestStartTime());
        incrementBuildModel.setTestEndTime(appletTestConfigModel.getTestEndTime());
        incrementBuildModel.setTestEnv(appletTestConfigModel.getTestEnv());

        return incrementBuildModel;
    }

    private FullBuildModel buildFullModel(JobBuildModel<? extends TestConfigModel> jobBuildModel) {
        FullBuildModel fullBuildModel = new FullBuildModel();
        JobBaseConfigModel jobBaseConfigModel = jobBuildModel.getBaseConfig();
        ProjectInfoModel projectInfoModel = jobBuildModel.getProjectInfo();

        fullBuildModel.setJobId(jobBuildModel.getJobConfigId());
        fullBuildModel.setGitUrl(projectInfoModel.getGitAddress());
        // projectName 由各类型自己完成
        fullBuildModel.setProjectType(String.valueOf(projectInfoModel.getProjectType().getId()));
        fullBuildModel.setBuildNumber(String.valueOf(jobBuildModel.getBuildNum()));
        fullBuildModel.setCurrentBranch(jobBaseConfigModel.getCurrentBranch());
        fullBuildModel.setThreshold(jobBaseConfigModel.getThreshold());

        return fullBuildModel;
    }

    private IncrementBuildModel buildIncrementModel(JobBuildModel<? extends TestConfigModel> jobBuildModel) {
        IncrementBuildModel incrementBuildModel = new IncrementBuildModel();
        ProjectInfoModel projectInfoModel = jobBuildModel.getProjectInfo();
        JobBaseConfigModel jobBaseConfigModel = jobBuildModel.getBaseConfig();

        incrementBuildModel.setJobId(jobBuildModel.getJobConfigId());
        incrementBuildModel.setGitUrl(projectInfoModel.getGitAddress());
        // projectName 由各类型自己完成
        // node 端进行了一次转化
        incrementBuildModel.setProjectType(String.valueOf(projectInfoModel.getProjectType().getId()));

        incrementBuildModel.setBuildNumber(String.valueOf(jobBuildModel.getBuildNum()));
        incrementBuildModel.setCurrentBranch(jobBaseConfigModel.getCurrentBranch());
        incrementBuildModel.setOriginBranch(jobBaseConfigModel.getOriginBranch());
        incrementBuildModel.setThreshold(jobBaseConfigModel.getThreshold());

        return incrementBuildModel;
    }

    private FrontBuildResultDataModel incrementBuild(String param) {
        String INCREMENT_API = "/api/increment";
        String resStr = HttpUtils.post(NODE_DOMAIN + INCREMENT_API, param, CONNECT_TIME_OUT, READ_TIME_OUT);
        JSONObject resJSONObject = JSONObject.parseObject(resStr);
        return parseRes(resJSONObject, ReportTypeEnum.INCREMENT_REPORT);
    }

    private FrontBuildResultDataModel fullBuild(String param) {
        String FULL_API = "/api/full";
        String resStr = HttpUtils.post(NODE_DOMAIN + FULL_API, param, CONNECT_TIME_OUT, READ_TIME_OUT);
        JSONObject resJSONObject = JSONObject.parseObject(resStr);
        return parseRes(resJSONObject, ReportTypeEnum.FULL_REPORT);
    }

    private FrontBuildResultDataModel parseRes(JSONObject resJSONObject, ReportTypeEnum reportType) {
        String success = resJSONObject.getString("success");
        String errMsg = resJSONObject.getString("errMsg");
        Integer code = resJSONObject.getInteger("code");
        Integer projectType = resJSONObject.getInteger("projectType");

        if (!success.equals("true")) {
            if (errMsg.contains("[UserInputException]")) {
                if (projectType.equals(ProjectTypeEnum.APPLETS.getId())) {
                    throw new UserInputException("从 S3 上拉取来的数据是空的，请检查 Job 配置中“分支”、“测试环境”、“测试时间”、“commit”是否正确");
                }
                if (projectType.equals(ProjectTypeEnum.I_VERSION.getId()) || projectType.equals(ProjectTypeEnum.PC.getId())) {
                    throw new UserInputException("从 S3 上拉取来的数据是空的，请检查 Job 配置中“分支”、“测试环境”、“DEPLOY_HOST”、“测试时间”是否正确");
                }
                if (projectType.equals(ProjectTypeEnum.MRN.getId())) {
                    throw new UserInputException("从 S3 上拉取来的数据是空的，请检查 Job 配置中“分支”、“发布环境”、“测试时间”是否正确");
                }
            }
            throw new RuntimeException("前端 Job 构建失败\n" + errMsg);
        }

        // 获取 data
        JSONObject data = resJSONObject.getJSONObject("data");

        // 获取数据指标信息
        JSONArray dataIndicators = JSONArray.parseArray(data.getString("dataIndicators"));

        ArrayList<DataIndicatorsModel> dataIndicatorsModels = new ArrayList<>();

        dataIndicators.forEach(j -> {
            DataIndicatorsModel dataIndicatorsModel = JSONObject.parseObject(j.toString(), DataIndicatorsModel.class);
            dataIndicatorsModels.add(dataIndicatorsModel);
        });

        String reportUrl = data.getString("reportUrl");
        String projectName = data.getString("projectName");
        String commit = data.getString("commit");

        FrontBuildResultDataModel frontBuildResultDataModel = new FrontBuildResultDataModel();
        frontBuildResultDataModel.setDataIndicators(dataIndicatorsModels);
        frontBuildResultDataModel.setProjectName(projectName);
        frontBuildResultDataModel.setReportUrl(reportUrl);
        frontBuildResultDataModel.setCommit(commit);
        frontBuildResultDataModel.setReportType(reportType);

        return frontBuildResultDataModel;
    }
}
