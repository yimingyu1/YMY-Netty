package com.maoyan.coverage.admin.biz.jobmanage;

import com.alibaba.fastjson.JSONObject;
import com.maoyan.coverage.admin.common.exception.UserInputException;
import com.maoyan.coverage.admin.common.utils.*;
import com.maoyan.coverage.admin.domain.constant.DateFormatStr;
import com.maoyan.coverage.admin.domain.constant.ErrorMessageConstant;
import com.maoyan.coverage.admin.domain.constant.RepositoryRefConstant;
import com.maoyan.coverage.admin.domain.enums.*;
import com.maoyan.coverage.admin.domain.model.JobTimerModel;
import com.maoyan.coverage.admin.domain.model.Paging;
import com.maoyan.coverage.admin.domain.model.buildhistory.BuildHistoryChartModel;
import com.maoyan.coverage.admin.domain.model.buildhistory.BuildHistoryListModel;
import com.maoyan.coverage.admin.domain.model.job.config.*;
import com.maoyan.coverage.admin.domain.model.jobmanage.JobConfigModel;
import com.maoyan.coverage.admin.domain.model.jobmanage.JobDetailConfigModel;
import com.maoyan.coverage.admin.domain.model.jobmanage.*;
import com.maoyan.coverage.admin.domain.model.projectmanage.ProjectManageModel;
import com.maoyan.coverage.admin.domain.param.job.CycleServerDumpParam;
import com.maoyan.coverage.admin.domain.param.jobmanage.JobManageParam;
import com.maoyan.coverage.admin.domain.vo.jobmanage.*;
import com.maoyan.coverage.admin.service.buildmanage.IBuildHistoryService;
import com.maoyan.coverage.admin.service.jobmanage.IJobManageService;
import com.maoyan.coverage.admin.service.jobtimer.JobTimerService;
import com.maoyan.coverage.admin.service.projectmanage.IProjectManageService;
import com.meituan.mobile.movie.common.response.ApiResponse;
import com.sankuai.meituan.auth.util.UserUtils;
import com.sankuai.meituan.auth.vo.User;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.dom4j.DocumentException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.io.IOException;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

import com.maoyan.coverage.admin.biz.schedule.JobManager;
import com.maoyan.coverage.admin.biz.job.ServerJobBiz;

/**
 * @author yimingyu
 * @date 2021/07/27
 */
@Service
@Slf4j
public class JobOptManageBiz {

    @Autowired
    JobManager jobManager;

    @Autowired
    ServerJobBiz serverJobBiz;

    @Resource
    private IJobManageService jobManageService;

    @Resource
    private IProjectManageService projectManageService;

    @Resource
    private JobTimerService jobTimerService;

    @Resource
    private IBuildHistoryService buildHistoryService;

    /**
     * 添加job操作
     *
     * @param projectId
     * @param projectType
     * @param jobManageParam
     * @return
     */
    public ApiResponse<Object> addJob(int projectId, int projectType, int jobType, JobManageParam jobManageParam) {
        /**
         * 根据projectType 封装 jobBaseConfig 和 jobTestConfig
         */
        User user = UserUtils.getUser();
        if (user == null) {
            return ApiResponse.buildFailure(ErrorMessageConstant.USER_NOT_LOGIN);
        }
        ProjectManageModel projectManageById = projectManageService.getProjectManageById(projectId);
        log.info("projectManageById = {}", projectManageById);
        if (projectManageById == null){
            return ApiResponse.buildFailure("该projectId不存在, 请确认后重试");
        }
        if (projectType != projectManageById.getProjectType()){
            return ApiResponse.buildFailure("当前projectId和projectType不匹配,该projectId对应的projectType=" + projectManageById.getProjectType());
        }

        JobManageModel jobManageModel = new JobManageModel();
        ApiResponse<Object> objectApiResponse = checkAndTransfer(projectType, jobType, jobManageParam, jobManageModel, projectManageById.getGitAddress(), false);
        if (objectApiResponse != null){
            return objectApiResponse;
        }
        JobBaseConfigModel jobBaseConfigModel = new JobBaseConfigModel();
        jobBaseConfigModel.setJobName(jobManageParam.getJobName());
        jobBaseConfigModel.setCurrentBranch(jobManageParam.getCurrentBranch());
        jobBaseConfigModel.setOriginBranch(jobManageParam.getOriginBranch());
        jobBaseConfigModel.setReportType(jobManageParam.getReportType());
        jobBaseConfigModel.setThreshold(jobManageParam.getThreshold());
        jobManageModel.setProjectConfigId(projectId);
        jobManageModel.setJobType(projectType);
        jobManageModel.setJobName(jobManageParam.getJobName());
        jobManageModel.setJobBaseConfig(jobBaseConfigModel);
        jobManageModel.setDeleted(0);
        jobManageModel.setCreator(user.getLogin());
        jobManageModel.setUpdater(user.getLogin());
        LocalDateTime localDateTime = LocalDateTime.now();
        jobManageModel.setCreateTime(localDateTime);
        jobManageModel.setUpdateTime(localDateTime);
        // 如果添加成功，返回新数据的id, rest = 新id
        int rest = jobManageService.insertJobConfig(jobManageModel);
        if (rest > 0) {
            if (projectType==6 && jobType == 0){
                jobManager.cycleDump(CycleServerDumpParam.build(rest));
            }
            return ApiResponse.buildSuccess();
        }
        return ApiResponse.buildFailure("内部错误，添加job失败");
    }

    /**
     * 获取指定项目下的job列表
     *
     * @param offset
     * @param limit
     * @param projectId
     * @return
     */
    public ApiResponse<Object> getJobList(int offset, int limit, int projectId, int jobType) {
        ProjectManageModel projectManageById = projectManageService.getProjectManageById(projectId);
        log.info("projectManageById = {}", projectManageById);
        if (projectManageById == null){
            return ApiResponse.buildFailure("该projectId不存在, 请确认后重试");
        }
        List<JobManageModel> jobManageModels = jobManageService.getJobManageListByProjectId(projectId, jobType);
        int total = jobManageModels.size();
        Paging paging = new Paging();
        paging.setOffset(offset);
        paging.setTotal(total);
        paging.setLimit(limit);
        paging.setHasMore(offset + limit < total);
        List<JobConfigListVO> jobConfigListVOS = new ArrayList<>();
        if (jobManageModels.size() == 0) {
            return ApiResponseCoverage.buildSuccess(jobConfigListVOS, paging);
        }
        if (offset >= total) {
            return ApiResponse.buildFailure(ErrorMessageConstant.PAGE_ERROR_NO_DATA);
        }
        List<JobManageModel> jobManageModelList = jobManageService.getJobManageListWithLimit(projectId, jobType, offset, limit);
        int i = 1 + offset;
        for (JobManageModel jmm : jobManageModelList
        ) {
            JobConfigListVO jobConfigListVO = new JobConfigListVO();
            jobConfigListVO.setId(jmm.getId());
            jobConfigListVO.setJobId(i++);
            jobConfigListVO.setJobType(jmm.getJobTestType());
            jobConfigListVO.setJobName(jmm.getJobName());
            JobBaseConfigModel jobBaseConfigModel = jmm.getJobBaseConfig();
            jobConfigListVO.setCurrentBranch(jobBaseConfigModel.getCurrentBranch());
            jobConfigListVO.setReportType(jobBaseConfigModel.getReportType()==0 ?
                    ReportTypeEnum.INCREMENT_REPORT.getDes() : ReportTypeEnum.FULL_REPORT.getDes());
            if (jmm.getJobType() == ProjectTypeEnum.PC.getId() || jmm.getJobType() == ProjectTypeEnum.I_VERSION.getId()
                    || jmm.getJobType() == ProjectTypeEnum.MRN.getId()) {
                if (jmm.getJobType() == ProjectTypeEnum.MRN.getId()){
                    JobTestConfig2MRNModel jobTestConfig2MRNModel = JSONObject.parseObject(jmm.getJobTestConfig(), JobTestConfig2MRNModel.class);
                    jobConfigListVO.setTestEnv(jobTestConfig2MRNModel.getReleaseEnv());
                } else {
                    JobTestConfig2WebModel jobTestConfig2WebModel = JSONObject.parseObject(jmm.getJobTestConfig(), JobTestConfig2WebModel.class);
                    jobConfigListVO.setTestEnv(jobTestConfig2WebModel.getTestEnv());
                }
            }
            if (jmm.getJobType() == ProjectTypeEnum.SERVER.getId()) {
                JobTestConfig2ServerModel jobTestConfig2ServerModel = JSONObject.parseObject(jmm.getJobTestConfig(), JobTestConfig2ServerModel.class);
                jobConfigListVO.setTestEnv(jobTestConfig2ServerModel.getTestEnv());
            }
            if (jmm.getJobType() == ProjectTypeEnum.APPLETS.getId()){
                JobTestConfig2AppletModel jobTestConfig2AppletModel = JSONObject.parseObject(jmm.getJobTestConfig(), JobTestConfig2AppletModel.class);
                jobConfigListVO.setTestEnv(jobTestConfig2AppletModel.getTestEnv());
            }
            if (jobType == 1){
                JobAutoTestConfigModel jobAutoTestConfigModel = jmm.getJobAutoTestConfig();
                jobConfigListVO.setJenkinsRef(jobAutoTestConfigModel.getJenkinsRef());
            }
            BuildHistoryChartModel newestBuildHistory = buildHistoryService.getNewestBuildHistoryByJobId(jmm.getId());
            String newestCoveredBranches = "暂无构建数据";
            String newestCoveredLines = "暂无构建数据";
            if (newestBuildHistory != null){
                List<String> coveredRate = CoveredRateUtils.getCoveredRate(newestBuildHistory.getLinesCovered(), newestBuildHistory.getLineNum());
                newestCoveredLines = coveredRate.get(0) + "(" + coveredRate.get(1) + "%)";
                List<String> coveredRate1 = CoveredRateUtils.getCoveredRate(newestBuildHistory.getBranchesCovered(), newestBuildHistory.getBranches());
                newestCoveredBranches = coveredRate1.get(0) + "(" + coveredRate1.get(1) + "%)";
            }
            jobConfigListVO.setNewestCoveredBranches(newestCoveredBranches);
            jobConfigListVO.setNewestCoveredLines(newestCoveredLines);
            // 获取该job的最新构建结果，如果是构建中，则向后顺延获取
            List<BuildHistoryListModel> buildHistoryListModels = buildHistoryService.getBuildHistoryListByJobId(jmm.getId());
            if (CollectionUtils.isEmpty(buildHistoryListModels)){
                jobConfigListVO.setNewestBuildResult(JobBuildResultEnum.UN_KNOWN.getType());
            } else {
                List<BuildHistoryListModel> collect = buildHistoryListModels.stream().sorted(Comparator.comparingInt(BuildHistoryListModel::getId).reversed())
                        .filter(buildHistoryListModel -> buildHistoryListModel.getBuildResult() != 0).collect(Collectors.toList());
                if (CollectionUtils.isEmpty(collect)) {
                    jobConfigListVO.setNewestBuildResult(JobBuildResultEnum.UN_KNOWN.getType());
                } else {
                    jobConfigListVO.setNewestBuildResult(collect.get(0).getBuildResult() == 1 ? JobBuildResultEnum.SUCCESS.getType() : JobBuildResultEnum.FAIL.getType());
                }
            }
            jobConfigListVOS.add(jobConfigListVO);
        }
        Map<String, Object> map = new HashMap<>();
        map.put("jobConfigList", jobConfigListVOS);
        map.put("projectType", projectManageById.getProjectType());
        map.put("projectName", projectManageById.getProjectName());
        map.put("projectId", projectId);
        return ApiResponseCoverage.buildSuccess(map, paging);
    }

    /**
     * 获取指定buildId的jobInfo
     * @param id
     * @return
     */
    public ApiResponse<Object> getBuildHistoryJobInfoById(int id){
        BuildHistoryChartModel buildHistoryByBuildId = buildHistoryService.getBuildHistoryByBuildId(id);
        if (buildHistoryByBuildId == null){
            return ApiResponse.buildFailure("该buildHistory不存在，请确认后重试");
        }
        JobManageModel jobConfigById = jobManageService.getJobConfigById(buildHistoryByBuildId.getJobId());
        if (jobConfigById == null){
            return ApiResponse.buildFailure("该buildId对应的job已被删除，请确认后重试");
        }
        return getJobInfoByJobModel(buildHistoryByBuildId.getJobManageModel());
    }

    /**
     * 获取指定jobId的jobInfo
     * @param id
     * @return
     */
    public ApiResponse<Object> getJobInfoByJobId(int id){
        JobManageModel jobConfigById = jobManageService.getJobConfigById(id);
        if (jobConfigById == null) {
            return ApiResponse.buildFailure("该job不存在，请确认后重试");
        }
        return getJobInfoByJobModel(jobConfigById);
    }

    /**
     * 获取指定JobManageModel的job信息
     *
     * @param jobManageModel
     * @return
     */
    public ApiResponse<Object> getJobInfoByJobModel(JobManageModel jobManageModel) {
        int projectType = jobManageModel.getJobType();
        JobAllConfigVO jobAllConfigVO = new JobAllConfigVO();
        jobAllConfigVO.setId(jobManageModel.getId());
        jobAllConfigVO.setJobName(jobManageModel.getJobName());
        JobBaseConfigModel jobBaseConfigModel = jobManageModel.getJobBaseConfig();
        jobAllConfigVO.setReportType(jobBaseConfigModel.getReportType());
        jobAllConfigVO.setCurrentBranch(jobBaseConfigModel.getCurrentBranch());
        jobAllConfigVO.setOriginBranch(jobBaseConfigModel.getOriginBranch());
        jobAllConfigVO.setThreshold(jobBaseConfigModel.getThreshold());
        if (jobManageModel.getJobTestType() ==  JobTestTypeEnum.INTERFACE_TEST.getType()) {
            JobAutoTestConfigModel jobAutoTestConfigModel = jobManageModel.getJobAutoTestConfig();
            jobAllConfigVO.setJenkinsRef(jobAutoTestConfigModel.getJenkinsRef());
            jobAllConfigVO.setJenkinsGitAddress(jobAutoTestConfigModel.getJenkinsGitAddress());
            jobAllConfigVO.setJenkinsGitBranch(jobAutoTestConfigModel.getJenkinsGitBranch());
        }
        transferToVo(projectType, jobManageModel, jobAllConfigVO);
        Map<String, Object> map = new HashMap<>();
        map.put("projectType", projectType);
        map.put("jobConfig", jobAllConfigVO);
        return ApiResponse.buildSuccess(map);
    }

    /**
     * 更新job信息
     *
     * @param projectType
     * @param jobManageParam
     * @return
     */
    public ApiResponse<Object> updateJobInfo(int projectType, JobManageParam jobManageParam) {
        /**
         * 根据projectType 封装 jobBaseConfig 和 jobTestConfig
         */
        User user = UserUtils.getUser();
        if (user == null) {
            return ApiResponse.buildFailure(ErrorMessageConstant.USER_NOT_LOGIN);
        }
        JobManageModel jobConfigById = jobManageService.getJobConfigById(jobManageParam.getId());
        if (jobConfigById == null) {
            return ApiResponse.buildFailure("该job不存在，请确认后重试");
        }
        if (projectType != jobConfigById.getJobType()){
            return ApiResponse.buildFailure("当前jobId和projectType不匹配,该id对应的projectType=" + jobConfigById.getJobType());
        }
        JobManageModel newJobManageModel = new JobManageModel();
        newJobManageModel.setJobTestConfig(jobConfigById.getJobTestConfig());
        ApiResponse<Object> objectApiResponse = checkAndTransfer(projectType, jobConfigById.getJobTestType(), jobManageParam, newJobManageModel, null, true);
        if (objectApiResponse != null){
            return objectApiResponse;
        }
        JobBaseConfigModel jobBaseConfigModel = new JobBaseConfigModel();
        jobBaseConfigModel.setJobName(jobManageParam.getJobName());
        jobBaseConfigModel.setCurrentBranch(jobConfigById.getJobBaseConfig().getCurrentBranch());
        jobBaseConfigModel.setOriginBranch(jobConfigById.getJobBaseConfig().getOriginBranch());
        jobBaseConfigModel.setReportType(jobConfigById.getJobBaseConfig().getReportType());
        jobBaseConfigModel.setThreshold(jobConfigById.getJobBaseConfig().getThreshold());
        newJobManageModel.setProjectConfigId(jobConfigById.getProjectConfigId());
        newJobManageModel.setJobType(jobConfigById.getJobType());
        newJobManageModel.setId(jobConfigById.getId());
        newJobManageModel.setJobName(jobManageParam.getJobName());
        newJobManageModel.setJobBaseConfig(jobBaseConfigModel);
        newJobManageModel.setUpdater(user.getLogin());
        newJobManageModel.setUpdateTime(LocalDateTime.now());
        newJobManageModel.setJobTestType(jobConfigById.getJobTestType());
        JobAutoTestConfigModel jobAutoTestConfigModel = new JobAutoTestConfigModel();
        jobAutoTestConfigModel.setJenkinsRef(jobManageParam.getJenkinsRef());
        jobAutoTestConfigModel.setJenkinsGitAddress(jobManageParam.getJenkinsGitAddress());
        jobAutoTestConfigModel.setJenkinsGitBranch(jobManageParam.getCurrentBranch());
        newJobManageModel.setJobAutoTestConfig(jobAutoTestConfigModel);
        int rest = jobManageService.updateJobConfig(newJobManageModel);
        if (rest > 0) {
            return ApiResponse.buildSuccess();
        }
        return ApiResponse.buildFailure("内部错误，修改job失败");
    }

    /**
     * 删除job
     *
     * @param id
     * @return
     */
    public ApiResponse<Object> delJobById(int id) {
        log.info("jobConfig delJobById --- id = {}", id);
        User user = UserUtils.getUser();
        if (user == null) {
            return ApiResponse.buildFailure(ErrorMessageConstant.USER_NOT_LOGIN);
        }
        JobManageModel jobConfigById = jobManageService.getJobConfigById(id);
        if (jobConfigById == null) {
            return ApiResponse.buildFailure("该job不存在，请确认后重试");
        }
        if (!jobConfigById.getCreator().equals(user.getLogin())){
            return ApiResponse.buildFailure("您不是该job的创建者，无法删除");
        }
        List<JobTimerModel> jobTimerModels = jobTimerService.getJobTimerModelsByJobConfigIdAndClosed(id, TimerStatusEnum.IN_PROCESSING.getType());
        if (jobTimerModels.size() > 0) {
            // 本身的定时构建或者服务端自带的Dump Job
            return ApiResponse.buildFailure("该job存在定时任务，请先关闭定时任务");
        }
        int rest = jobManageService.deleteJobConfig(id, user.getLogin(), LocalDateTime.now());
        if (rest > 0) {
            return ApiResponse.buildSuccess();
        }
        return ApiResponse.buildFailure("内部错误，删除job失败");
    }

    /**
     * 获取job详情页头部信息
     * @param id
     * @return
     */
    public ApiResponse<Object> getJobDetailHeaderInfo(int id){
        JobManageModel jobConfigById = jobManageService.getJobConfigById(id);
        if (jobConfigById == null) {
            return ApiResponse.buildFailure("该job不存在，请确认后重试");
        }
        ProjectTypeEnum projectTypeEnum = ProjectTypeEnum.getById(jobConfigById.getJobType());
        JobDetailHeaderVO jobDetailHeaderVO = null;
        switch (projectTypeEnum){
            case PC:
            case I_VERSION:
                jobDetailHeaderVO = new WebJobDetailHeaderVO();
                break;
            case MRN:
                jobDetailHeaderVO = new MRNJobDetailHeaderVO();
                break;
            case APPLETS:
                jobDetailHeaderVO = new AppletJobDetailHeaderVO();
                break;
            case SERVER:
                jobDetailHeaderVO = new ServerJobDetailHeaderVO();
                break;
            case ANDROID:
                jobDetailHeaderVO = new AndroidJobDetailHeaderVO();
                break;
            case IOS:
                jobDetailHeaderVO = new IOSJobDetailHeaderVO();
                break;
        }
        JobBaseConfigModel jobBaseConfigModel = jobConfigById.getJobBaseConfig();
        jobDetailHeaderVO.setJobType(jobBaseConfigModel.getReportType() == ReportTypeEnum.INCREMENT_REPORT.getType() ?
                        ReportTypeEnum.INCREMENT_REPORT.getDes() : ReportTypeEnum.FULL_REPORT.getDes());
        jobDetailHeaderVO.setTestBranch(jobBaseConfigModel.getCurrentBranch());
        jobDetailHeaderVO.setOriginBranch(jobBaseConfigModel.getOriginBranch());
        jobDetailHeaderVO.setJobName(jobBaseConfigModel.getJobName());
        ProjectManageModel projectManageById = projectManageService.getProjectManageById(jobConfigById.getProjectConfigId());
        jobDetailHeaderVO.setGitAddress(getRepositoryRef(projectManageById.getGitAddress()));
        String gitAddress = getRepositoryRef(projectManageById.getGitAddress());
        String[] gitAddressList = gitAddress.split("/");
        String projectName = gitAddressList[gitAddressList.length - 3];
        //        jobDetailHeaderVO.setProjectName(projectManageById.getProjectName());
        jobDetailHeaderVO.setProjectName(projectName);
        jobDetailHeaderVO.setProjectType(projectManageById.getProjectType());
        jobDetailHeaderVO.setThreshold(jobBaseConfigModel.getThreshold());
        JobTimerModel jobTimerModelByJobConfigId = jobTimerService.getJobTimerModelByJobConfigIdAndType(id, JobTimerTypeEnum.JOB_BUILD_TIMER.getType());
        // 0: 已开启定时构建   1：未开启定时构建
        jobDetailHeaderVO.setBuildStatus(jobTimerModelByJobConfigId == null ? 1 : jobTimerModelByJobConfigId.getClosed());
        switch (projectTypeEnum){
            // PC i版 MRN
            case PC:
            case I_VERSION:
                JobTestConfig2WebModel jobTestConfig2WebModel = JSONObject.parseObject(jobConfigById.getJobTestConfig(), JobTestConfig2WebModel.class);
                WebJobDetailHeaderVO webJobDetailHeaderVO = (WebJobDetailHeaderVO) jobDetailHeaderVO;
                webJobDetailHeaderVO.setDeployHost(jobTestConfig2WebModel.getDeployHost());
                webJobDetailHeaderVO.setTestTime(DateUtils.turnTimeFormatBatch(jobTestConfig2WebModel.getTestTime(),DateFormatStr.DATE_FORMAT_DO, DateFormatStr.DATE_FORMAT_VO));
                webJobDetailHeaderVO.setTestEnv(jobTestConfig2WebModel.getTestEnv());
                return ApiResponse.buildSuccess(webJobDetailHeaderVO);
            case MRN:
                JobTestConfig2MRNModel jobTestConfig2MRNModel = JSONObject.parseObject(jobConfigById.getJobTestConfig(), JobTestConfig2MRNModel.class);
                MRNJobDetailHeaderVO mrnJobDetailHeaderVO = (MRNJobDetailHeaderVO) jobDetailHeaderVO;
                mrnJobDetailHeaderVO.setTestTime(DateUtils.turnTimeFormatBatch(jobTestConfig2MRNModel.getTestTime(), DateFormatStr.DATE_FORMAT_DO, DateFormatStr.DATE_FORMAT_VO));
                mrnJobDetailHeaderVO.setReleaseEnv(jobTestConfig2MRNModel.getReleaseEnv());
                return ApiResponse.buildSuccess(mrnJobDetailHeaderVO);
            case APPLETS:
                JobTestConfig2AppletModel jobTestConfig2AppletModel = JSONObject.parseObject(jobConfigById.getJobTestConfig(), JobTestConfig2AppletModel.class);
                AppletJobDetailHeaderVO appletJobDetailHeaderVO = (AppletJobDetailHeaderVO) jobDetailHeaderVO;
                appletJobDetailHeaderVO.setTestTime(DateUtils.turnTimeFormatBatch(jobTestConfig2AppletModel.getTestTime(), DateFormatStr.DATE_FORMAT_DO, DateFormatStr.DATE_FORMAT_VO));
                appletJobDetailHeaderVO.setTestEnv(jobTestConfig2AppletModel.getTestEnv());
                appletJobDetailHeaderVO.setCommit(jobTestConfig2AppletModel.getCommit());
                return ApiResponse.buildSuccess(appletJobDetailHeaderVO);
            case SERVER:
                JobTestConfig2ServerModel jobTestConfig2ServerModel = JSONObject.parseObject(jobConfigById.getJobTestConfig(), JobTestConfig2ServerModel.class);
                ServerJobDetailHeaderVO serverJobDetailHeaderVO = (ServerJobDetailHeaderVO) jobDetailHeaderVO;
                serverJobDetailHeaderVO.setServerIp(jobTestConfig2ServerModel.getServerIp());
                serverJobDetailHeaderVO.setAgentPort(jobTestConfig2ServerModel.getAgentPort());
                serverJobDetailHeaderVO.setTestEnv(jobTestConfig2ServerModel.getTestEnv());
                serverJobDetailHeaderVO.setReleaseId(jobTestConfig2ServerModel.getReleaseId());
                serverJobDetailHeaderVO.setTestTime(DateUtils.turnTimeFormatBatch(jobTestConfig2ServerModel.getTestTime(), DateFormatStr.DATE_FORMAT_DO, DateFormatStr.DATE_FORMAT_VO));
                serverJobDetailHeaderVO.setJobTestType(jobConfigById.getJobTestType());
                if (jobConfigById.getJobTestType() == 1){
                    JobAutoTestConfigModel jobAutoTestConfigModel = jobConfigById.getJobAutoTestConfig();
                    serverJobDetailHeaderVO.setJenkinsRef(jobAutoTestConfigModel.getJenkinsRef());
                    serverJobDetailHeaderVO.setJenkinsGitAddress(jobAutoTestConfigModel.getJenkinsGitAddress());
                }
                return ApiResponse.buildSuccess(serverJobDetailHeaderVO);
            case ANDROID:
                JobTestConfig2AndroidModel jobTestConfig2AndroidModel = JSONObject.parseObject(jobConfigById.getJobTestConfig(), JobTestConfig2AndroidModel.class);
                AndroidJobDetailHeaderVO androidJobDetailHeaderVO = (AndroidJobDetailHeaderVO) jobDetailHeaderVO;
                androidJobDetailHeaderVO.setTestVersion(jobTestConfig2AndroidModel.getTestVersion());
                androidJobDetailHeaderVO.setBuildNum(jobTestConfig2AndroidModel.getBuildNum());
                androidJobDetailHeaderVO.setTestTime(DateUtils.turnTimeFormatBatch(jobTestConfig2AndroidModel.getTestTime(), DateFormatStr.DATE_FORMAT_DO, DateFormatStr.DATE_FORMAT_VO));
                return ApiResponse.buildSuccess(androidJobDetailHeaderVO);
            case IOS:
                JobTestConfig2iOSModel jobTestConfig2IOSModel = JSONObject.parseObject(jobConfigById.getJobTestConfig(), JobTestConfig2iOSModel.class);
                IOSJobDetailHeaderVO iosJobDetailHeaderVO = (IOSJobDetailHeaderVO) jobDetailHeaderVO;
                iosJobDetailHeaderVO.setTestVersion(jobTestConfig2IOSModel.getTestVersion());
                iosJobDetailHeaderVO.setBuildNum(jobTestConfig2IOSModel.getProjectVersion());
                return ApiResponse.buildSuccess(iosJobDetailHeaderVO);
        }
        return ApiResponse.buildFailure("内部错误");
    }

    public String getJobNameByJobConfigId(int id) {
        return jobManageService.getJobNameByJobConfigId(id);
    }

    public int getProjectTypeByJobConfigId(int id) {
        return jobManageService.getProjectTypeByJobConfigId(id);
    }

    public JobBaseConfigModel getJobBaseConfigModelByJobConfigId(int id) {
        return jobManageService.getJobBaseConfigModelByJobConfigId(id);
    }

    public JobConfigModel getJobConfigModelByJobConfigId(int id) {
        return jobManageService.getJobConfigModelByJobConfigId(id);
    }

    public JobDetailConfigModel<ServerTestConfigModel> getServerJobDetailConfigModelByJobConfigId(int id) {
        return jobManageService.getServerJobDetailConfigModelByJobConfigId(id);
    }

    public JobDetailConfigModel<IOSTestConfigModel> getIOSJobDetailConfigModelByJobConfigId(int id) {
        return jobManageService.getIOSJobDetailConfigModelByJobConfigId(id);
    }

    public JobDetailConfigModel<AndroidTestConfigModel> getAndroidJobDetailConfigModelByJobConfigId(int id) {
        return jobManageService.getAndroidJobDetailConfigModelByJobConfigId(id);
    }

    public JobDetailConfigModel<WebTestConfigModel> getWebJobDetailConfigModelByJobConfigId(int id) {
        return jobManageService.getWebJobDetailConfigModelByJobConfigId(id);
    }

    public JobDetailConfigModel<MRNTestConfigModel> getMRNJobDetailConfigModelByJobConfigId(int id) {
        return jobManageService.getMRNJobDetailConfigModelByJobConfigId(id);
    }

    public JobDetailConfigModel<AppletTestConfigModel> getAppletJobDetailConfigModelByJobConfigId(int id) {
        return jobManageService.getAppletJobDetailConfigModelByJobConfigId(id);
    }

    /**
     * 已确定是服务端Job
     * 获取Job的测试配置
     */
    public ServerTestConfigModel getServerTestConfigModelByJobConfigId(int id) {
        return jobManageService.getServerTestConfigModelByJobConfigId(id);
    }

    /**
     * 已确定是小程序端Job
     * 获取Job的测试配置
     */
    public AppletTestConfigModel getAppletTestConfigModelByJobConfigId(int id) {
        return jobManageService.getAppletTestConfigModelByJobConfigId(id);
    }

    /**
     * 已确定是Web端(i\PC)Job
     * 获取Job的测试配置
     */
    public WebTestConfigModel getWebTestConfigModelByJobConfigId(int id) {
        return jobManageService.getWebTestConfigModelByJobConfigId(id);
    }

    /**
     * 已确定是MRN端Job
     * 获取Job的测试配置
     */
    public MRNTestConfigModel getMRNTestConfigModelByJobConfigId(int id) {
        return jobManageService.getMRNTestConfigModelByJobConfigId(id);
    }

    /**
     * 已确定是安卓端Job
     * 获取Job的测试配置
     */
    public AndroidTestConfigModel getAndroidTestConfigModelByJobConfigId(int id) {
        return jobManageService.getAndroidTestConfigModelByJobConfigId(id);
    }

    /**
     * 已确定是iOS端Job
     * 获取Job的测试配置
     */
    public IOSTestConfigModel getIOSTestConfigModelByJobConfigId(int id) {
        return jobManageService.getIOSTestConfigModelByJobConfigId(id);
    }

    public JobManageModel getJobManageModelByJobConfigId(int id) {
        return jobManageService.getJobConfigById(id);
    }

    /**
     * 转换为vo
     * @param projectType
     * @param jobManageModel
     * @param jobAllConfigVO
     */
    public void transferToVo(int projectType, JobManageModel jobManageModel, JobAllConfigVO jobAllConfigVO){
        ProjectTypeEnum projectTypeEnum = ProjectTypeEnum.getById(projectType);
        List<String> testTime = null;
        switch (projectTypeEnum){
            // PC i版 MRN
            case PC:
            case MRN:
            case I_VERSION:
                if (projectType == ProjectTypeEnum.MRN.getId()){
                    JobTestConfig2MRNModel jobTestConfig2MRNModel = JSONObject.parseObject(jobManageModel.getJobTestConfig(), JobTestConfig2MRNModel.class);
                    jobAllConfigVO.setTestEnv(jobTestConfig2MRNModel.getReleaseEnv());
                    testTime = jobTestConfig2MRNModel.getTestTime();
                } else {
                    JobTestConfig2WebModel jobTestConfig2WebModel = JSONObject.parseObject(jobManageModel.getJobTestConfig(), JobTestConfig2WebModel.class);
                    jobAllConfigVO.setTestEnv(jobTestConfig2WebModel.getTestEnv());
                    testTime = jobTestConfig2WebModel.getTestTime();
                    jobAllConfigVO.setDeployHost(jobTestConfig2WebModel.getDeployHost());
                }
                break;
            case APPLETS:
                JobTestConfig2AppletModel jobTestConfig2AppletModel = JSONObject.parseObject(jobManageModel.getJobTestConfig(), JobTestConfig2AppletModel.class);
                jobAllConfigVO.setCommit(jobTestConfig2AppletModel.getCommit());
                testTime = jobTestConfig2AppletModel.getTestTime();
                jobAllConfigVO.setTestEnv(jobTestConfig2AppletModel.getTestEnv());
                break;
            case SERVER:
                JobTestConfig2ServerModel jobTestConfig2ServerModel = JSONObject.parseObject(jobManageModel.getJobTestConfig(), JobTestConfig2ServerModel.class);
                jobAllConfigVO.setTestEnv(jobTestConfig2ServerModel.getTestEnv());
                jobAllConfigVO.setServerIp(jobTestConfig2ServerModel.getServerIp());
                jobAllConfigVO.setAgentPort(jobTestConfig2ServerModel.getAgentPort());
                jobAllConfigVO.setReleaseId(jobTestConfig2ServerModel.getReleaseId());
//                jobAllConfigVO.setTargetDir(jobTestConfig2ServerModel.getTargetDir());
                testTime = jobTestConfig2ServerModel.getTestTime();
                if (jobManageModel.getJobTestType() == JobTestTypeEnum.INTERFACE_TEST.getType()){
                    jobAllConfigVO.setJobTestType(jobManageModel.getJobTestType());
                    jobAllConfigVO.setJenkinsRef(jobManageModel.getJobAutoTestConfig().getJenkinsRef());
                    jobAllConfigVO.setJenkinsGitAddress(jobManageModel.getJobAutoTestConfig().getJenkinsGitAddress());
                    jobAllConfigVO.setJenkinsGitBranch(jobManageModel.getJobAutoTestConfig().getJenkinsGitBranch());
                }
                break;
            case ANDROID:
            case IOS:
                if (projectType == ProjectTypeEnum.IOS.getId()) {
                    JobTestConfig2iOSModel jobTestConfig2IOSModel = JSONObject.parseObject(jobManageModel.getJobTestConfig(), JobTestConfig2iOSModel.class);
                    jobAllConfigVO.setTestVersion(jobTestConfig2IOSModel.getTestVersion());
                    jobAllConfigVO.setProjectNum(jobTestConfig2IOSModel.getProjectVersion());
                } else {
                    JobTestConfig2AndroidModel jobTestConfig2AndroidModel = JSONObject.parseObject(jobManageModel.getJobTestConfig(), JobTestConfig2AndroidModel.class);
                    testTime = jobTestConfig2AndroidModel.getTestTime();
                    jobAllConfigVO.setTestVersion(jobTestConfig2AndroidModel.getTestVersion());
                    jobAllConfigVO.setProjectNum(jobTestConfig2AndroidModel.getBuildNum());
                }
                break;
            default:
                break;
        }
        log.info("transferToVo testTime is {}", testTime);
        // 测试时间格式前端转化
        if (testTime != null){
            List<String> list = DateUtils.turnTimeFormatBatch(testTime,
                    DateFormatStr.DATE_FORMAT_DO, DateFormatStr.DATE_FORMAT_TIME_STAMP);
            log.info("transferToVo testTimeList is {}", list);
            List<Long> timeStamps = new ArrayList<>();
            for (String timestampStr: list
                 ) {
                timeStamps.add(Long.parseLong(timestampStr));
            }
            jobAllConfigVO.setTestTime(timeStamps);
        }
    }

    /**
     * 将jobManageParam的部分参数转换为jobManageModel中TestConfig
     * @param projectType
     * @param jobManageParam
     * @param jobManageModel
     * @return
     */
    public ApiResponse<Object> checkAndTransfer(int projectType, int jobType, JobManageParam jobManageParam, JobManageModel jobManageModel, String gitAddress, boolean isUpdate) {

        // 测试时间格式落库转化
        if (!CollectionUtils.isEmpty(jobManageParam.getTestTime())){
            List<String> list = DateUtils.turnTimeFormatBatch(jobManageParam.getTestTime(),
                    DateFormatStr.DATE_FORMAT_TIME_STAMP, DateFormatStr.DATE_FORMAT_DO);
            if (CollectionUtils.isEmpty(list)){
                return ApiResponse.buildFailure("测试时间格式错误,期望格式为时间戳");
            }
            if (Long.parseLong(jobManageParam.getTestTime().get(0)) >= Long.parseLong(jobManageParam.getTestTime().get(1))){
                return ApiResponse.buildFailure("测试时间中开始时间应该小于结束时间");
            }
            jobManageParam.setTestTime(list);
        }
        if (jobManageParam.getTestTime() == null){
            jobManageParam.setTestTime(new ArrayList<>());
        }
        String jobTestConfigStr = null;
        JobAutoTestConfigModel jobAutoTestConfigModel = new JobAutoTestConfigModel();
        ProjectTypeEnum projectTypeEnum = ProjectTypeEnum.getById(projectType);
        jobManageModel.setJobTestType(jobType);
        switch (projectTypeEnum){
            // PC i版 MRN
            case PC:
            case I_VERSION:
                if (CollectionUtils.isEmpty(jobManageParam.getDeployHost())) {
                    return ApiResponse.buildFailure("主机名不能为空");
                }
                if (!FormatUtils.formatJudgeBatch(jobManageParam.getDeployHost(), FormatUtils.IS_LETTER_OR_NUMBER)){
                    return ApiResponse.buildFailure("主机名只能输入字符和数字，不能输入其他字符（注：请使用英文逗号隔开）");
                }
            case MRN:
                if (!isUpdate && StringUtils.isEmpty(jobManageParam.getTestEnv())) {
                    return ApiResponse.buildFailure("测试环境不能为空");
                }
                if (CollectionUtils.isEmpty(jobManageParam.getTestTime())) {
                    return ApiResponse.buildFailure("测试时间不能为空");
                }

                if (projectType == ProjectTypeEnum.MRN.getId()){
                    JobTestConfig2MRNModel jobTestConfig2MRNModel = (JobTestConfig2MRNModel) getTestConfig(JobTestConfig2MRNModel.class, jobManageModel);
                    if (!isUpdate) {
                        jobTestConfig2MRNModel.setReleaseEnv(jobManageParam.getTestEnv());
                    }
                    jobTestConfig2MRNModel.setTestTime(jobManageParam.getTestTime());
                    jobTestConfigStr = JSONObject.toJSONString(jobTestConfig2MRNModel);
                }else {
                    JobTestConfig2WebModel jobTestConfig2WebModel = (JobTestConfig2WebModel) getTestConfig(JobTestConfig2WebModel.class, jobManageModel);
                    if(!isUpdate) {
                        jobTestConfig2WebModel.setTestEnv(jobManageParam.getTestEnv());
                    }
                    jobTestConfig2WebModel.setDeployHost(jobManageParam.getDeployHost());
                    jobTestConfig2WebModel.setTestTime(jobManageParam.getTestTime());
                    jobTestConfigStr = JSONObject.toJSONString(jobTestConfig2WebModel);
                }
                break;
            // 小程序
            case APPLETS:
                if (CollectionUtils.isEmpty(jobManageParam.getTestTime())) {
                    return ApiResponse.buildFailure("测试时间不能为空");
                }
                if (!isUpdate && StringUtils.isEmpty(jobManageParam.getTestEnv())) {
                    return ApiResponse.buildFailure("测试环境不能为空");
                }
                JobTestConfig2AppletModel jobTestConfig2AppletModel = (JobTestConfig2AppletModel) getTestConfig(JobTestConfig2AppletModel.class, jobManageModel);
                if (!isUpdate) {
                    jobTestConfig2AppletModel.setCommit(StringUtils.isEmpty(jobManageParam.getCommit()) ? "" : jobManageParam.getCommit());
                    jobTestConfig2AppletModel.setTestEnv(jobManageParam.getTestEnv());
                }
                jobTestConfig2AppletModel.setTestTime(jobManageParam.getTestTime());
                jobTestConfigStr = JSONObject.toJSONString(jobTestConfig2AppletModel);
                break;
            // 服务端
            case SERVER:
                if (!isUpdate && StringUtils.isEmpty(jobManageParam.getTestEnv())) {
                    return ApiResponse.buildFailure("测试环境不能为空");
                }
                if (CollectionUtils.isEmpty(jobManageParam.getServerIp())) {
                    return ApiResponse.buildFailure("ip地址不能为空");
                }
                if (!IPUtils.isIpBatch(jobManageParam.getServerIp())){
                    return ApiResponse.buildFailure("IP地址格式不对，请调整后重试");
                }
                if (CollectionUtils.isEmpty(jobManageParam.getAgentPort())) {
                    return ApiResponse.buildFailure("agentPort不能为空");
                }
                if (!FormatUtils.formatJudgeBatch(jobManageParam.getAgentPort(), FormatUtils.IS_NUMBER)){
                    return ApiResponse.buildFailure("agentPort只能输入数字，不能输入其他字符（注：请使用英文逗号隔开）");
                }
                if (jobManageParam.getServerIp().size() != jobManageParam.getAgentPort().size()){
                    return ApiResponse.buildFailure("serverIp元素个数和AgentPort元素个数不一致,请调整后重试");
                }
                if (!isUpdate && jobManageParam.getReleaseId() < 1) {
                    return ApiResponse.buildFailure("发布项Id不能小于1");
                }
                if (!StringUtils.isEmpty(gitAddress)){
                    try {
                        if (!serverJobBiz.checkPlusIdIsRight(jobManageParam.getReleaseId(),gitAddress)){
                            return ApiResponse.buildFailure("当前发布项id关联的项目与当前测试项目不匹配，请检查是否填错");
                        }
                    } catch (UserInputException e) {
                        return ApiResponse.buildFailure(e.getMessage());
                    }
                }
                if ("null".equals(String.valueOf(jobType))) {
                    return ApiResponse.buildFailure("jobType不能为空");
                }
                if (jobType == JobTestTypeEnum.INTERFACE_TEST.getType()) {
                    if (StringUtils.isEmpty(jobManageParam.getJenkinsRef())) {
                        return ApiResponse.buildFailure("jenkinsRef不能为空");
                    }
                    try {
                        JenkinsUtils.getJenkinsGitInfo(jobManageParam.getJenkinsRef());
                    } catch (Exception e) {
                        e.printStackTrace();
                        return ApiResponse.buildFailure(e.getMessage());
                    }
                }
                JobTestConfig2ServerModel jobTestConfig2ServerModel = (JobTestConfig2ServerModel) getTestConfig(JobTestConfig2ServerModel.class, jobManageModel);
                if (!isUpdate) {
                    jobTestConfig2ServerModel.setReleaseId(jobManageParam.getReleaseId());
                    jobTestConfig2ServerModel.setTestEnv(jobManageParam.getTestEnv());
                }
                jobTestConfig2ServerModel.setTestTime(jobManageParam.getTestTime());
                jobTestConfig2ServerModel.setAgentPort(jobManageParam.getAgentPort());
                jobTestConfig2ServerModel.setServerIp(jobManageParam.getServerIp());
                jobTestConfigStr = JSONObject.toJSONString(jobTestConfig2ServerModel);

//                接口自动化测试类型
                if(jobType == 1){
                    jobAutoTestConfigModel.setJenkinsRef(jobManageParam.getJenkinsRef());
                    jobAutoTestConfigModel.setJenkinsGitAddress(jobManageParam.getJenkinsGitAddress());
                    jobAutoTestConfigModel.setJenkinsGitBranch(jobManageParam.getJenkinsGitBranch());
                }
                jobManageModel.setJobTestType(jobType);
                break;
            // Android iOS
            case IOS:
            case ANDROID:
                if (!isUpdate && StringUtils.isEmpty(jobManageParam.getTestVersion())) {
                    return ApiResponse.buildFailure("测试版本不能为空");
                }
                if (!isUpdate && jobManageParam.getProjectNum() < 1) {
                    return ApiResponse.buildFailure("项目版本不能小于1");
                }
                if (projectType == ProjectTypeEnum.IOS.getId()) {
                    JobTestConfig2iOSModel jobTestConfig2IOSModel = (JobTestConfig2iOSModel) getTestConfig(JobTestConfig2iOSModel.class, jobManageModel);
                    if (!isUpdate) {
                        jobTestConfig2IOSModel.setTestVersion(jobManageParam.getTestVersion());
                        jobTestConfig2IOSModel.setProjectVersion(jobManageParam.getProjectNum());
                    }
                    jobTestConfigStr = JSONObject.toJSONString(jobTestConfig2IOSModel);
                    break;
                }else {
                    JobTestConfig2AndroidModel jobTestConfig2AndroidModel = (JobTestConfig2AndroidModel) getTestConfig(JobTestConfig2AndroidModel.class, jobManageModel);
                    jobTestConfig2AndroidModel.setTestTime(jobManageParam.getTestTime());
                    if (!isUpdate) {
                        jobTestConfig2AndroidModel.setTestVersion(jobManageParam.getTestVersion());
                        jobTestConfig2AndroidModel.setBuildNum(jobManageParam.getProjectNum());
                    }
                    jobTestConfigStr = JSONObject.toJSONString(jobTestConfig2AndroidModel);
                    break;
                }
        }
        jobManageModel.setJobTestConfig(jobTestConfigStr);
        jobManageModel.setJobAutoTestConfig(jobAutoTestConfigModel);
        return null;
    }


    public Object getTestConfig(Class<?> testConfigClass, JobManageModel jobManageModel){
        Object testConfigObj = null;
        log.info("getTestConfig jobManageMode = {}", jobManageModel);
        log.info("getTestConfig jobManageMode is null --- {}",StringUtils.isEmpty(jobManageModel.getJobTestConfig()));
        if (StringUtils.isEmpty(jobManageModel.getJobTestConfig())){
            try {
                testConfigObj = testConfigClass.newInstance();
            }catch (Exception e){
                log.error("getTestConfig errit = {}", e);
            }
        } else {
            testConfigObj = JSONObject.parseObject(jobManageModel.getJobTestConfig(), testConfigClass);
        }
        log.info("getTestConfig testConfigObj = {}", testConfigObj);
        return testConfigObj;
    }

    public ApiResponse<Object> getAllGitBranchByProjectId(int projectId){
        ProjectManageModel projectManageById = projectManageService.getProjectManageById(projectId);
        log.info("projectManageById = {}", projectManageById);
        if (projectManageById == null){
            return ApiResponse.buildFailure("该projectId不存在, 无法获取到git分支信息, 请确认后重试");
        }
        String gitAddress = projectManageById.getGitAddress();
        String[] gits = gitAddress.split("\\/");
        String str = gits[gits.length - 1];
        int i = str.indexOf(".");
        String branchFileName =str.substring(0, i);
        log.info("gitAddress = {}, branchFileName = {}", gitAddress, branchFileName);
        return ShellUtils.getGitBranch(branchFileName, gitAddress);
    }

    public String getRepositoryRef(String gitAddress){
        String repositoryGroupPath = RepositoryPathUtils.getRepositoryGroupPath(gitAddress);
        if (repositoryGroupPath == null){
            return RepositoryRefConstant.DEFAULT_REPOSITORY_ROUTE;
        }
        return RepositoryRefConstant.REPOSITORY_PREFIX + repositoryGroupPath + RepositoryRefConstant.REPOSITORY_SUFFIX;
    }


    public ApiResponse<Object> getAllJobByProjectId2ChaoYue(int projectId){
        List<JobManageModel> jobManageModels = jobManageService.getJobManageListByProjectId(projectId);
        List<CJobConfigVO> jobConfigVOS = new ArrayList<>();
        if (!CollectionUtils.isEmpty(jobManageModels)){
            for (JobManageModel jobManage: jobManageModels
                 ) {
                CJobConfigVO cJobConfigVO = new CJobConfigVO();
                cJobConfigVO.setId(jobManage.getId());
                cJobConfigVO.setJobName(jobManage.getJobName());
                jobConfigVOS.add(cJobConfigVO);
            }
        }
        return ApiResponse.buildSuccess(jobConfigVOS);
    }
}
