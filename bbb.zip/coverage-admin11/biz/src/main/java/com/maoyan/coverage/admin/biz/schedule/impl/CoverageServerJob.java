package com.maoyan.coverage.admin.biz.schedule.impl;

import com.maoyan.coverage.admin.biz.job.InterfaceJobBiz;
import com.maoyan.coverage.admin.biz.job.ServerJobBiz;
import com.maoyan.coverage.admin.biz.jobmanage.JobOptManageBiz;
import com.maoyan.coverage.admin.biz.projectmanage.ProjectOptManageBiz;
import com.maoyan.coverage.admin.common.exception.JenkinsException;
import com.maoyan.coverage.admin.common.utils.PathUtils;
import com.maoyan.coverage.admin.domain.enums.JobTestTypeEnum;
import com.maoyan.coverage.admin.domain.enums.ProjectTypeEnum;
import com.maoyan.coverage.admin.domain.enums.TimerTypeEnum;
import com.maoyan.coverage.admin.domain.model.job.JobBuildModel;
import com.maoyan.coverage.admin.domain.model.job.WorkSpacePathModel;
import com.maoyan.coverage.admin.domain.model.job.config.ServerTestConfigModel;
import com.maoyan.coverage.admin.domain.model.jobmanage.JobDetailConfigModel;
import com.maoyan.coverage.admin.domain.schema.buildHistory.BuildHistoryDO;
import com.maoyan.coverage.admin.biz.schedule.CoverageJob;
import org.quartz.DisallowConcurrentExecution;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * java 服务端
 *
 * @author lizhuoran05
 * @date 2021/7/9
 */
@DisallowConcurrentExecution
@Service
public class CoverageServerJob extends CoverageJob {

    private final Logger logger = LoggerFactory.getLogger(CoverageServerJob.class);

    @Resource
    ServerJobBiz serverJobBiz;

    @Resource
    JobOptManageBiz jobOptManageBiz;

    @Resource
    ProjectOptManageBiz projectOptManageBiz;

    @Resource
    InterfaceJobBiz interfaceJobBiz;

    /**
     * 循环构建
     *
     * @param context
     * @throws JobExecutionException
     */
    @Override
    public void execute(JobExecutionContext context) {
        JobBuildModel<ServerTestConfigModel> jobBuildModel = null;
        try {
            logger.info("Job: [Server] Job 开始执行");
            jobBuildModel = buildJobBuildModel(context);
            int jobTestType = context.getJobDetail().getJobDataMap().getIntValue("jobTestType");
            switch (JobTestTypeEnum.jobTestTypeEnumMap.get(jobTestType)){
                case INTERFACE_TEST:
                    interfaceJobBiz.build(jobBuildModel);
                    break;
                case DEMAND_TEST:
                    serverJobBiz.build(jobBuildModel);
                    break;
            }
        } catch (Exception e) {
            if (jobBuildModel != null) {
                this.buildFailed(e, "Job: [Server] 构建出现异常", jobBuildModel);
            }
            logger.error("Job: [Server] 构建出现异常", e);
        }
    }

    public JobBuildModel<ServerTestConfigModel> buildJobBuildModel(JobExecutionContext context) {
        JobBuildModel<ServerTestConfigModel> jobBuildModel = new JobBuildModel<>();
        JobDataMap jobDataMap = context.getJobDetail().getJobDataMap();
        int jobConfigId = (int) jobDataMap.get("jobConfigId");
        int timerType = (int) jobDataMap.get("timerType");
        String timerValue = (String) jobDataMap.get("timerValue");
        String builder = (String) jobDataMap.get("builder");
        if (timerType != TimerTypeEnum.IMMEDIATE.getType()) {
            builder = "SYSTEM";
        }
        jobBuildModel.setTimerType(TimerTypeEnum.typeMap.get(timerType));
        jobBuildModel.setTimerValue(timerValue);

        // 创建一条构建记录，部分数据都是初始值
        BuildHistoryDO buildHistoryDO = this.createBuildHistoryDO(jobConfigId, timerType, builder);

        JobDetailConfigModel<ServerTestConfigModel> jobDetailConfigModel = jobOptManageBiz.getServerJobDetailConfigModelByJobConfigId(jobConfigId);
        jobBuildModel.setBuildHistoryId(buildHistoryDO.getId());
        jobBuildModel.setJobConfigId(buildHistoryDO.getJobConfigId());
        jobBuildModel.setBuildNum(buildHistoryDO.getBuildNum());

        WorkSpacePathModel workSpacePathModel = new WorkSpacePathModel(PathUtils.getBaseWorkSpace(ProjectTypeEnum.SERVER, jobDetailConfigModel.getProjectConfigId(), jobConfigId, buildHistoryDO.getBuildNum()));
        workSpacePathModel.setCodeWorkSpacePath(PathUtils.getWorkSpaceOfCode(ProjectTypeEnum.SERVER, jobDetailConfigModel.getProjectConfigId(), jobConfigId, buildHistoryDO.getBuildNum()));
        workSpacePathModel.setDataWorkSpacePath(PathUtils.getWorkSpaceOfData(ProjectTypeEnum.SERVER, jobDetailConfigModel.getProjectConfigId(), jobConfigId, buildHistoryDO.getBuildNum()));
        workSpacePathModel.setReportWorkSpacePath(PathUtils.getWorkSpaceOfReport(ProjectTypeEnum.SERVER, jobDetailConfigModel.getProjectConfigId(), jobConfigId, buildHistoryDO.getBuildNum()));

        jobBuildModel.setWorkSpacePath(workSpacePathModel);
        jobBuildModel.setBaseConfig(jobDetailConfigModel.getBasicConfig());
        jobBuildModel.setTestConfig(jobDetailConfigModel.getTestConfig());
        jobBuildModel.setProjectInfo(projectOptManageBiz.getProjectInfoModelByProjectId(jobDetailConfigModel.getProjectConfigId()));

        return jobBuildModel;
    }

}
