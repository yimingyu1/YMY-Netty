package com.maoyan.coverage.admin.biz.job;

import com.maoyan.coverage.admin.biz.data.AndroidDataStoreBiz;
import com.maoyan.coverage.admin.biz.data.ServerDataStoreBiz;
import com.maoyan.coverage.admin.biz.s3.S3Biz;
import com.maoyan.coverage.admin.common.PropUtil;
import com.maoyan.coverage.admin.common.utils.ShellUtils;
import com.maoyan.coverage.admin.common.utils.XMPubUtil;
import com.maoyan.coverage.admin.domain.enums.*;
import com.maoyan.coverage.admin.domain.model.data.*;
import com.maoyan.coverage.admin.domain.model.job.*;
import com.maoyan.coverage.admin.domain.model.job.config.IOSTestConfigModel;
import com.maoyan.coverage.admin.domain.model.job.config.TestConfigModel;
import com.maoyan.coverage.admin.domain.model.job.msg.BuildSuccessMsgModel;
import com.maoyan.coverage.admin.domain.model.job.result.AndroidJobBuildResultModel;
import com.maoyan.coverage.admin.domain.model.job.result.ServerJobBuildResultModel;
import com.maoyan.coverage.admin.domain.model.jobmanage.BuildHistoryModel;
import com.maoyan.coverage.admin.domain.model.jobmanage.JobBaseConfigModel;
import com.maoyan.coverage.admin.service.buildmanage.IBuildHistoryService;
import org.jacoco.core.analysis.IBundleCoverage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @author lizhuoran05
 * @date 2021/8/2
 */
@Service
public class BaseJobBiz {

    @Autowired
    S3Biz s3Biz;

    @Autowired
    AndroidDataStoreBiz androidDataStoreBiz;

    @Autowired
    ServerDataStoreBiz serverDataStoreBiz;

    @Autowired
    private IBuildHistoryService buildHistoryService;

    private static final String ORIGIN = "origin";

    private static final String CURRENT = "current";

    /**
     * 增量报告时使用，拉取当前测试分支代码
     *
     * @param projectInfoModel   项目信息对象
     * @param jobBaseConfigModel job基础配置对象
     * @param workSpacePathModel 工作区路径对象
     */
    protected String cloneCurrentBranchCode(ProjectInfoModel projectInfoModel, JobBaseConfigModel jobBaseConfigModel, WorkSpacePathModel workSpacePathModel) {
        String gitUrl = projectInfoModel.getGitAddress();
        String currentBranch = jobBaseConfigModel.getCurrentBranch();
        String codePath = workSpacePathModel.getCodeWorkSpacePath() + CURRENT;
        boolean res = ShellUtils.cloneCode(gitUrl, currentBranch, codePath);
        return codePath;
    }

    /**
     * 增量报告时使用，拉取对比分支的代码
     *
     * @param projectInfoModel   项目信息对象
     * @param jobBaseConfigModel job基础配置对象
     * @param workSpacePathModel 工作区路径对象
     */
    protected String cloneOriginBranchCode(ProjectInfoModel projectInfoModel, JobBaseConfigModel jobBaseConfigModel, WorkSpacePathModel workSpacePathModel) {
        String gitUrl = projectInfoModel.getGitAddress();
        String originBranch = jobBaseConfigModel.getOriginBranch();
        String codePath = workSpacePathModel.getCodeWorkSpacePath() + ORIGIN;
        boolean res = ShellUtils.cloneCode(gitUrl, originBranch, codePath);
        return codePath;
    }

    /**
     * 全量报告时使用，拉取当前测试分支代码
     *
     * @param projectInfoModel   项目信息对象
     * @param jobBaseConfigModel job基础配置对象
     * @param workSpacePathModel 工作区路径对象
     */
    protected void cloneBranchCode(ProjectInfoModel projectInfoModel, JobBaseConfigModel jobBaseConfigModel, WorkSpacePathModel workSpacePathModel) {
        String gitUrl = projectInfoModel.getGitAddress();
        String branch = jobBaseConfigModel.getOriginBranch();
        String codePath = workSpacePathModel.getCodeWorkSpacePath();
        boolean res = ShellUtils.cloneCode(gitUrl, branch, codePath);
    }

    /**
     * 服务端调用
     * 功能：上传报告、存储构建结果、更新构建历史、发送通知消息
     *
     * @param jobBuildModel           构建参数对象
     * @param jobJavaBuildResultModel 构建结果对象
     */
    protected void buildSuccess(JobBuildModel<? extends TestConfigModel> jobBuildModel, ServerJobBuildResultModel jobJavaBuildResultModel) {
        JobBaseConfigModel jobBaseConfigModel = jobBuildModel.getBaseConfig();
        WorkSpacePathModel workSpacePathModel = jobBuildModel.getWorkSpacePath();
        com.maoyan.coverage.jacocoplus.core.analysis.IBundleCoverage coverageResult = jobJavaBuildResultModel.getCoverageResult();

        ReportTypeEnum reportTypeEnum = ReportTypeEnum.typeMap.get(jobBaseConfigModel.getReportType());
        Double threshold = jobBaseConfigModel.getThreshold();
        Integer buildHistoryId = jobBuildModel.getBuildHistoryId();

        // 上传报告，返回报告文件夹的链接
        String reportBaseUrl = uploadReportFile(jobBuildModel, jobJavaBuildResultModel.getS3Env());

        // 存储数据，参数多，将数据插入到 build_detail
        serverDataStoreBiz.store(reportTypeEnum, coverageResult, buildHistoryId, reportBaseUrl, threshold, jobBuildModel);

        // 更新 buildHistory
        updateBuildHistory(buildHistoryId, jobJavaBuildResultModel.getCommit(),
                serverDataStoreBiz.buildDataIndicatorsCounter(coverageResult.getBranchCounter()),
                serverDataStoreBiz.buildDataIndicatorsCounter(coverageResult.getLineCounter()));

        this.sendSuccessMsg(jobBuildModel);

        // 删除 workspace
        this.removeWorkSpaceContent(workSpacePathModel.getBaseWorkSpacePath());
    }

    /**
     * 安卓端调用
     * 功能：上传报告、存储构建结果、更新构建历史、发送通知消息
     *
     * @param jobBuildModel           构建参数对象
     * @param jobJavaBuildResultModel 构建结果对象
     */
    protected void buildSuccess(JobBuildModel<? extends TestConfigModel> jobBuildModel, AndroidJobBuildResultModel jobJavaBuildResultModel) {
        JobBaseConfigModel jobBaseConfigModel = jobBuildModel.getBaseConfig();
        IBundleCoverage coverageResult = jobJavaBuildResultModel.getCoverageResult();
        WorkSpacePathModel workSpacePathModel = jobBuildModel.getWorkSpacePath();

        ReportTypeEnum reportTypeEnum = ReportTypeEnum.typeMap.get(jobBaseConfigModel.getReportType());
        Double threshold = jobBaseConfigModel.getThreshold();
        Integer buildHistoryId = jobBuildModel.getBuildHistoryId();

        // 上传报告，返回报告文件夹的链接
        String reportBaseUrl = uploadReportFile(jobBuildModel);

        // 存储数据，参数多，将数据插入到 build_detail
        androidDataStoreBiz.store(reportTypeEnum, coverageResult, buildHistoryId, reportBaseUrl, threshold);

        // 更新 buildHistory
        updateBuildHistory(buildHistoryId, jobJavaBuildResultModel.getCommit(),
                androidDataStoreBiz.buildDataIndicatorsCounter(coverageResult.getBranchCounter()),
                androidDataStoreBiz.buildDataIndicatorsCounter(coverageResult.getLineCounter()));

        this.sendSuccessMsg(jobBuildModel);

        // 删除该buildNum的workSpace
        this.removeWorkSpaceContent(workSpacePathModel.getBaseWorkSpacePath());
    }

    /**
     * 前端调用
     *
     * @param jobBuildModel
     * @param buildResultDataModel
     */
    protected void buildSuccess(JobBuildModel<? extends TestConfigModel> jobBuildModel, FrontBuildResultDataModel buildResultDataModel) {
        Integer buildHistoryId = jobBuildModel.getBuildHistoryId();

        ArrayList<DataIndicatorsModel> dataIndicatorsModels = buildResultDataModel.getDataIndicators();
        Map<String, DataIndicatorsModel> dataIndicatorsCounterHashMap = dataIndicatorsModels.stream().collect(Collectors.toMap(DataIndicatorsModel::getKey, d -> d));

        // 往 buildDetail 中插入
        androidDataStoreBiz.store(dataIndicatorsModels, buildHistoryId, buildResultDataModel.getReportUrl());

        DataIndicatorsModel line;
        DataIndicatorsModel branch;
        if (buildResultDataModel.getReportType().equals(ReportTypeEnum.FULL_REPORT)) {
            line = dataIndicatorsCounterHashMap.get("lines");
            branch = dataIndicatorsCounterHashMap.get("branches");
        } else {
            line = dataIndicatorsCounterHashMap.get("incrementLines");
            branch = dataIndicatorsCounterHashMap.get("incrementBranches");
        }


        // 更新 buildHistory
        updateBuildHistory(buildHistoryId, buildResultDataModel.getCommit(),
                androidDataStoreBiz.buildDataIndicatorsCounter(branch.getCovered(), branch.getTotal()),
                androidDataStoreBiz.buildDataIndicatorsCounter(line.getCovered(), line.getTotal()));

        this.sendSuccessMsg(jobBuildModel);
    }

    /**
     * iOS 调用
     *
     * @param jobBuildModel
     * @param buildResultDataModel
     */
    protected void buildSuccess(JobBuildModel<IOSTestConfigModel> jobBuildModel, IOSBuildResultDataModel buildResultDataModel) {
        Integer buildHistoryId = jobBuildModel.getBuildHistoryId();

        ArrayList<DataIndicatorsModel> dataIndicatorsModels = buildResultDataModel.getDataIndicators();
        Map<String, DataIndicatorsModel> dataIndicatorsCounterHashMap = dataIndicatorsModels.stream().collect(Collectors.toMap(DataIndicatorsModel::getKey, d -> d));

        // 往 buildDetail 中插入
        androidDataStoreBiz.store(dataIndicatorsModels, buildHistoryId, buildResultDataModel.getReportUrl());

        DataIndicatorsModel line = dataIndicatorsCounterHashMap.get("lines");
        DataIndicatorsModel branch = dataIndicatorsCounterHashMap.get("branches");

        // 更新 buildHistory
        updateBuildHistory(buildHistoryId, buildResultDataModel.getCommit(),
                androidDataStoreBiz.buildDataIndicatorsCounter(branch.getCovered(), branch.getTotal()),
                androidDataStoreBiz.buildDataIndicatorsCounter(line.getCovered(), line.getTotal()));

        // TODO 成功后发消息
    }


    /**
     * 传递报告路径
     *
     * @param jobBuildModel 本地报告路径，获取方式workSpaceModel.getReportWorkSpacePath
     * @return s3上报告的路径，只到文件夹级别，后续可自行拼接文件名称
     */
    public String uploadReportFile(JobBuildModel<? extends TestConfigModel> jobBuildModel) {
        ProjectInfoModel projectInfoModel = jobBuildModel.getProjectInfo();
        ProjectTypeEnum projectType = projectInfoModel.getProjectType();
        String projectName = projectInfoModel.getRepositoryName();
        Integer jobId = jobBuildModel.getJobConfigId();
        Integer buildNum = jobBuildModel.getBuildNum();
        String reportPath = jobBuildModel.getWorkSpacePath().getReportWorkSpacePath();

        return s3Biz.uploadReports(projectType, projectName, jobId, buildNum, reportPath);
    }

    /**
     * 传递报告路径
     * 服务端调用
     * @param jobBuildModel 本地报告路径，获取方式workSpaceModel.getReportWorkSpacePath
     * @param s3Env 需要区分环境前缀
     * @return s3上报告的路径，只到文件夹级别，后续可自行拼接文件名称
     */
    public String uploadReportFile(JobBuildModel<? extends TestConfigModel> jobBuildModel, String s3Env) {
        ProjectInfoModel projectInfoModel = jobBuildModel.getProjectInfo();
        ProjectTypeEnum projectType = projectInfoModel.getProjectType();
        String projectName = projectInfoModel.getRepositoryName();
        Integer jobId = jobBuildModel.getJobConfigId();
        Integer buildNum = jobBuildModel.getBuildNum();
        String reportPath = jobBuildModel.getWorkSpacePath().getReportWorkSpacePath();

        // 上传报告, 先在线下测试
        return s3Biz.uploadReportsWithEnv(projectType, projectName, jobId, buildNum, reportPath, s3Env);
    }

    // 更新构建结果buildHistory信息
    private void updateBuildHistory(Integer buildHistoryId, String commit, DataIndicatorsCounter branch, DataIndicatorsCounter line) {
        // 数据库中查询 BuildHistoryModel
        BuildHistoryModel buildHistoryModel = buildHistoryService.getBuildHistoryModelById(buildHistoryId);

        // 更新结束时间
        buildHistoryModel.setEndTime(LocalDateTime.now());
        // 更新 commit
        buildHistoryModel.setCommit(commit);

        // 补全数据
        buildHistoryModel.setLineNum(line.getTotal());
        buildHistoryModel.setLinesCovered(line.getCovered());
        buildHistoryModel.setBranches(branch.getTotal());
        buildHistoryModel.setBranchesCovered(branch.getCovered());
        // 更新状态
        buildHistoryModel.setBuildStatus(JobBuildStatusEnum.END.getType());
        buildHistoryModel.setBuildResult(JobBuildResultEnum.SUCCESS.getType());

        buildHistoryService.update(buildHistoryModel);
    }

    private void sendSuccessMsg(JobBuildModel<? extends TestConfigModel> jobBuildModel) {
        String frontBaseUrl = PropUtil.getProperty("front.domain");
        int jobConfigId = jobBuildModel.getJobConfigId();

        ProjectInfoModel projectInfoModel = jobBuildModel.getProjectInfo();
        BuildSuccessMsgModel buildSuccessMsgModel = new BuildSuccessMsgModel();

        buildSuccessMsgModel.setJobName(jobBuildModel.getBaseConfig().getJobName());
        buildSuccessMsgModel.setCurrentTime(LocalDateTime.now());
        buildSuccessMsgModel.setProjectLeader(projectInfoModel.getProjectLeader());
        buildSuccessMsgModel.setProjectName(ShellUtils.getRepositoryName(projectInfoModel.getGitAddress()));
        buildSuccessMsgModel.setBuildHistoryUrl(frontBaseUrl + "/#/jobhistory?jobId=" + jobConfigId);
        buildSuccessMsgModel.setReportDetailUrl(frontBaseUrl + "/#/covreport?id=" + jobBuildModel.getBuildHistoryId());

        XMPubUtil.sendMessage(buildSuccessMsgModel.getMsg(), projectInfoModel.getProjectLeader());
    }

    /**
     * 获取Job的报告类型
     *
     * @param reportType reportType
     * @return ReportTypeEnum
     */
    protected ReportTypeEnum getReportType(Integer reportType) {
        return ReportTypeEnum.typeMap.get(reportType);
    }

    private void removeWorkSpaceContent(String localPath) {
        ShellUtils.rmDir(localPath);
    }
}
