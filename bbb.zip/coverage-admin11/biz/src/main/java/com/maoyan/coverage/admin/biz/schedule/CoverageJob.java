package com.maoyan.coverage.admin.biz.schedule;

import com.alibaba.fastjson.JSONObject;
import com.maoyan.coverage.admin.biz.build.BuildHistoryManageBiz;
import com.maoyan.coverage.admin.biz.jobmanage.JobOptManageBiz;
import com.maoyan.coverage.admin.biz.projectmanage.ProjectOptManageBiz;
import com.maoyan.coverage.admin.common.PropUtil;
import com.maoyan.coverage.admin.common.exception.CoverageUserOptBaseException;
import com.maoyan.coverage.admin.common.exception.DeveloperConfigException;
import com.maoyan.coverage.admin.common.exception.UserInputException;
import com.maoyan.coverage.admin.common.utils.BuildUtils;
import com.maoyan.coverage.admin.common.utils.ShellUtils;
import com.maoyan.coverage.admin.common.utils.XMPubUtil;
import com.maoyan.coverage.admin.domain.enums.JobBuildResultEnum;
import com.maoyan.coverage.admin.domain.enums.JobBuildStatusEnum;
import com.maoyan.coverage.admin.domain.enums.JobBuildTypeEnum;
import com.maoyan.coverage.admin.domain.enums.TimerTypeEnum;
import com.maoyan.coverage.admin.domain.model.job.JobBuildModel;
import com.maoyan.coverage.admin.domain.model.job.ProjectInfoModel;
import com.maoyan.coverage.admin.domain.model.job.config.TestConfigModel;
import com.maoyan.coverage.admin.domain.model.job.msg.BuildFailedToDeveloperMsgModel;
import com.maoyan.coverage.admin.domain.model.job.msg.BuildFailedToUserMsgModel;
import com.maoyan.coverage.admin.domain.model.job.msg.DumpFailedToUserMsgModel;
import com.maoyan.coverage.admin.domain.model.jobmanage.BuildHistoryModel;
import com.maoyan.coverage.admin.domain.model.jobmanage.JobBaseConfigModel;
import com.maoyan.coverage.admin.domain.model.jobmanage.JobConfigModel;
import com.maoyan.coverage.admin.domain.model.jobmanage.JobManageModel;
import com.maoyan.coverage.admin.domain.schema.buildHistory.BuildHistoryDO;
import lombok.extern.slf4j.Slf4j;
import org.quartz.InterruptableJob;
import org.quartz.JobExecutionContext;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

/**
 * @author lizhuoran05
 * @date 2021/7/9
 */
@Slf4j
public abstract class CoverageJob implements InterruptableJob {

    @Resource
    JobOptManageBiz jobOptManageBiz;

    @Resource
    BuildHistoryManageBiz buildHistoryBiz;

    @Resource
    ProjectOptManageBiz projectOptManageBiz;

    protected boolean _interrupted = false;

    public abstract JobBuildModel<? extends TestConfigModel> buildJobBuildModel(JobExecutionContext context);

    public BuildHistoryDO createBuildHistoryDO(int jobConfigId, int timerType, String builder) {
        JobManageModel jobManageModel = jobOptManageBiz.getJobManageModelByJobConfigId(jobConfigId);
        BuildHistoryDO buildHistoryDO = new BuildHistoryDO();
        buildHistoryDO.setJobConfigId(jobConfigId);
        buildHistoryDO.setBuildNum(BuildUtils.getInsertBuildNum(jobConfigId));
        // 定时构建触发 或者 手动构建触发
        buildHistoryDO.setBuilder(builder);
        buildHistoryDO.setBuildType(timerType == TimerTypeEnum.IMMEDIATE.getType() ? JobBuildTypeEnum.MANUAL.getType() : JobBuildTypeEnum.TIMING.getType());

        buildHistoryDO.setStartTime(LocalDateTime.now());
        // endTime 要在构建结束后更新
        buildHistoryDO.setEndTime(LocalDateTime.now());

        // 插入时还不知道使用的 commit
        buildHistoryDO.setCommit("");

        // 初始Build记录时数据指标都是0
        buildHistoryDO.setLineNum(0);
        buildHistoryDO.setLinesCovered(0);
        buildHistoryDO.setBranches(0);
        buildHistoryDO.setBranchesCovered(0);

        buildHistoryDO.setBuildNum(BuildUtils.getInsertBuildNum(jobConfigId));
        // 初始Build构建记录时的构建状态，构建结果
        buildHistoryDO.setBuildStatus(JobBuildStatusEnum.BUILDING.getType());
        buildHistoryDO.setBuildResult(JobBuildResultEnum.UN_KNOWN.getType());
        // 插入本次构建使用到的配置
        buildHistoryDO.setJobBuildConfig(JSONObject.toJSONString(jobManageModel));
        buildHistoryBiz.createJobBuildRecord(buildHistoryDO);
        return buildHistoryDO;
    }


    /**
     * Job 中断的逻辑：暂不考虑
     * 立即执行的Job目前不准备提供中断的功能：Job提交之后就不能关闭了，只能执行完毕。
     * 定时构建的Job，如果中断：算一种极端情况，在Job恰好构建中时，关闭掉定时构建，这时也可以接受Job继续执行
     */
    public void interrupt(JobExecutionContext context) {
        this.interrupt();
    }

    public void interrupt() {
    }


    /**
     * 发送错误信息给开发者
     */
    protected void sendBuildErrorMsgToDeveloper(Exception error, JobBuildModel<? extends TestConfigModel> jobBuildModel, String info) {
        String frontBaseUrl = PropUtil.getProperty("front.domain");
        int jobConfigId = jobBuildModel.getJobConfigId();
        JobConfigModel jobConfigModel = jobOptManageBiz.getJobConfigModelByJobConfigId(jobConfigId);
        ProjectInfoModel projectInfoModel = projectOptManageBiz.getProjectInfoModelByProjectId(jobConfigModel.getProjectConfigId());

        BuildFailedToDeveloperMsgModel failedDeveloperMsgModel = new BuildFailedToDeveloperMsgModel();
        failedDeveloperMsgModel.setJobId(jobConfigId);
        failedDeveloperMsgModel.setJobName(jobConfigModel.getJobName());
        failedDeveloperMsgModel.setBuildHistoryUrl(frontBaseUrl + "/#/jobhistory?jobId=" + jobBuildModel.getJobConfigId());
        failedDeveloperMsgModel.setProjectName(ShellUtils.getRepositoryName(projectInfoModel.getGitAddress()));
        failedDeveloperMsgModel.setError(buildErrorMsg(error));
        failedDeveloperMsgModel.setBuildNum(jobBuildModel.getBuildNum());

        failedDeveloperMsgModel.setRemarks(error instanceof DeveloperConfigException ? error.getMessage() : "");
        failedDeveloperMsgModel.setInfo(info);


        XMPubUtil.sendToDeveloper(failedDeveloperMsgModel.getMsg());
    }

    private String buildErrorMsg(Exception error) {
        return error.getClass() + ":" + error.getMessage() + "\n" + Arrays.toString(error.getStackTrace());
    }

    /**
     * 构建过程中异常，发送给项目负责人
     * 及开发者
     */
    protected void sendErrorMsgToProjectLeader(String msg, List<String> misIds) {
        XMPubUtil.sendMessage(msg, misIds);
    }

    /**
     * dump 出现异常时调用
     *
     * @param error         异常
     * @param info          信息提示
     * @param jobBuildModel 构建参数
     */
    protected void dumpFailed(Exception error, String info, JobBuildModel<? extends TestConfigModel> jobBuildModel) {
        ProjectInfoModel projectInfoModel = jobBuildModel.getProjectInfo();

        // 构建失败，发送消息通知给项目负责人
        // 通知 JobId、buildNum、构建历史链接

        DumpFailedToUserMsgModel dumpFailedToUserMsgModel = new DumpFailedToUserMsgModel();
        dumpFailedToUserMsgModel.setJobName(jobBuildModel.getBaseConfig().getJobName());
        dumpFailedToUserMsgModel.setProjectName(ShellUtils.getRepositoryName(projectInfoModel.getGitAddress()));
        dumpFailedToUserMsgModel.setRemarks(error instanceof UserInputException ? error.getMessage() : "请联系覆盖率平台开发同学");
        dumpFailedToUserMsgModel.setProjectLeader(projectInfoModel.getProjectLeader());
        // dump 失败发送给用户
        sendErrorMsgToProjectLeader(dumpFailedToUserMsgModel.getMsg(), projectInfoModel.getProjectLeader());
        // dump 失败发送给开发者
        sendBuildErrorMsgToDeveloper(error, jobBuildModel, info);
    }

    /**
     * 构建失败时调用
     *
     * @param error         异常
     * @param info          信息提示
     * @param jobBuildModel 构建参数
     */
    protected void buildFailed(Exception error, String info, JobBuildModel<? extends TestConfigModel> jobBuildModel) {
        int buildHistoryId = jobBuildModel.getBuildHistoryId();
        BuildHistoryModel buildHistoryModel = buildHistoryBiz.getBuildHistoryModelById(buildHistoryId);
        ProjectInfoModel projectInfoModel = jobBuildModel.getProjectInfo();

        // 更新结束时间
        buildHistoryModel.setEndTime(LocalDateTime.now());
        // 更新状态
        buildHistoryModel.setBuildStatus(JobBuildStatusEnum.END.getType());
        buildHistoryModel.setBuildResult(JobBuildResultEnum.FAIL.getType());

        buildHistoryBiz.update(buildHistoryModel);

        // 构建失败，发送消息通知给项目负责人
        // 通知 JobId、buildNum、构建历史链接
        BuildFailedToUserMsgModel failedUserMsgModel = buildFailedMsgModel(jobBuildModel, error instanceof CoverageUserOptBaseException ? error.getMessage() : "请联系覆盖率平台开发同学");
        sendErrorMsgToProjectLeader(failedUserMsgModel.getMsg(), projectInfoModel.getProjectLeader());

        sendBuildErrorMsgToDeveloper(error, jobBuildModel, info);
    }

    private BuildFailedToUserMsgModel buildFailedMsgModel(JobBuildModel<? extends TestConfigModel> jobBuildModel, String remarks) {
        String frontBaseUrl = PropUtil.getProperty("front.domain");
        JobBaseConfigModel jobBaseConfigModel = jobBuildModel.getBaseConfig();
        ProjectInfoModel projectInfoModel = jobBuildModel.getProjectInfo();

        BuildFailedToUserMsgModel failedMsgModel = new BuildFailedToUserMsgModel();

        failedMsgModel.setJobName(jobBaseConfigModel.getJobName());
        failedMsgModel.setBuildNum(jobBuildModel.getBuildNum());
        failedMsgModel.setBuildHistoryUrl(frontBaseUrl + "/#/jobhistory?jobId=" + jobBuildModel.getJobConfigId());
        failedMsgModel.setProjectName(ShellUtils.getRepositoryName(projectInfoModel.getGitAddress()));
        failedMsgModel.setRemarks(remarks);
        failedMsgModel.setProjectLeader(projectInfoModel.getProjectLeader());

        return failedMsgModel;
    }
}
