package com.maoyan.coverage.admin.biz.schedule.impl;

import com.maoyan.coverage.admin.biz.job.FrontJobBiz;
import com.maoyan.coverage.admin.biz.jobmanage.JobOptManageBiz;
import com.maoyan.coverage.admin.biz.projectmanage.ProjectOptManageBiz;
import com.maoyan.coverage.admin.common.utils.PathUtils;
import com.maoyan.coverage.admin.domain.enums.ProjectTypeEnum;
import com.maoyan.coverage.admin.domain.enums.TimerTypeEnum;
import com.maoyan.coverage.admin.domain.model.job.JobBuildModel;
import com.maoyan.coverage.admin.domain.model.job.WorkSpacePathModel;
import com.maoyan.coverage.admin.domain.model.job.config.*;
import com.maoyan.coverage.admin.domain.model.jobmanage.JobDetailConfigModel;
import com.maoyan.coverage.admin.domain.schema.buildHistory.BuildHistoryDO;
import com.maoyan.coverage.admin.biz.schedule.CoverageJob;
import org.quartz.DisallowConcurrentExecution;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.annotation.Resource;

/**
 * PC、小程序、i版
 *
 * @author lizhuoran05
 * @date 2021/7/12
 */
@DisallowConcurrentExecution
public class CoverageFrontJob extends CoverageJob {

    private final Logger logger = LoggerFactory.getLogger(CoverageFrontJob.class);

    @Resource
    FrontJobBiz frontJobBiz;

    @Resource
    JobOptManageBiz jobOptManageBiz;

    @Resource
    ProjectOptManageBiz projectOptManageBiz;

    @Override
    public void execute(JobExecutionContext context) {
        JobBuildModel<WebTestConfigModel> webJobBuildModel = null;
        JobBuildModel<MRNTestConfigModel> mrnJobBuildModel = null;
        JobBuildModel<AppletTestConfigModel> appLetJobBuildModel = null;
        ProjectTypeEnum projectTypeEnum = null;
        try {
            logger.info("Job: [Front] Job 开始执行");
            JobDataMap jobDataMap = context.getJobDetail().getJobDataMap();
            int projectType = (int) jobDataMap.get("projectType");
            projectTypeEnum = ProjectTypeEnum.typeMap.get(projectType);
            if (projectTypeEnum.equals(ProjectTypeEnum.APPLETS)) {
                appLetJobBuildModel = buildAppletJobBuildModel(context);
                buildAppletJob(appLetJobBuildModel);
            }
            if (projectTypeEnum.equals(ProjectTypeEnum.I_VERSION) || projectTypeEnum.equals(ProjectTypeEnum.PC)) {
                webJobBuildModel = buildWebJobBuildModel(context, projectTypeEnum);
                buildWebJob(webJobBuildModel);
            }
            if (projectTypeEnum.equals(ProjectTypeEnum.MRN)) {
                mrnJobBuildModel = buildMRNJobBuildModel(context);
                buildMRNJob(mrnJobBuildModel);
            }
        } catch (Exception e) {
            assert projectTypeEnum != null;
            if (projectTypeEnum.equals(ProjectTypeEnum.APPLETS) && appLetJobBuildModel != null) {
                this.buildFailed(e, "Job: [小程序] 构建出现异常", appLetJobBuildModel);
            }
            if ((projectTypeEnum.equals(ProjectTypeEnum.I_VERSION) || projectTypeEnum.equals(ProjectTypeEnum.PC)) && webJobBuildModel != null) {
                this.buildFailed(e, "Job: [web] 构建出现异常", webJobBuildModel);
            }
            if (projectTypeEnum.equals(ProjectTypeEnum.MRN) && mrnJobBuildModel != null) {
                this.buildFailed(e, "Job: [MRN] 构建出现异常", mrnJobBuildModel);
            }
            logger.error("Job: [Front] 构建出现异常", e);
        }
    }

    private void buildMRNJob(JobBuildModel<MRNTestConfigModel> jobBuildModel) {
        frontJobBiz.mrnJobBuild(jobBuildModel);
    }

    private void buildWebJob(JobBuildModel<WebTestConfigModel> jobBuildModel) {
        frontJobBiz.webJobBuild(jobBuildModel);
    }

    private void buildAppletJob(JobBuildModel<AppletTestConfigModel> jobBuildModel) {
        frontJobBiz.appletJobBuild(jobBuildModel);
    }

    /**
     * 基于目前的抽象类接口定义，实现Web类的JobBuildModel构建方法
     */
    @Override
    public JobBuildModel<WebTestConfigModel> buildJobBuildModel(JobExecutionContext context) {
        // 不实现
        return null;
    }

    public JobBuildModel<WebTestConfigModel> buildWebJobBuildModel(JobExecutionContext context, ProjectTypeEnum projectTypeEnum) {
        JobBuildModel<WebTestConfigModel> jobBuildModel = new JobBuildModel<>();
        JobDataMap jobDataMap = context.getJobDetail().getJobDataMap();
        int jobConfigId = (int) jobDataMap.get("jobConfigId");
        int timerType = (int) jobDataMap.get("timerType");
        String timerValue = (String) jobDataMap.get("timerValue");
        String builder = (String) jobDataMap.get("builder");
        if (timerType != TimerTypeEnum.IMMEDIATE.getType()) {
            builder = "SYSTEM";
        }
        jobBuildModel.setTimerType(TimerTypeEnum.typeMap.get(timerType));
        jobBuildModel.setTimerValue(timerValue);

        // 创建一条构建记录，部分数据都是初始值
        BuildHistoryDO buildHistoryDO = this.createBuildHistoryDO(jobConfigId, timerType, builder);

        JobDetailConfigModel<WebTestConfigModel> jobDetailConfigModel = jobOptManageBiz.getWebJobDetailConfigModelByJobConfigId(jobConfigId);
        jobBuildModel.setBuildHistoryId(buildHistoryDO.getId());
        jobBuildModel.setJobConfigId(buildHistoryDO.getJobConfigId());
        jobBuildModel.setBuildNum(buildHistoryDO.getBuildNum());

        WorkSpacePathModel workSpacePathModel = new WorkSpacePathModel(PathUtils.getBaseWorkSpace(projectTypeEnum, jobDetailConfigModel.getProjectConfigId(), jobConfigId, buildHistoryDO.getBuildNum()));
        workSpacePathModel.setCodeWorkSpacePath(PathUtils.getWorkSpaceOfCode(projectTypeEnum, jobDetailConfigModel.getProjectConfigId(), jobConfigId, buildHistoryDO.getBuildNum()));
        workSpacePathModel.setDataWorkSpacePath(PathUtils.getWorkSpaceOfData(projectTypeEnum, jobDetailConfigModel.getProjectConfigId(), jobConfigId, buildHistoryDO.getBuildNum()));
        workSpacePathModel.setReportWorkSpacePath(PathUtils.getWorkSpaceOfReport(projectTypeEnum, jobDetailConfigModel.getProjectConfigId(), jobConfigId, buildHistoryDO.getBuildNum()));

        jobBuildModel.setWorkSpacePath(workSpacePathModel);
        jobBuildModel.setBaseConfig(jobDetailConfigModel.getBasicConfig());
        jobBuildModel.setTestConfig(jobDetailConfigModel.getTestConfig());
        jobBuildModel.setProjectInfo(projectOptManageBiz.getProjectInfoModelByProjectId(jobDetailConfigModel.getProjectConfigId()));

        return jobBuildModel;
    }

    public JobBuildModel<MRNTestConfigModel> buildMRNJobBuildModel(JobExecutionContext context) {
        JobBuildModel<MRNTestConfigModel> jobBuildModel = new JobBuildModel<>();
        JobDataMap jobDataMap = context.getJobDetail().getJobDataMap();
        int jobConfigId = (int) jobDataMap.get("jobConfigId");
        int timerType = (int) jobDataMap.get("timerType");
        String timerValue = (String) jobDataMap.get("timerValue");
        String builder = (String) jobDataMap.get("builder");
        if (timerType != TimerTypeEnum.IMMEDIATE.getType()) {
            builder = "SYSTEM";
        }

        jobBuildModel.setTimerType(TimerTypeEnum.typeMap.get(timerType));
        jobBuildModel.setTimerValue(timerValue);

        // 创建一条构建记录，部分数据都是初始值
        BuildHistoryDO buildHistoryDO = this.createBuildHistoryDO(jobConfigId, timerType, builder);

        JobDetailConfigModel<MRNTestConfigModel> jobDetailConfigModel = jobOptManageBiz.getMRNJobDetailConfigModelByJobConfigId(jobConfigId);
        jobBuildModel.setBuildHistoryId(buildHistoryDO.getId());
        jobBuildModel.setJobConfigId(buildHistoryDO.getJobConfigId());
        jobBuildModel.setBuildNum(buildHistoryDO.getBuildNum());

        WorkSpacePathModel workSpacePathModel = new WorkSpacePathModel(PathUtils.getBaseWorkSpace(ProjectTypeEnum.MRN, jobDetailConfigModel.getProjectConfigId(), jobConfigId, buildHistoryDO.getBuildNum()));
        workSpacePathModel.setCodeWorkSpacePath(PathUtils.getWorkSpaceOfCode(ProjectTypeEnum.MRN, jobDetailConfigModel.getProjectConfigId(), jobConfigId, buildHistoryDO.getBuildNum()));
        workSpacePathModel.setDataWorkSpacePath(PathUtils.getWorkSpaceOfData(ProjectTypeEnum.MRN, jobDetailConfigModel.getProjectConfigId(), jobConfigId, buildHistoryDO.getBuildNum()));
        workSpacePathModel.setReportWorkSpacePath(PathUtils.getWorkSpaceOfReport(ProjectTypeEnum.MRN, jobDetailConfigModel.getProjectConfigId(), jobConfigId, buildHistoryDO.getBuildNum()));

        jobBuildModel.setWorkSpacePath(workSpacePathModel);
        jobBuildModel.setBaseConfig(jobDetailConfigModel.getBasicConfig());
        jobBuildModel.setTestConfig(jobDetailConfigModel.getTestConfig());
        jobBuildModel.setProjectInfo(projectOptManageBiz.getProjectInfoModelByProjectId(jobDetailConfigModel.getProjectConfigId()));

        return jobBuildModel;
    }

    public JobBuildModel<AppletTestConfigModel> buildAppletJobBuildModel(JobExecutionContext context) {
        JobBuildModel<AppletTestConfigModel> jobBuildModel = new JobBuildModel<>();
        JobDataMap jobDataMap = context.getJobDetail().getJobDataMap();
        int jobConfigId = (int) jobDataMap.get("jobConfigId");
        int timerType = (int) jobDataMap.get("timerType");
        String timerValue = (String) jobDataMap.get("timerValue");
        String builder = (String) jobDataMap.get("builder");
        if (timerType != TimerTypeEnum.IMMEDIATE.getType()) {
            builder = "SYSTEM";
        }
        jobBuildModel.setTimerType(TimerTypeEnum.typeMap.get(timerType));
        jobBuildModel.setTimerValue(timerValue);

        // 创建一条构建记录，部分数据都是初始值
        BuildHistoryDO buildHistoryDO = this.createBuildHistoryDO(jobConfigId, timerType, builder);

        JobDetailConfigModel<AppletTestConfigModel> jobDetailConfigModel = jobOptManageBiz.getAppletJobDetailConfigModelByJobConfigId(jobConfigId);
        jobBuildModel.setBuildHistoryId(buildHistoryDO.getId());
        jobBuildModel.setJobConfigId(buildHistoryDO.getJobConfigId());
        jobBuildModel.setBuildNum(buildHistoryDO.getBuildNum());

        WorkSpacePathModel workSpacePathModel = new WorkSpacePathModel(PathUtils.getBaseWorkSpace(ProjectTypeEnum.APPLETS, jobDetailConfigModel.getProjectConfigId(), jobConfigId, buildHistoryDO.getBuildNum()));
        workSpacePathModel.setCodeWorkSpacePath(PathUtils.getWorkSpaceOfCode(ProjectTypeEnum.APPLETS, jobDetailConfigModel.getProjectConfigId(), jobConfigId, buildHistoryDO.getBuildNum()));
        workSpacePathModel.setDataWorkSpacePath(PathUtils.getWorkSpaceOfData(ProjectTypeEnum.APPLETS, jobDetailConfigModel.getProjectConfigId(), jobConfigId, buildHistoryDO.getBuildNum()));
        workSpacePathModel.setReportWorkSpacePath(PathUtils.getWorkSpaceOfReport(ProjectTypeEnum.APPLETS, jobDetailConfigModel.getProjectConfigId(), jobConfigId, buildHistoryDO.getBuildNum()));

        jobBuildModel.setWorkSpacePath(workSpacePathModel);
        jobBuildModel.setBaseConfig(jobDetailConfigModel.getBasicConfig());
        jobBuildModel.setTestConfig(jobDetailConfigModel.getTestConfig());
        jobBuildModel.setProjectInfo(projectOptManageBiz.getProjectInfoModelByProjectId(jobDetailConfigModel.getProjectConfigId()));

        return jobBuildModel;
    }
}
