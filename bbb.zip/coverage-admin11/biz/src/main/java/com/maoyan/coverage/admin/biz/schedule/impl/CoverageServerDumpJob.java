package com.maoyan.coverage.admin.biz.schedule.impl;

import com.maoyan.coverage.admin.biz.job.ServerJobBiz;
import com.maoyan.coverage.admin.biz.jobmanage.JobOptManageBiz;
import com.maoyan.coverage.admin.biz.projectmanage.ProjectOptManageBiz;
import com.maoyan.coverage.admin.biz.schedule.JobManager;
import com.maoyan.coverage.admin.common.utils.PathUtils;
import com.maoyan.coverage.admin.domain.enums.JobTimerTypeEnum;
import com.maoyan.coverage.admin.domain.enums.ProjectTypeEnum;
import com.maoyan.coverage.admin.domain.model.job.JobBuildModel;
import com.maoyan.coverage.admin.domain.model.job.WorkSpacePathModel;
import com.maoyan.coverage.admin.domain.model.job.config.ServerTestConfigModel;
import com.maoyan.coverage.admin.biz.schedule.CoverageJob;
import com.maoyan.coverage.admin.domain.model.jobmanage.JobDetailConfigModel;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * @author lizhuoran05
 * @date 2021/8/22
 */
@Service
public class CoverageServerDumpJob extends CoverageJob {

    private final Logger logger = LoggerFactory.getLogger(CoverageServerDumpJob.class);

    @Autowired
    ServerJobBiz serverJobBiz;

    @Autowired
    CoverageServerJob coverageServerJob;

    @Autowired
    JobOptManageBiz jobOptManageBiz;

    @Autowired
    ProjectOptManageBiz projectOptManageBiz;

    @Autowired
    JobManager jobManager;

    @Override
    public void execute(JobExecutionContext context) {
        JobBuildModel<ServerTestConfigModel> jobBuildModel = null;
        try {
            logger.info("Job: [Server Dump] Job 开始执行");
            jobBuildModel = buildJobBuildModel(context);
            serverJobBiz.dump(jobBuildModel);
        } catch (Exception e) {
            if (jobBuildModel != null) {
                this.dumpFailed(e, "Job: [Server Dump] dump 出现异常", jobBuildModel);
                // 如果 dump 出现异常则关闭 dump
                jobManager.closeCycleBuild(jobBuildModel.getJobConfigId(), JobTimerTypeEnum.SERVER_JOB_DUMP_TIMER.getType());
            }
            logger.error("Job: [Server Dump] dump 出现异常", e);
        }
    }

    public JobBuildModel<ServerTestConfigModel> buildJobBuildModel(JobExecutionContext context) {
        JobBuildModel<ServerTestConfigModel> jobBuildModel = new JobBuildModel<>();
        JobDataMap jobDataMap = context.getJobDetail().getJobDataMap();
        int jobConfigId = (int) jobDataMap.get("jobConfigId");

        JobDetailConfigModel<ServerTestConfigModel> jobDetailConfigModel = jobOptManageBiz.getServerJobDetailConfigModelByJobConfigId(jobConfigId);
        jobBuildModel.setJobConfigId(jobConfigId);
        // buildHistoryId 没有意义
        jobBuildModel.setBuildHistoryId(0);
        // buildNum 没有意义
        jobBuildModel.setBuildNum(0);

        WorkSpacePathModel workSpacePathModel = new WorkSpacePathModel();
        // server/jobId:X/dumpData/xxxx.exec
        workSpacePathModel.setDataWorkSpacePath(PathUtils.getDumpWorkSpaceOfData(ProjectTypeEnum.SERVER, jobDetailConfigModel.getProjectConfigId(), jobConfigId));
        // codePath 没用、reportPath 没用
        workSpacePathModel.setCodeWorkSpacePath("");
        workSpacePathModel.setReportWorkSpacePath("");

        jobBuildModel.setWorkSpacePath(workSpacePathModel);
        jobBuildModel.setBaseConfig(jobDetailConfigModel.getBasicConfig());
        jobBuildModel.setTestConfig(jobDetailConfigModel.getTestConfig());
        jobBuildModel.setProjectInfo(projectOptManageBiz.getProjectInfoModelByProjectId(jobDetailConfigModel.getProjectConfigId()));

        return jobBuildModel;
    }

}
