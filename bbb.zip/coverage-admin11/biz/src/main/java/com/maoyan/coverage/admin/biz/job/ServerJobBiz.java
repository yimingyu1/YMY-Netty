package com.maoyan.coverage.admin.biz.job;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.maoyan.coverage.admin.biz.s3.S3Biz;
import com.maoyan.coverage.admin.biz.s3.S3UtilBiz;
import com.maoyan.coverage.admin.common.S3Util;
import com.maoyan.coverage.admin.common.exception.DeveloperConfigException;
import com.maoyan.coverage.admin.common.exception.UserInputException;
import com.maoyan.coverage.admin.common.utils.DateUtils;
import com.maoyan.coverage.admin.common.utils.HttpUtils;
import com.maoyan.coverage.admin.common.utils.ShellUtils;
import com.maoyan.coverage.admin.common.utils.ZipUtils;
import com.maoyan.coverage.admin.domain.config.DumpClosingConfig;
import com.maoyan.coverage.admin.domain.enums.CoverageTypeEnum;
import com.maoyan.coverage.admin.domain.enums.MTConfigKeyEnum;
import com.maoyan.coverage.admin.domain.model.job.JobBuildModel;
import com.maoyan.coverage.admin.domain.model.job.ProjectInfoModel;
import com.maoyan.coverage.admin.domain.model.job.WorkSpacePathModel;
import com.maoyan.coverage.admin.domain.model.job.config.ServerTestConfigModel;
import com.maoyan.coverage.admin.domain.model.job.result.ServerJobBuildResultModel;
import com.maoyan.coverage.admin.domain.model.job.s3.SearchServerFileModel;
import com.maoyan.coverage.admin.domain.model.job.s3.ExecFileNameModel;
import com.maoyan.coverage.admin.domain.model.jobmanage.JobBaseConfigModel;
import com.maoyan.coverage.jacocoplus.core.analysis.Analyzer;
import com.maoyan.coverage.jacocoplus.core.analysis.CoverageBuilder;
import com.maoyan.coverage.jacocoplus.core.analysis.IBundleCoverage;
import com.maoyan.coverage.jacocoplus.core.data.ExecutionDataWriter;
import com.maoyan.coverage.jacocoplus.core.internal.diff.ClassInfo;
import com.maoyan.coverage.jacocoplus.core.internal.diff.CodeDiff;
import com.maoyan.coverage.jacocoplus.core.internal.merge.ASTAnalyzer;
import com.maoyan.coverage.jacocoplus.core.internal.merge.CommitHistoryDataStore;
import com.maoyan.coverage.jacocoplus.core.internal.merge.CommitMethodInstDataStore;
import com.maoyan.coverage.jacocoplus.core.internal.merge.CommitMethodMD5DataStore;
import com.maoyan.coverage.jacocoplus.core.runtime.RemoteControlReader;
import com.maoyan.coverage.jacocoplus.core.runtime.RemoteControlWriter;
import com.maoyan.coverage.jacocoplus.core.tools.ExecFileLoader;
import com.maoyan.coverage.jacocoplus.report.DirectorySourceFileLocator;
import com.maoyan.coverage.jacocoplus.report.FileMultiReportOutput;
import com.maoyan.coverage.jacocoplus.report.IReportVisitor;
import com.maoyan.coverage.jacocoplus.report.html.HTMLFormatter;
import com.meituan.service.mobile.service.movieconfig.service.MTConfigService;
import org.eclipse.jgit.api.Git;
import org.eclipse.jgit.revwalk.RevCommit;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import org.eclipse.jgit.api.errors.GitAPIException;
import org.springframework.web.client.HttpClientErrorException;

import javax.annotation.Resource;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.*;

@Service
public class ServerJobBiz extends BaseJobBiz {

    private final Logger logger = LoggerFactory.getLogger(ServerJobBiz.class);


    @Resource
    private S3UtilBiz s3UtilBiz;
    private S3Util s3Util = new S3Util();

    @Autowired
    S3Biz s3Biz;

    @Autowired
    private MTConfigService mtConfigService;

    /**
     * 服务端构建逻辑，当用户点击立即构建时或者定时构建到时间时会出发此逻辑
     *
     * @param jobBuildModel 服务端构建逻辑中会用到的参数
     *                      {@link JobBuildModel} 构建逻辑中会使用到的参数
     *                      包括：{@link WorkSpacePathModel}: 工作区路径对象，包括代码存放位置，本地报告存放位置，data存放位置
     *                      {@link JobBaseConfigModel}: Job 的基础配置
     *                      {@link ProjectInfoModel}: 项目的配置信息
     *                      {@link ServerTestConfigModel}: 服务端会使用到的对象
     *                      buildHistoryId: 构建历史Id
     */
    public void build(JobBuildModel<ServerTestConfigModel> jobBuildModel) throws Exception {
        //上传最后一次exec
        dump(jobBuildModel);//上传最后一次exec和mergeclasses
        //去s3上拉取所有exec文件
        Set<String> commitSet = new HashSet<String>();
        //downloadFile(jobBuildModel,commitSet);
        downloadFile(jobBuildModel, commitSet);
        //对commitlist进行排序
        List<String> commitList = new ArrayList<>(commitSet);
        //去s3上拉取该分支所有mergeclasses.zip文件
        downloadMergeclass(jobBuildModel, commitList);
        //clone commit code+解压mergeclasses
        for (int i = 0; i < commitList.size(); i++) {
            String commitId = commitList.get(i);
            ZipUtils.unzip(jobBuildModel.getWorkSpacePath().getDataWorkSpacePath() + commitId + "/" + commitId + "-mergeclasses.zip", jobBuildModel.getWorkSpacePath().getDataWorkSpacePath() + commitId + "/");
            File dir = new File(jobBuildModel.getWorkSpacePath().getDataWorkSpacePath() + commitId + "/mergeclasses");
            if (!dir.isDirectory()) {
                throw new UserInputException("mergeclasses文件夹为空，请检查与被测服务器是否建立信任关系或mergeclasses在服务器存放位置是否正确");
            }
            ShellUtils.cloneCodeByCommit(jobBuildModel.getProjectInfo().getGitAddress(), jobBuildModel.getWorkSpacePath().getCodeWorkSpacePath() + commitId + "/" + jobBuildModel.getProjectInfo().getRepositoryName(), jobBuildModel.getBaseConfig().getCurrentBranch(), commitId);
        }
        List<String> newCommitList = sortCommitList(jobBuildModel, commitList);
        if (newCommitList.size() != commitList.size()) {
            throw new UserInputException("对应分支找不到相应commit，请检查服务器部署分支与创建job所填分支是否一致");
        }
        //覆盖率解析
        // #1 创建基础对象
        List<ClassInfo> diffClassInfos = new ArrayList<ClassInfo>();
        if (jobBuildModel.getBaseConfig().getReportType() == 1) {
             diffClassInfos = CodeDiff.diffBranchToBranch(jobBuildModel.getWorkSpacePath().getCodeWorkSpacePath() + jobBuildModel.getProjectInfo().getRepositoryName(), jobBuildModel.getBaseConfig().getCurrentBranch(), jobBuildModel.getBaseConfig().getOriginBranch());
        }
        else {
            String newCommit = newCommitList.get(0);
            String oldCommit = getOldCommit(jobBuildModel);
            diffClassInfos = CodeDiff.diffTagToTag(jobBuildModel.getWorkSpacePath().getCodeWorkSpacePath() + jobBuildModel.getProjectInfo().getRepositoryName(), jobBuildModel.getBaseConfig().getCurrentBranch(), newCommit, oldCommit);
        }
        CommitMethodMD5DataStore commitMethodMD5DataStore = new CommitMethodMD5DataStore();
        CommitMethodInstDataStore commitMethodInstDataStore = new CommitMethodInstDataStore();
        CommitHistoryDataStore commitHistoryDataStore = new CommitHistoryDataStore(commitMethodMD5DataStore, commitMethodInstDataStore);
        // #2 收集 md5

        for (int i = 0; i < newCommitList.size(); i++) {
            File f = new File(jobBuildModel.getWorkSpacePath().getCodeWorkSpacePath() + newCommitList.get(i));
            String commit = newCommitList.get(i);
            if (f.isDirectory()) {
                File[] commitFile = f.listFiles();
                for (File cf : commitFile) {
                    if (cf.getAbsolutePath().endsWith(jobBuildModel.getProjectInfo().getRepositoryName())) {
                        if (jobBuildModel.getBaseConfig().getReportType() == 0) {
                            fillMD5(commit, cf.getAbsolutePath(), commitMethodMD5DataStore, diffClassInfos);
                        } else {
                            fillMD5(commit, cf.getAbsolutePath(), commitMethodMD5DataStore);
                        }
                    }
                }
            }
        }

        // #3 创建多个 CoverageBuilder 和 ExecFileLoader，应该为每一个 commit 都创建一个
        ArrayList<CoverageBuilder> coverageBuilders = new ArrayList<CoverageBuilder>();
        List<ExecFileLoader> execFileLoaders = new ArrayList<ExecFileLoader>();
        // #4 解析数据，收集数据，最新一次 commit 会合并数据
        for (int i = 0; i < newCommitList.size(); i++) {
            // newest：这个属性是让解析器知道，自己解析的是不是最新 commit，如果是的话，就会去做合并了
            boolean newest = i == newCommitList.size() - 1;
            String commit = newCommitList.get(i);
            File execFile = new File(jobBuildModel.getWorkSpacePath().getDataWorkSpacePath() + commit);

            try {
                CoverageBuilder coverageBuilder = new CoverageBuilder();
                if (jobBuildModel.getBaseConfig().getReportType() == 0) {
                    //增量报告
                    coverageBuilder.diffClassInfos = diffClassInfos;
                }
                ExecFileLoader execFileLoader = loadExecutionData(execFile);

                // 为每个 commit 创建解析器，各解析器使用到的 commitHistoryDataStore 是同一个
                final Analyzer analyzer = new Analyzer(
                        execFileLoader.getExecutionDataStore(), coverageBuilder, commit, newest, commitHistoryDataStore);
                analyzer.analyzeAll(new File(jobBuildModel.getWorkSpacePath().getDataWorkSpacePath() + commit + "/mergeclasses"));
                execFileLoaders.add(execFileLoader);
                coverageBuilders.add(coverageBuilder);
            } catch (Exception e) {
                logger.error("服务端 jacoco 解析数据的过程中出现异常", e);
                throw new RuntimeException(e);
            }
        }
        // #5生成报告的目录
        String currentCommitReportDir = jobBuildModel.getWorkSpacePath().getReportWorkSpacePath();
        // 最新一次 commit 的源码，注意：最新一次
        String currentCommitSrcDir = jobBuildModel.getWorkSpacePath().getCodeWorkSpacePath() + newCommitList.get(newCommitList.size() - 1) + "/" + jobBuildModel.getProjectInfo().getRepositoryName();

        // 获取到最新一次 commit 对应的 CoverageBuilder
        CoverageBuilder coverageBuilder = coverageBuilders.get(coverageBuilders.size() - 1);
        // 获取到最新一次 commit 对应的 ExecFileLoader
        ExecFileLoader execFileLoader = execFileLoaders.get(execFileLoaders.size() - 1);
        try {
            createReport(coverageBuilder.getBundle(""), currentCommitReportDir, currentCommitSrcDir, execFileLoader);
        } catch (Exception e) {
            logger.error("服务端 jacoco 生成报告的过程中出现异常", e);
            throw new RuntimeException(e);
        }
        ServerJobBuildResultModel serverJobJavaBuildResultModel = new ServerJobBuildResultModel();
        serverJobJavaBuildResultModel.setCoverageResult(coverageBuilder.getBundle(""));
        serverJobJavaBuildResultModel.setS3Env(jobBuildModel.getTestConfig().getTestEnv());
        serverJobJavaBuildResultModel.setCommit(getPlusCommitid(jobBuildModel.getTestConfig().getReleaseId(), jobBuildModel.getTestConfig().getTestEnv()));
        buildSuccess(jobBuildModel, serverJobJavaBuildResultModel);
    }

    /**
     * 对根据exec获取的commitList进行排序
     * 排序顺序为倒序
     *
     * @param commitList    根据exec获取的commitList
     * @param jobBuildModel 服务端构建逻辑中会用到的参数
     * @return 排序后的commitList
     */
    public List<String> sortCommitList(JobBuildModel<ServerTestConfigModel> jobBuildModel, List<String> commitList) throws GitAPIException {
        List<String> newCommitList = new ArrayList<String>();
        //clone该分支源码
        ShellUtils.dumpcode(jobBuildModel.getProjectInfo().getGitAddress(), jobBuildModel.getWorkSpacePath().getCodeWorkSpacePath() + jobBuildModel.getProjectInfo().getRepositoryName(), jobBuildModel.getBaseConfig().getCurrentBranch(), jobBuildModel.getBaseConfig().getOriginBranch());
        List<String> allCommitList = getBranchCommits(jobBuildModel.getWorkSpacePath().getCodeWorkSpacePath() + jobBuildModel.getProjectInfo().getRepositoryName() + "/.git", jobBuildModel.getBaseConfig().getCurrentBranch());
        TreeMap<Integer, String> pairs = new TreeMap<>();
        for (String commit : commitList) {
            if (allCommitList.contains(commit)) {
                int index = allCommitList.indexOf(commit);
                pairs.put(index, commit);
            }
        }
        for (int index : pairs.keySet()) {
            newCommitList.add(pairs.get(index));
        }
        Collections.reverse(newCommitList);
        return newCommitList;
    }

    /**
     * 获取oldCommit
     * @param jobBuildModel 服务端构建逻辑中会用到的参数
     * @return oldCommit
     */
    public String getOldCommit(JobBuildModel<ServerTestConfigModel> jobBuildModel) throws GitAPIException {
        //check old commit
        String oldCommit="";
        List<String> allOldBranchCommitList = getBranchCommits(jobBuildModel.getWorkSpacePath().getCodeWorkSpacePath() + jobBuildModel.getProjectInfo().getRepositoryName() + "/.git", "origin/"+jobBuildModel.getBaseConfig().getOriginBranch());
        List<String> allNewBranchCommitList = getBranchCommits(jobBuildModel.getWorkSpacePath().getCodeWorkSpacePath() + jobBuildModel.getProjectInfo().getRepositoryName() + "/.git", "origin/"+jobBuildModel.getBaseConfig().getCurrentBranch());
        for(int i=0;i<allNewBranchCommitList.size();i++){
            if(oldCommit.length()!=0){
                break;
            }
            for (String s : allOldBranchCommitList) {
                if (allNewBranchCommitList.get(i).equals(s)) {
                    oldCommit = allNewBranchCommitList.get(i);
                    break;
                }
            }
        }
        return oldCommit;
    }


    /**
     * 全量填充 md5
     *
     * @param commit                   commit
     * @param srcPath                  源码路径
     * @param commitMethodMD5DataStore commitMethodMD5DataStore
     */
    void fillMD5(String commit, String srcPath, CommitMethodMD5DataStore commitMethodMD5DataStore) {
        // # 解析类java文件，获取方法信息
        ASTAnalyzer astAnalyzer = new ASTAnalyzer(commit, commitMethodMD5DataStore);
        try {
            astAnalyzer.analyzeAll(new File(srcPath));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * 增量填充 md5
     *
     * @param commit                   commit
     * @param srcPath                  源码路径
     * @param commitMethodMD5DataStore commitMethodMD5DataStore
     * @param diffClassInfos
     */
    public void fillMD5(String commit, String srcPath, CommitMethodMD5DataStore commitMethodMD5DataStore, List<ClassInfo> diffClassInfos) {
        // # 解析类java文件，获取方法信息
        ASTAnalyzer astAnalyzer = new ASTAnalyzer(commit, commitMethodMD5DataStore, diffClassInfos);
        try {
            astAnalyzer.analyzeAll(new File(srcPath));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private ExecFileLoader loadExecutionData(File exec) throws IOException {
        ExecFileLoader execFileLoader = new ExecFileLoader();
        ArrayList<File> craneDataFile = screenExec(exec.getAbsolutePath());
        //合并exec文件
        for (File curFile : craneDataFile) {
            execFileLoader.load(curFile);
        }
        return execFileLoader;
    }

    /**
     * download exec文件后筛选 exec 文件
     *
     * @param path 服务端exec文件存储路径
     * @return 经筛选过后的 exec 文件list
     */
    public ArrayList<File> screenExec(String path) {
        ArrayList<File> craneDataFile = new ArrayList<File>();
        //查文件下的exec文件
        File dir = new File(path);
        File[] subFiles = dir.listFiles();
        if (null != subFiles) {
            for (File subFile : subFiles) {
                if (subFile.isDirectory())        //文件夹则递归寻找
                    screenExec(subFile.getAbsolutePath());
                else if (subFile.isFile() && subFile.getName().endsWith(".exec"))
                    craneDataFile.add(subFile);
            }
        }
        return craneDataFile;
    }

    /**
     * 生成报告
     *
     * @param bundleCoverage execFileLoader reportDirectory sourceDirectory
     */
    void createReport(IBundleCoverage bundleCoverage, String reportDirectory, String sourceDirectory, ExecFileLoader execFileLoader) throws Exception {
        final HTMLFormatter htmlFormatter = new HTMLFormatter();
        final IReportVisitor visitor = htmlFormatter
                .createVisitor(new FileMultiReportOutput(new File(reportDirectory)));

        visitor.visitInfo(execFileLoader.getSessionInfoStore().getInfos(),
                execFileLoader.getExecutionDataStore().getContents());


        visitor.visitBundle(bundleCoverage,
                new DirectorySourceFileLocator(new File(sourceDirectory), "utf-8", 4));


        visitor.visitEnd();
    }

    /**
     * 获取iplist字符串
     *
     * @param ipAndPortMap – ip和port的map
     * @return string
     */
    public String mapToString(Map<String, String> ipAndPortMap) {
        StringBuilder iplistString = new StringBuilder();
        List<String> iplist = new ArrayList<String>();
        for (String address : ipAndPortMap.keySet()) {
            iplist.add(address);
        }
        for (int i = 0; i < iplist.size(); i++) {
            if (i > 0) {
                iplistString.append(",");
            }
            iplistString.append(iplist.get(i));
        }
        return iplistString.toString();
    }

    /**
     * 获取最近发布成功的commitId
     *
     * @param releaseId 服务发布项id
     *                  env 测试环境
     * @return commitId
     */
    public String getPlusCommitid(int releaseId, String env) {
        String commitId = "";

        String plusurl = "http://plus.sankuai.com/release/" + releaseId + "/joblist";
        String response = HttpUtils.get(plusurl);
        JSONArray jsonArray = JSONArray.parseArray(response);
        for (int i = 0; i < jsonArray.size(); i++) {
            JSONObject jsonObject = jsonArray.getJSONObject(i);
            if ((jsonObject.get("Status").toString().equals("Success")) && (jsonObject.get("Env").toString().equals(env)) && (jsonObject.get("Commit")!="")) {
                commitId = jsonObject.get("Commit").toString().substring(0, 11);
                break;
            }
        }
        return commitId;
    }

    /**
     * check plus部署分支与所填分支是否一致
     *
     * @param jobBuildModel 服务发布项id
     *                      env 测试环境
     * @return boolean
     */
    public Boolean checkPlusBranch(JobBuildModel<ServerTestConfigModel> jobBuildModel) {
        Integer releaseId = jobBuildModel.getTestConfig().getReleaseId();
        String env = jobBuildModel.getTestConfig().getTestEnv();
        String branch = jobBuildModel.getBaseConfig().getCurrentBranch();
        String plusurl = "http://plus.sankuai.com/release/" + releaseId + "/joblist";
        String response = HttpUtils.get(plusurl);
        String plusBranch = "";
        JSONArray jsonArray = JSONArray.parseArray(response);
        for (int i = 0; i < jsonArray.size(); i++) {
            JSONObject jsonObject = jsonArray.getJSONObject(i);
            if ((jsonObject.get("Status").toString().equals("Success")) && (jsonObject.get("Env").toString().equals(env))) {
                plusBranch = jsonObject.get("Label").toString();
                break;
            }
        }
        if (plusBranch.equals(branch)) {
            return true;
        } else return false;
    }

    /**
     * check plus部署分支与所填分支是否一致
     *
     * @param releaseId 服务发布项id
     *                  env 测试环境
     * @return boolean
     */
    public Boolean checkPlusIdIsRight(int releaseId, String gitAddress) {
        try {
            // TODO 低优：如果该接口被封禁，怎么办？
            String plusurl = "http://plus.sankuai.com/release/" + releaseId;
            String response = HttpUtils.get(plusurl);
            JSONObject jsonObject = JSONObject.parseObject(response);
            return jsonObject.get("Repository").toString().equals(gitAddress);
        } catch (HttpClientErrorException e) {
            if (e.getMessage().contains("400 Bad Request")) {
                throw new UserInputException("可能是不存在的发布项id，请检查是否填错");
            }
            // 未知错误，直接抛出，前端会出现500
            throw new RuntimeException(e);
        } catch (Exception e) {
            // 未知错误，直接抛出，前端会出现500
            throw new RuntimeException(e);
        }
    }

    /**
     * 从服务器dump exec文件
     *
     * @param jobBuildModel – 服务端构建逻辑中会用到的参数
     */
    public void dump(JobBuildModel<ServerTestConfigModel> jobBuildModel) throws IOException {
        DumpClosingConfig dumpClosingConfig;
        try {
            dumpClosingConfig = mtConfigService.getConfig(MTConfigKeyEnum.dumpClosingConfig.getKey(), DumpClosingConfig.class);
        } catch (Exception e) {
            logger.error("get dumpClosingConfig Error", e);
            dumpClosingConfig = null;
        }
        if((dumpClosingConfig!= null)&&(checkDumpUpload(dumpClosingConfig.getStartDumpClosingTime(), dumpClosingConfig.getCloseDumpClosingTime()))){
            return;
        }
        // 项目名称/部署分支/commit-机器ip-上传时间.exec
        Map<String, String> ipAndPortMap = jobBuildModel.getTestConfig().getIpAndPortMap();
        List<String> iplist = new ArrayList<String>();
        List<String> portlist = new ArrayList<String>();
        for (String address : ipAndPortMap.keySet()) {
            iplist.add(address);
            portlist.add(ipAndPortMap.get(address));
        }
        String projectName = ShellUtils.getRepositoryName(jobBuildModel.getProjectInfo().getGitAddress());
        String commitid = getPlusCommitid(jobBuildModel.getTestConfig().getReleaseId(), jobBuildModel.getTestConfig().getTestEnv());
        //从多个被测服务器获取数据
        for (int i = 0; i < iplist.size(); i++) {
            String addr = iplist.get(i);
            int port = Integer.parseInt(portlist.get(i));
            FileOutputStream localFile = null;
            File foder = new File(jobBuildModel.getWorkSpacePath().getDataWorkSpacePath());
            if (!foder.exists()) {
                boolean wasSuccessful = foder.mkdirs();
                if (!wasSuccessful) {
                    System.out.println("mkdir exec file was not successful.");
                }
            }
            ;
            // Open a socket to the coverage agent:
            Socket socket = null;
            try {
                //创建文件输出流以写入具有指定名称的文件
                //项目名称/部署分支/commit-机器ip-上传时间.exec
                long currentTime = System.currentTimeMillis();
                String filename = jobBuildModel.getWorkSpacePath().getDataWorkSpacePath() + commitid + "-" + addr + "-" + currentTime + ".exec";
                localFile = new FileOutputStream(filename);
                //将执行数据序列化为二进制流
                final ExecutionDataWriter localWriter = new ExecutionDataWriter(
                        localFile);
                // Open a socket to the coverage agent:
                socket = new Socket(InetAddress.getByName(addr), port);
                final RemoteControlWriter writer = new RemoteControlWriter(
                        socket.getOutputStream());
                final RemoteControlReader reader = new RemoteControlReader(
                        socket.getInputStream());
                //二进制流的执行数据反序列化
                reader.setSessionInfoVisitor(localWriter);
                reader.setExecutionDataVisitor(localWriter);

                writer.visitDumpCommand(true, false);
                if (!reader.read()) {
                    throw new IOException("Socket closed unexpectedly.");
                }
                socket.close();
                localFile.close();
                //上传exec文件到s3
                File execFile = new File(filename);
                if (!checkPlusBranch(jobBuildModel)) {
                    throw new UserInputException("dump失败，请检查服务器部署分支与创建job所填分支是否一致");
                }
                if (execFile.exists()) {
                    s3Biz.uploadExecFileWithEnvV2(execFile.getAbsolutePath(), projectName, jobBuildModel.getBaseConfig().getCurrentBranch(), commitid, jobBuildModel.getTestConfig().getTestEnv());
                }
                //check是否拉取mergeclasses
                if (!checkMergeclassExist(jobBuildModel)) {
                    String iplistnew = mapToString(jobBuildModel.getTestConfig().getIpAndPortMap());
                    ShellUtils.dumpmergeclass(iplistnew, jobBuildModel.getWorkSpacePath().getDataWorkSpacePath() + "mergeclasses");
                    FileOutputStream fos1 = new FileOutputStream(new File(jobBuildModel.getWorkSpacePath().getDataWorkSpacePath() + commitid + "-mergeclasses.zip"));
                    ZipUtils.toZip(jobBuildModel.getWorkSpacePath().getDataWorkSpacePath() + "mergeclasses", fos1, true);
                    s3Biz.uploadMergeclassFileWithEnv(jobBuildModel.getWorkSpacePath().getDataWorkSpacePath() + commitid + "-mergeclasses.zip", projectName, jobBuildModel.getBaseConfig().getCurrentBranch(), commitid, jobBuildModel.getTestConfig().getTestEnv());
                    ShellUtils.rmDir(jobBuildModel.getWorkSpacePath().getDataWorkSpacePath() + "mergeclasses");

                }
            } catch (Exception e) {
                logger.error("[Server]: dump 时出现问题", e);
                if (e instanceof UserInputException) {
                    throw new UserInputException(e.getMessage());
                }
                if (e instanceof DeveloperConfigException) {
                    throw new DeveloperConfigException(e.getMessage());
                }
                if (e.getMessage().contains("Connection refused")) {
                    throw new UserInputException("请检查项目信任关系是否建立，是否正确使用代码覆盖率模版或ip及端口号填写正确");
                }
                if (e.getMessage().contains("Connection timed out")) {
                    throw new UserInputException("端口已被占用，请检查ip及端口号是否填写正确");
                }
                throw new RuntimeException(e);
            }
        }
    }

    /**
     * check当前commitid是否存在
     *
     * @param jobBuildModel 服务端构建逻辑中会用到的参数
     * @return mergeclasses是否存在
     */
    private Boolean checkMergeclassExist(JobBuildModel<ServerTestConfigModel> jobBuildModel) {
        List<String> objectList = Lists.newArrayList();
        String commit = getPlusCommitid(jobBuildModel.getTestConfig().getReleaseId(), jobBuildModel.getTestConfig().getTestEnv());
        String projectName = jobBuildModel.getProjectInfo().getRepositoryName();
        String branch = jobBuildModel.getBaseConfig().getCurrentBranch();
        String todayStr = DateUtils.getTodayStr();
        String filePrefix = s3Util.coverageTypeMapping(CoverageTypeEnum.SERVER.getType()) + "coverage_data/" + jobBuildModel.getTestConfig().getTestEnv() + "/" + projectName + "/" + branch + "/" + todayStr + "/" + commit + "/" + "mergeclass/";
        objectList = s3UtilBiz.getObjectListV2(filePrefix);
        if (objectList.size() == 0) {
            return false;
        } else return true;
    }

    /**
     * 下载 exec 文件到本地
     *
     * @param jobBuildModel 服务端构建逻辑中会用到的参数
     */
    private void downloadFile(JobBuildModel<ServerTestConfigModel> jobBuildModel, Set<String> commitSet) {
        // 项目名称/部署分支/commit-机器ip-上传时间.exec
        JobBaseConfigModel jobBaseConfigModel = jobBuildModel.getBaseConfig();
        ProjectInfoModel projectInfoModel = jobBuildModel.getProjectInfo();
        ServerTestConfigModel serverTestConfigModel = jobBuildModel.getTestConfig();
        WorkSpacePathModel workSpacePathModel = jobBuildModel.getWorkSpacePath();
        // 构建搜索对象
        SearchServerFileModel searchServerFileModel = new SearchServerFileModel.Builder()
                .addBranch(jobBaseConfigModel.getCurrentBranch())
                .addRepositoryName(projectInfoModel.getRepositoryName())
                .addIp(serverTestConfigModel.getIpAndPortMap().keySet())
                .addTestEnv(serverTestConfigModel.getTestEnv())
                // 目前采用了全拉下来再筛选的方式
                .addTestStartTime(serverTestConfigModel.getTestStartTime())
                .addTestEndTime(serverTestConfigModel.getTestEndTime())
                .build();
        List<String> targetExecFileObjectUrlList = screenFile(searchServerFileModel, commitSet);
        // 批量下载 exec 文件到本地
        s3Biz.batchDownloadFileWithEnvAndCommit(targetExecFileObjectUrlList, workSpacePathModel.getDataWorkSpacePath(), serverTestConfigModel.getTestEnv());
    }

    /**
     * 下载mergeclass文件到本地
     *
     * @param jobBuildModel 服务端构建逻辑中会用到的参数
     */
    private void downloadMergeclass(JobBuildModel<ServerTestConfigModel> jobBuildModel, List<String> commitList) {
        // 项目名称/部署分支/commit-机器ip-上传时间.exec
        JobBaseConfigModel jobBaseConfigModel = jobBuildModel.getBaseConfig();
        ProjectInfoModel projectInfoModel = jobBuildModel.getProjectInfo();
        ServerTestConfigModel serverTestConfigModel = jobBuildModel.getTestConfig();
        WorkSpacePathModel workSpacePathModel = jobBuildModel.getWorkSpacePath();
        // 构建搜索对象
        SearchServerFileModel searchServerFileModel = new SearchServerFileModel.Builder()
                .addBranch(jobBaseConfigModel.getCurrentBranch())
                .addRepositoryName(projectInfoModel.getRepositoryName())
                .addIp(serverTestConfigModel.getIpAndPortMap().keySet())
                .addTestEnv(serverTestConfigModel.getTestEnv())
                // 目前采用了全拉下来再筛选的方式
                .addTestStartTime(serverTestConfigModel.getTestStartTime())
                .addTestEndTime(serverTestConfigModel.getTestEndTime())
                .build();
        List<String> targetMergeClassObjectUrlList = screenMergeclass(searchServerFileModel, commitList);
        // 批量下载 exec 文件到本次
        s3Biz.batchDownloadFileWithEnvAndCommit(targetMergeClassObjectUrlList, workSpacePathModel.getDataWorkSpacePath(), serverTestConfigModel.getTestEnv());
    }

    private List<String> screenFileWithTime(SearchServerFileModel searchServerFileModel, Set<String> commitSet) {
        LocalDateTime testStartTime = searchServerFileModel.getTestStartTime();
        LocalDateTime testEndTime = searchServerFileModel.getTestEndTime();

        // 返回结果
        List<String> retObjectNameList = new ArrayList<>();
        List<String> allDateObjectNameList = new ArrayList<>();

        List<String> dateRange = DateUtils.collectLocalDates(testStartTime, testEndTime);
        dateRange.forEach(date -> {
            // 增加时间筛选前缀，获取对应时间下的 exec 数据
            List<String> objectNameList = s3Biz.searchObjectListWithEnvV2(CoverageTypeEnum.SERVER.getType(),
                    searchServerFileModel.getRepositoryName() + "/" + searchServerFileModel.getBranch() + "/" + date
                    , searchServerFileModel.getTestEnv());

            allDateObjectNameList.addAll(objectNameList);
        });

        List<ExecFileNameModel> execFileNameModels = new ArrayList<>();
        for (String objectUrl : allDateObjectNameList) {
            if (objectUrl.endsWith("zip")) {
                continue;
            }
            ExecFileNameModel execFileNameModel = ExecFileNameModel.format(objectUrl);
            execFileNameModels.add(execFileNameModel);
        }

        Set<String> ipSet = new HashSet<>();
        boolean isMatchIp = false;
        boolean isMatchTestTime = false;

        long testStartTimeStamp = 0;
        long testEndTimeStamp = 0;

        // ipSet 必须有才行
        if (searchServerFileModel.getIpSet() != null) {
            ipSet = searchServerFileModel.getIpSet();
            // 需要进行 ip 匹配
            isMatchIp = true;
        }

        if (searchServerFileModel.getTestStartTime() != null && searchServerFileModel.getTestEndTime() != null) {
            // 需要进行时间戳匹配
            isMatchTestTime = true;
            testStartTimeStamp = searchServerFileModel.getTestStartTime().toInstant(ZoneOffset.of("+8")).toEpochMilli();
            testEndTimeStamp = searchServerFileModel.getTestEndTime().toInstant(ZoneOffset.of("+8")).toEpochMilli();
        }

        for (ExecFileNameModel execFileNameModel : execFileNameModels) {
            boolean isContainsIp = false;
            boolean isBetweenStartTimeAndEndTime = true;

            // 将时间戳转化为long
            long uploadTime = Long.parseLong(execFileNameModel.getUploadTime());

            if (isMatchIp) {
                isContainsIp = ipSet.contains(execFileNameModel.getIp());
            }

            // 如果需要测试时间
            if (isMatchTestTime) {
                isBetweenStartTimeAndEndTime = uploadTime >= testStartTimeStamp && testEndTimeStamp >= uploadTime;
            }

            if (isBetweenStartTimeAndEndTime && isContainsIp) {
                retObjectNameList.add(execFileNameModel.getObjectName());
            }
        }
        if (retObjectNameList.size() == 0) {
            throw new UserInputException("未在s3上筛选到对应分支或时间的的exec文件，请查看时间或分支是否填写正确");
        }

        for (int i = 0; i < retObjectNameList.size(); i++) {
            String objectUrl = retObjectNameList.get(i);
            ExecFileNameModel execFileNameModel = ExecFileNameModel.format(objectUrl);
            commitSet.add(execFileNameModel.getCommit());
        }
        return retObjectNameList;
    }

    /**
     * 筛选 exec 文件
     *
     * @param searchServerFileModel 服务端exec文件搜索对象
     * @return 经筛选过后的 exec 文件名
     */
    private List<String> screenFile(SearchServerFileModel searchServerFileModel, Set<String> commitSet) {
        if (searchServerFileModel.getTestStartTime() != null && searchServerFileModel.getTestEndTime() != null) {
            // 需要进行时间戳匹配
            return screenFileWithTime(searchServerFileModel, commitSet);
        }

        // 粗略查询，获取对应分支下的所有 objectUrl
        List<String> objectNameList = s3Biz.searchObjectListWithEnvV2(CoverageTypeEnum.SERVER.getType(), searchServerFileModel.getRepositoryName() + "/" + searchServerFileModel.getBranch()
                , searchServerFileModel.getTestEnv());
        // 筛选后的结果集合
        List<String> retObjectNameList = new ArrayList<>();
        // 将路径转化为对象，方便操作
        List<ExecFileNameModel> execFileNameModels = new ArrayList<>();
        for (String objectUrl : objectNameList) {
            if (objectUrl.endsWith("zip")) {
                continue;
            }
            ExecFileNameModel execFileNameModel = ExecFileNameModel.format(objectUrl);
            execFileNameModels.add(execFileNameModel);
        }

        Set<String> ipSet = new HashSet<>();
        boolean isMatchIp = false;

        // ipSet 必须有才行
        if (searchServerFileModel.getIpSet() != null) {
            ipSet = searchServerFileModel.getIpSet();
            // 需要进行 ip 匹配
            isMatchIp = true;
        }

        for (ExecFileNameModel execFileNameModel : execFileNameModels) {
            boolean isContainsIp = false;

            if (isMatchIp) {
                isContainsIp = ipSet.contains(execFileNameModel.getIp());
            }

            if (isContainsIp) {
                retObjectNameList.add(execFileNameModel.getObjectName());
            }
        }
        if (retObjectNameList.size() == 0) {
            throw new UserInputException("未在s3上筛选到对应分支或时间的的exec文件，请查看时间或分支是否填写正确");
        }
        logger.info("[ServerJob]: 经 ip 和 testTime 筛选过后, objectNameList: {}", retObjectNameList);
        for (int i = 0; i < retObjectNameList.size(); i++) {
            String objectUrl = retObjectNameList.get(i);
            ExecFileNameModel execFileNameModel = ExecFileNameModel.format(objectUrl);
            commitSet.add(execFileNameModel.getCommit());
        }
        return retObjectNameList;
    }

    private List<String> screenMergeClassWithTime(SearchServerFileModel searchServerFileModel, List<String> commitList) {
        LocalDateTime testStartTime = searchServerFileModel.getTestStartTime();
        LocalDateTime testEndTime = searchServerFileModel.getTestEndTime();
        List<String> dateRange = DateUtils.collectLocalDates(testStartTime, testEndTime);

        List<String> retObjectNameList = new ArrayList<>();
        // 时间复杂度 O(日期间隔*commit数量)，分日期存储后，导致这部分数据改动
        dateRange.forEach(date -> {
            commitList.forEach(commit -> {
                List<String> commitObjectNameList = s3Biz.searchObjectListWithEnvV2(CoverageTypeEnum.SERVER.getType(),
                        searchServerFileModel.getRepositoryName() + "/" + searchServerFileModel.getBranch() + "/" + date + "/" + commit + "/mergeclass"
                        , searchServerFileModel.getTestEnv());
                // 这里一般只有一个
                commitObjectNameList.forEach(commitObjectName -> {
                    if (commitObjectName.endsWith("zip")) {
                        retObjectNameList.add(commitObjectName);
                    }
                });
            });

        });
        if (retObjectNameList.size() == 0) {
            throw new DeveloperConfigException("有项目出现搜不到 mergeclass 的问题了：项目名称：" + searchServerFileModel.getRepositoryName());
        }
        logger.info("[ServerJob]: 经commit筛选过后, objectNameList: {}", retObjectNameList);
        return retObjectNameList;
    }

    /**
     * 筛选 exec 文件
     *
     * @param searchServerFileModel 服务端文件搜索对象
     * @return 经筛选过后的文件名
     */
    private List<String> screenMergeclass(SearchServerFileModel searchServerFileModel, List<String> commitList) {
        if(searchServerFileModel.getTestStartTime() != null && searchServerFileModel.getTestEndTime() != null) {
            return screenMergeClassWithTime(searchServerFileModel, commitList);
        }

        // 如果用户没有填写时间，则查询时就基于分支去查
        List<String> retObjectNameList = new ArrayList<>();
        commitList.forEach(commit -> {
            List<String> commitObjectNameList = s3Biz.searchObjectListWithEnvV2(CoverageTypeEnum.SERVER.getType(),
                    searchServerFileModel.getRepositoryName() + "/" + searchServerFileModel.getBranch()
                    , searchServerFileModel.getTestEnv());

            commitObjectNameList.forEach(commitObjectName -> {
                if (commitObjectName.endsWith("zip")) {
                    retObjectNameList.add(commitObjectName);
                }
            });
        });
        if (retObjectNameList.size() == 0) {
            throw new DeveloperConfigException("有项目出现搜不到 mergeclass 的问题了：项目名称：" + searchServerFileModel.getRepositoryName());
        }
        logger.info("[ServerJob]: 经commit筛选过后, objectNameList: {}", retObjectNameList);
        return retObjectNameList;
    }

    /**
     * 获取分支下的所有commit
     *
     * @param gitUrl branch
     * @return 经筛选过后的 exec 文件名
     */
    private List<String> getBranchCommits(String gitUrl, String branch) throws GitAPIException {
        // 获取分支下的所有commit
        List<String> commitList = new ArrayList<String>();
        try {
            Git git = Git.open(new File(gitUrl));
            org.eclipse.jgit.lib.Repository repository = git.getRepository();
            Iterable<RevCommit> logs = new Git(repository).log()
                    .add(repository.resolve(branch))
                    .call();
            for (RevCommit rev : logs) {
                commitList.add(rev.toString().split("\\s+")[1].substring(0, 11));
            }
            return commitList;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return commitList;
    }

    private boolean checkDumpUpload(int startDumpClosingTime, int closeDumpClosingTime) {
        //check dump的exec是否上传到s3上
        Calendar cal = Calendar.getInstance();
        int hours = cal.get( Calendar.HOUR_OF_DAY );
        if (closeDumpClosingTime<startDumpClosingTime){
            return (hours < closeDumpClosingTime) || (hours >= startDumpClosingTime);
        }
        else{
            return (hours < closeDumpClosingTime) && (hours >= startDumpClosingTime);
        }
    }
}
