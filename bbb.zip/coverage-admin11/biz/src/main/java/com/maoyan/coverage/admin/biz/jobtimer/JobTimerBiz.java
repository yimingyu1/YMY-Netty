package com.maoyan.coverage.admin.biz.jobtimer;

import com.maoyan.coverage.admin.domain.enums.TimerStatusEnum;
import com.maoyan.coverage.admin.domain.enums.TimerTypeEnum;
import com.maoyan.coverage.admin.domain.model.JobTimerModel;
import com.maoyan.coverage.admin.domain.vo.jobmanage.JobTimerVO;
import com.maoyan.coverage.admin.service.jobtimer.JobTimerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author lizhuoran05
 * @date 2021/7/20
 */
@Service
public class JobTimerBiz {

    @Autowired
    JobTimerService jobTimerService;

    public int insertJobTimer(JobTimerModel jobTimerModel) {
        return jobTimerService.insert(jobTimerModel);
    }

    public JobTimerModel selectByJobConfigId(int jobConfigId) {
        return jobTimerService.getJobTimerModelByJobConfigId(jobConfigId);
    }

    public JobTimerModel selectByJobConfigIdAndType(int jobConfigId, int type) {
        return jobTimerService.getJobTimerModelByJobConfigIdAndType(jobConfigId, type);
    }

    public JobTimerVO selectUnClosedByJobConfigIdAndType(int jobConfigId, int type) {
        JobTimerModel jobTimerModel = jobTimerService.getByJobConfigIdAndTypeAndClosed(jobConfigId, type, TimerStatusEnum.IN_PROCESSING.getType());
        if (jobTimerModel == null) {
            return null;
        }
        JobTimerVO jobTimerVO = new JobTimerVO();
        jobTimerVO.setJobId(jobTimerModel.getJobConfigId());
        jobTimerVO.setTimerType(jobTimerModel.getTimerType());
        jobTimerVO.setTimerValue(jobTimerModel.getTimerValue());

        return jobTimerVO;
    }

    public int updateJobTimerByJobConfigIdAndType(JobTimerModel jobTimerModel) {
        return jobTimerService.updateByJobConfigIdAndType(jobTimerModel);
    }

    public int updateClosedByJobConfigIdAndType(int jobConfigId, int type) {
        JobTimerModel jobTimerModel = jobTimerService.getJobTimerModelByJobConfigIdAndType(jobConfigId, type);
        jobTimerModel.setClosed(TimerStatusEnum.CLOSED.getType());
        return jobTimerService.updateByJobConfigIdAndType(jobTimerModel);
    }

    public List<JobTimerModel> getUnClosedJobTimers() {
        return jobTimerService.getJobTimerModelsByClosed(0);
    }
}
