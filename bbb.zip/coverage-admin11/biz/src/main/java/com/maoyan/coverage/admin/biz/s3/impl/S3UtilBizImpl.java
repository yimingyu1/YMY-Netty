package com.maoyan.coverage.admin.biz.s3.impl;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.S3ClientOptions;
import com.amazonaws.services.s3.model.*;
import com.google.common.collect.Lists;
import com.maoyan.coverage.admin.biz.s3.S3UtilBiz;
import com.maoyan.coverage.admin.common.PropUtil;
import com.maoyan.coverage.admin.domain.enums.S3EnvEnum;
import com.maoyan.coverage.admin.domain.enums.TestEnvEnum;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.util.List;


/**
 * S3 的基础方法
 * Created by lihongmei03 on 2020-12-01
 */
@Service
public class S3UtilBizImpl implements S3UtilBiz {
    public static final Logger LOGGER = LoggerFactory.getLogger(S3UtilBizImpl.class);

    private AmazonS3 s3Client;

    @Autowired
    AmazonS3 testS3Client;

    @Autowired
    AmazonS3 prodS3Client;

    @Autowired
    AmazonS3 envS3Client;


    // test S3使用的信息，当被测试应用部署在 test 时使用
    private String accessKey = PropUtil.getProperty("mss.accessKey");
    private String secretKey = PropUtil.getProperty("mss.secretKey");
    private String hostname = PropUtil.getProperty("mss.host");
    private String bucketName = PropUtil.getProperty("mss.bucket");

    // prod S3使用的信息，当被测试应用部署在 staging 时使用
    private String prodBucketName = PropUtil.getProperty("mss.prodBucket");

    private String envBucketName = PropUtil.getProperty("env.mss.bucket");

    public Boolean putObjectFileWithEnv(File uploadFile, String path, String env) {
        boolean uploadStatus = true;
        String localeBucket = env.equals(S3EnvEnum.PROD.getEnv()) ? prodBucketName : bucketName;

        try {
            ObjectMetadata metadata = new ObjectMetadata();
            String uploadFileType = handleS3FileType(uploadFile);
            metadata.setContentType(uploadFileType);
            metadata.setContentLength(uploadFile.length());
            FileInputStream inputStream = new FileInputStream(uploadFile);
            // uploadFile.getName() = ec文件的名称，如1619423271453.ec
            if (env.equals((S3EnvEnum.PROD.getEnv()))) {
                prodS3Client.putObject(localeBucket, path + uploadFile.getName(), inputStream, metadata);
            } else {
                testS3Client.putObject(localeBucket, path + uploadFile.getName(), inputStream, metadata);
            }
        } catch (Exception e) {
            LOGGER.error("文件上传失败: " + e.getMessage());
            uploadStatus = false;
        }

        return uploadStatus;
    }

    @Override
    public Boolean putReportFileV2(File uploadFile, String relativePath) {
        boolean uploadStatus = true;

        try {
            ObjectMetadata metadata = new ObjectMetadata();
            String uploadFileType = handleS3FileType(uploadFile);
            metadata.setContentType(uploadFileType);
            metadata.setContentLength(uploadFile.length());
            FileInputStream inputStream = new FileInputStream(uploadFile);
            // 前期拼接好相对路径
            envS3Client.putObject(envBucketName, relativePath, inputStream, metadata);
        } catch (Exception e) {
            LOGGER.error("文件上传失败: " + e.getMessage());
            uploadStatus = false;
        }

        return uploadStatus;
    }

    @Override
    public Boolean putObjectWithEnv(String content, String objectName, String env) {
        boolean uploadStatus = true;
        // 如果测试环境在st环境，就上传至线上的S3
        String localeBucket = env.equals(TestEnvEnum.STAGING.getEnv()) ? prodBucketName : bucketName;

        try {
            ObjectMetadata metadata = new ObjectMetadata();
            metadata.setContentLength(content.length());
            if (env.equals(TestEnvEnum.STAGING.getEnv())) {
                prodS3Client.putObject(localeBucket, objectName, new ByteArrayInputStream(content.getBytes()), metadata);
            } else {
                testS3Client.putObject(localeBucket, objectName, new ByteArrayInputStream(content.getBytes()), metadata);
            }
        } catch (Exception e) {
            LOGGER.error("文件上传失败: " + e.getMessage());
            uploadStatus = false;
        }
        return uploadStatus;
    }

    @Override
    public Boolean putObject(String content, String path) {
        boolean uploadStatus = true;
        try {
            ObjectMetadata metadata = new ObjectMetadata();
            metadata.setContentLength(content.length());
            envS3Client.putObject(envBucketName, path, new ByteArrayInputStream(content.getBytes()), metadata);
        } catch (Exception e) {
            LOGGER.error("文件上传失败: " + e.getMessage());
            uploadStatus = false;
        }
        return uploadStatus;
    }

    /**
     * 覆盖率服务prod和st环境，会使用线上的s3
     * 覆盖率服务test和dev环境，会使用线下的s3
     *
     * @param uploadFile 文件
     * @param path       路径
     * @return 是否上传成功
     */
    @Override
    public Boolean putObjectFileV2(File uploadFile, String path) {
        boolean uploadStatus = true;

        try {
            ObjectMetadata metadata = new ObjectMetadata();
            String uploadFileType = handleS3FileType(uploadFile);
            metadata.setContentType(uploadFileType);
            metadata.setContentLength(uploadFile.length());
            FileInputStream inputStream = new FileInputStream(uploadFile);
            envS3Client.putObject(envBucketName, path + uploadFile.getName(), inputStream, metadata);
        } catch (Exception e) {
            LOGGER.error("文件上传失败: " + e.getMessage());
            uploadStatus = false;
        }

        return uploadStatus;
    }


    @Override
    public List<String> getObjectListWithTestEnv(String filePrefix, String env) {
        List<String> objectList = Lists.newArrayList();

        String localeBucket = env.equals(TestEnvEnum.STAGING.getEnv()) ? prodBucketName : bucketName;

        try {
            ListObjectsRequest listObjectsRequest = new ListObjectsRequest()
                    .withBucketName(localeBucket)
                    //查询bucket下固定的前缀
                    .withPrefix(filePrefix);
            ObjectListing objectListing = null;
            if (env.equals(TestEnvEnum.STAGING.getEnv())) {
                objectListing = prodS3Client.listObjects(listObjectsRequest);
            } else {
                objectListing = testS3Client.listObjects(listObjectsRequest);
            }
            for (S3ObjectSummary objectSummary : objectListing.getObjectSummaries()) {
                objectList.add(objectSummary.getKey());
            }
        } catch (Exception e) {
            LOGGER.error("获取文件列表失败: " + e.getMessage());
        }
        return objectList;
    }

    @Override
    public List<String> getObjectListV2(String filePrefix) {
        List<String> objectList = Lists.newArrayList();
        try {
            ListObjectsRequest listObjectsRequest = new ListObjectsRequest()
                    .withBucketName(envBucketName)
                    //查询bucket下固定的前缀
                    .withPrefix(filePrefix)
                    //每页10w条数据，这是极限数据
                    .withMaxKeys(100000);
            ObjectListing objectListing = null;
            objectListing = envS3Client.listObjects(listObjectsRequest);
            for (S3ObjectSummary objectSummary : objectListing.getObjectSummaries()) {
                objectList.add(objectSummary.getKey());
            }
        } catch (Exception e) {
            LOGGER.error("获取文件列表失败: " + e.getMessage());
        }
        return objectList;
    }

    @Override
    public void downloadObjectWithEnv(String objectName, String localFilePath, String env) {
        String localeBucket = env.equals(TestEnvEnum.STAGING.getEnv()) ? prodBucketName : bucketName;
        ObjectMetadata res = null;
        if (env.equals(TestEnvEnum.STAGING.getEnv())) {
            prodS3Client.getObject(new GetObjectRequest(localeBucket, objectName), new File(localFilePath));
        } else {
            testS3Client.getObject(new GetObjectRequest(localeBucket, objectName), new File(localFilePath));
        }
    }

    @Override
    public void downloadObjectV2(String objectName, String localFilePath) {
        envS3Client.getObject(new GetObjectRequest(envBucketName, objectName), new File(localFilePath));
    }


    //设置常见文件上传至 S3 的格式
    private static String handleS3FileType(File uploadFile) {
        String S3FileType;
        String uploadFileType = uploadFile.getName().substring(uploadFile.getName().lastIndexOf(".") + 1);
        if (uploadFileType.contains("css") || uploadFileType.contains("html")) {
            S3FileType = "text/" + uploadFileType;
        } else if (uploadFileType.contains("js")) {
            S3FileType = "application/javascript";
        } else if (uploadFileType.contains("png") || uploadFileType.contains("jepg")) {
            S3FileType = "image/" + uploadFileType;
        } else if (uploadFileType.contains("json")) {
            S3FileType = "application/json";
        } else {
            S3FileType = "application/octet-stream";
        }
        return S3FileType;
    }
}
