package com.maoyan.coverage.admin.biz.projectmanage;

import com.alibaba.fastjson.JSONObject;
import com.maoyan.coverage.admin.common.utils.ApiResponseCoverage;
import com.maoyan.coverage.admin.domain.constant.ErrorMessageConstant;
import com.maoyan.coverage.admin.domain.enums.ProjectTypeEnum;
import com.maoyan.coverage.admin.domain.model.Paging;
import com.maoyan.coverage.admin.domain.model.job.ProjectInfoModel;
import com.maoyan.coverage.admin.domain.model.jobmanage.JobManageModel;
import com.maoyan.coverage.admin.domain.model.projectmanage.ProjectManageModel;
import com.maoyan.coverage.admin.domain.param.projectmanage.ProjectParam;
import com.maoyan.coverage.admin.domain.vo.projectmanage.CProjectManageVO;
import com.maoyan.coverage.admin.domain.vo.projectmanage.ProjectManageVO;
import com.maoyan.coverage.admin.service.jobmanage.IJobManageService;
import com.maoyan.coverage.admin.service.projectmanage.IProjectManageService;
import com.meituan.mobile.movie.common.response.ApiResponse;
import com.sankuai.meituan.auth.util.UserUtils;
import com.sankuai.meituan.auth.vo.User;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @author yimingyu
 * @date 2021/07/22
 */
@Service
@Slf4j
public class ProjectOptManageBiz {

    @Resource
    private IProjectManageService projectManageService;

    @Resource
    private IJobManageService jobManageService;

    /**
     * 添加项目
     *
     * @param projectParam
     * @return
     */
    public ApiResponse<Object> addProject(ProjectParam projectParam) {
        User user = UserUtils.getUser();
        if (user == null) {
            return ApiResponse.buildFailure(ErrorMessageConstant.USER_NOT_LOGIN);
        }
        ProjectManageModel sameProjectManageModel = projectManageService.getSameProjectManageModel(projectParam.getBusinessLineId(), projectParam.getProjectName(),
                projectParam.getGitAddress(), JSONObject.toJSONString(projectParam.getProjectLeader()),
                projectParam.getProjectType());
        if (sameProjectManageModel != null){
            return ApiResponse.buildFailure("当前业务线下已存在相同的项目名、项目类型、git地址、项目负责人的项目, 请调整后重试！");
        }
        ProjectManageModel projectManageModel = new ProjectManageModel();
        projectManageModel.setBusinessLineId(projectParam.getBusinessLineId());
        projectManageModel.setProjectName(projectParam.getProjectName());
        projectManageModel.setProjectLeader(projectParam.getProjectLeader());
        projectManageModel.setProjectType(projectParam.getProjectType());
        projectManageModel.setCreator(user.getLogin());
        projectManageModel.setUpdater(user.getLogin());
        projectManageModel.setGitAddress(projectParam.getGitAddress());
        projectManageModel.setDeleted(0);
        LocalDateTime localDateTime = LocalDateTime.now();
        projectManageModel.setCreateTime(localDateTime);
        projectManageModel.setUpdateTime(localDateTime);
        int rest = projectManageService.insertProjectManage(projectManageModel);
        if (rest > 0) {
            return ApiResponse.buildSuccess();
        }
        return ApiResponse.buildFailure("内部错误，添加项目失败");
    }

    /**
     * 查询项目列表
     *
     * @param businessLineId
     * @param offset
     * @param limit
     * @param projectType
     * @return
     */
    public ApiResponse<Object> getProjectList(int businessLineId, int offset, int limit, int projectType) {
        /**
         * 1.判断该业务线下是否有项目，如果没有返回空
         * 2.判断项目类型
         */
        List<ProjectManageModel> allProjectManages = projectManageService.getAllProjectManages(businessLineId);
        List<ProjectManageVO> projectManageVOList = new ArrayList<>();
        int allProjectManageTotal = allProjectManages.size();
        Paging paging = new Paging();
        paging.setLimit(limit);
        paging.setOffset(offset);
        if (allProjectManageTotal == 0) {
            return ApiResponseCoverage.buildSuccess(projectManageVOList, paging);
        }
        List<ProjectManageModel> projectManageModelList = null;
        if (projectType < ProjectTypeEnum.PC.getId() || projectType > ProjectTypeEnum.MRN.getId()) {
            if (offset >= allProjectManageTotal){
                return ApiResponse.buildFailure(ErrorMessageConstant.PAGE_ERROR_NO_DATA);
            }
            projectManageModelList = projectManageService.getProjectManageList(businessLineId, offset, limit);
        } else {
            List<ProjectManageModel> allProjectManagesWithType = projectManageService.getAllProjectManagesWithType(businessLineId, projectType);
            allProjectManageTotal = allProjectManagesWithType.size();
            if (allProjectManageTotal == 0) {
                return ApiResponseCoverage.buildSuccess(projectManageVOList, paging);
            }
            if (offset >= allProjectManageTotal){
                return ApiResponse.buildFailure(ErrorMessageConstant.PAGE_ERROR_NO_DATA);
            }
            projectManageModelList = projectManageService.getProjectManageListWithType(businessLineId, offset, limit, projectType);
        }
        for (ProjectManageModel pmm : projectManageModelList
        ) {
            ProjectManageVO projectManageVO = new ProjectManageVO();
            projectManageVO.setId(pmm.getId());
            projectManageVO.setProjectName(pmm.getProjectName());
            projectManageVO.setProjectType(pmm.getProjectType());
            projectManageVO.setGitAddress(pmm.getGitAddress());
            projectManageVO.setProjectCreator(pmm.getCreator());
            projectManageVO.setProjectLeader(pmm.getProjectLeader());
            projectManageVOList.add(projectManageVO);
        }
        paging.setTotal(allProjectManageTotal);
        paging.setHasMore(offset + limit < allProjectManageTotal);
        return ApiResponseCoverage.buildSuccess(projectManageVOList, paging);
    }

    /**
     * 获取指定id的project信息
     *
     * @param id
     * @return
     */
    public ApiResponse<Object> getProjectInfoById(int id) {
        ProjectManageModel projectManageModel = projectManageService.getProjectManageById(id);
        if (projectManageModel == null) {
            return ApiResponse.buildFailure("该项目不存在");
        }
        ProjectManageVO projectManageVO = new ProjectManageVO();
        projectManageVO.setId(projectManageModel.getId());
        projectManageVO.setProjectName(projectManageModel.getProjectName());
        projectManageVO.setProjectType(projectManageModel.getProjectType());
        projectManageVO.setGitAddress(projectManageModel.getGitAddress());
        projectManageVO.setProjectLeader(projectManageModel.getProjectLeader());
        return ApiResponse.buildSuccess(projectManageVO);
    }

    /**
     * 编辑项目
     *
     * @param projectParam
     * @return
     */
    public ApiResponse<Object> editProjectInfo(ProjectParam projectParam) {
        User user = UserUtils.getUser();
        if (user == null) {
            return ApiResponse.buildFailure(ErrorMessageConstant.USER_NOT_LOGIN);
        }
        ProjectManageModel projectManageById = projectManageService.getProjectManageById(projectParam.getId());
        if (projectManageById == null){
            return ApiResponse.buildFailure("该项目不存在，请确认后重试");
        }
        ProjectManageModel sameProjectManageModel = projectManageService.getSameProjectManageModel(projectManageById.getBusinessLineId(), projectParam.getProjectName(),
                projectParam.getGitAddress(), JSONObject.toJSONString(projectParam.getProjectLeader()),
                projectParam.getProjectType());
        if (sameProjectManageModel != null && sameProjectManageModel.getId() != projectParam.getId()) {
            return ApiResponse.buildFailure("当前业务线下已存在相同的项目名、项目类型、git地址、项目负责人的项目, 请调整后重试！");
        }
        ProjectManageModel pmm = new ProjectManageModel();
        pmm.setId(projectParam.getId());
        pmm.setBusinessLineId(projectManageById.getBusinessLineId());
        pmm.setProjectName(projectParam.getProjectName());
        pmm.setProjectLeader(projectParam.getProjectLeader());
        pmm.setProjectType(projectManageById.getProjectType());
        pmm.setUpdater(user.getLogin());
        pmm.setGitAddress(projectManageById.getGitAddress());
        pmm.setUpdateTime(LocalDateTime.now());
        int rest = projectManageService.updateProjectManage(pmm);
        if (rest > 0) {
            return ApiResponse.buildSuccess();
        }
        log.info("内部错误,更新项目失败");
        return ApiResponse.buildFailure("内部错误,更新项目失败");
    }

    public ProjectInfoModel getProjectInfoModelByProjectId(int id) {
        return projectManageService.getProjectInfoModelByProjectId(id);
    }

    /**
     * 删除project
     * 如果被删除的project下边有job, 则连同job一起删除
     * @param projectId
     * @return
     */
    public ApiResponse<Object> delProject(int projectId){
        User user = UserUtils.getUser();
        if (user == null) {
            return ApiResponse.buildFailure(ErrorMessageConstant.USER_NOT_LOGIN);
        }
        ProjectManageModel projectManageById = projectManageService.getProjectManageById(projectId);
        if (projectManageById == null){
            return ApiResponse.buildFailure("该项目不存在，请确认后重试");
        }
        if (!projectManageById.getCreator().equals(user.getLogin())){
            return ApiResponse.buildFailure("您不是该项目的创建者，无法删除");
        }
        // 原逻辑 删除project，会直接删除所有属于该project的job
        // 新逻辑 当project下存在job，则无法删除该project
        int delJobRes = 0;
        List<JobManageModel> jobManageModels = jobManageService.getJobManageListByProjectId(projectId);
        if (!CollectionUtils.isEmpty(jobManageModels)){
            return ApiResponse.buildFailure("当前项目下存在job，无法删除");
        }
        Map<String, Object> map = new HashMap<>();
//        if (!CollectionUtils.isEmpty(jobManageModels)){
//            List<Integer> collect = jobManageModels.stream().map(JobManageModel::getId).collect(Collectors.toList());
//            map.put("projectIds", collect);
//            map.put("updater", user.getLogin());
//            map.put("updateTime", LocalDateTime.now());
//            delJobRes = jobManageService.deleteJobBranch(map);
//        }
//        log.info("deljobs by projectId , delInfo = {}", map);
//        if (delJobRes < 0){
//            return ApiResponse.buildFailure("删除该project关联的job失败，请联系管理员");
//        }
//        map.remove("projectIds");
        map.put("updater", user.getLogin());
        map.put("projectId", projectId);
        map.put("updateTime", LocalDateTime.now());
        int delProjectRes = projectManageService.deleteProjectManage(map);
        if (delProjectRes > 0){
            return ApiResponse.buildSuccess();
        }
        return ApiResponse.buildFailure("删除project失败，请联系管理员");
    }

    /**
     * 获取所有的项目id和项目名
     * @param businessLineId
     * @return
     */
    public ApiResponse<Object> getAllProject2ChaoYue(int businessLineId){
        List<ProjectManageModel> allProjectManages = projectManageService.getAllProjectManages(businessLineId);
        List<CProjectManageVO> projectManageVOS = new ArrayList<>();
        if (!CollectionUtils.isEmpty(allProjectManages)) {
            for (ProjectManageModel projectManage : allProjectManages
            ) {
                CProjectManageVO cProjectManageVO = new CProjectManageVO();
                cProjectManageVO.setId(projectManage.getId());
                cProjectManageVO.setProjectName(projectManage.getProjectName());
                projectManageVOS.add(cProjectManageVO);
            }
        }
        return ApiResponse.buildSuccess(projectManageVOS);
    }
}

