package com.maoyan.coverage.admin.biz.job.schedule;

import com.maoyan.coverage.admin.biz.job.InterfaceJobBiz;
import com.maoyan.coverage.admin.common.exception.JenkinsException;
import com.maoyan.coverage.admin.common.utils.DateUtils;
import com.maoyan.coverage.admin.common.utils.JenkinsUtils;
import com.maoyan.coverage.admin.common.utils.ShellUtils;
import com.maoyan.coverage.admin.domain.constant.DateFormatStr;
import com.maoyan.coverage.admin.domain.model.job.JobBuildModel;
import com.maoyan.coverage.admin.domain.model.job.config.ServerTestConfigModel;
import com.maoyan.coverage.jacocoplus.core.analysis.Analyzer;
import com.maoyan.coverage.jacocoplus.core.analysis.CoverageBuilder;
import com.maoyan.coverage.jacocoplus.core.tools.ExecFileLoader;
import com.offbytwo.jenkins.model.Build;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.quartz.*;
import org.springframework.beans.factory.annotation.Autowired;
import java.io.File;
import java.time.LocalDateTime;
import java.time.ZoneOffset;

/**
 * @author yimingyu
 * @date 2021/11/11
 */
@Slf4j
public class InterfaceJob implements InterruptableJob {

    @Autowired
    private InterfaceJobBiz interfaceJobBiz;

    @Override
    public void interrupt() throws UnableToInterruptJobException {

    }


    @SneakyThrows
    @Override
    public void execute(JobExecutionContext jobExecutionContext){
        String jobName = String.valueOf(jobExecutionContext.getJobDetail().getKey().getName());
        String jenkinsRef = jobExecutionContext.getJobDetail().getJobDataMap().getString("jenkinsRef");
        int jenkinsBuildId = jobExecutionContext.getJobDetail().getJobDataMap().getInt("jenkinsBuildId");
        JobBuildModel<ServerTestConfigModel> jobBuildModel = (JobBuildModel<ServerTestConfigModel>)jobExecutionContext.getJobDetail().getJobDataMap().get("jobBuildModel");
        TriggerKey triggerKey = jobExecutionContext.getTrigger().getKey();
        JobKey jobKey = jobExecutionContext.getJobDetail().getKey();
        int buildNum = jobBuildModel.getBuildNum();
        int jobId = jobBuildModel.getJobConfigId();
        Build buildById = null;
        log.info("now is {}, jobId = {}, buildNum = {}, 开启轮询jenkinsJob: {} 的构建结果", DateUtils.format2Str(LocalDateTime.now(), DateFormatStr.DATE_FORMAT_VO), jobId, buildNum, jobName);
        try {
            buildById = JenkinsUtils.getBuildById(jenkinsRef, jenkinsBuildId);
            if (buildById != null && buildById.details().getResult() != null){
                log.info("now is {}, jobId = {}, buildNum = {}, 已经查询到job: {} 的构建结果 --- {}", DateUtils.format2Str(LocalDateTime.now(), DateFormatStr.DATE_FORMAT_VO),
                        jobId, buildNum, jobName, buildById.details().getResult());
                log.info("关闭 {} jenkinsJob轮询", jobName);
                interfaceJobBiz.stopAndCleanJob(triggerKey, jobKey);
                // dump 接口测试后的exec文件到本地 WorkSpacePathModel.dataWorkSpacePath/commit + jobName/xxx.exec,并上传到S3
                String commitId =jobExecutionContext.getJobDetail().getJobDataMap().getString("commitId");
                String extraFileName = (jobName.split("_")[0]).replaceAll("-+", "_");
                log.info(jobName + " 开始dump exec文件");
                String execPath = interfaceJobBiz.dumpOption(jobBuildModel, commitId + jobName ,extraFileName + "-", false);
                log.info(jobName + " dump exec文件完成");
                // 拉取 class 文件到本地  WorkSpacePathModel.dataWorkSpacePath/commit + jobName/mergeclasses
                log.info(jobName + " 开始拉取classes文件");
                String classPath = interfaceJobBiz.loadNewestClasses(jobBuildModel, commitId + jobName);
                log.info(jobName + " 拉取classes文件完成");
                // 拉取源码文件到本地 jobBuildModel.getWorkSpacePath().getCodeWorkSpacePath()/commit + jobName/
                log.info(jobName + " 开始获取source文件");
                String sourcePath = jobBuildModel.getWorkSpacePath().getCodeWorkSpacePath() + commitId + jobName + "/" +
                        jobBuildModel.getProjectInfo().getRepositoryName();
                ShellUtils.cloneCodeByCommit(jobBuildModel.getProjectInfo().getGitAddress(), sourcePath,
                        jobBuildModel.getBaseConfig().getCurrentBranch(), commitId);
                log.info(jobName + " 获取source文件完成");
                // 加载exec文件数据到execFileLoader中
                ExecFileLoader execFileLoader = new ExecFileLoader();
                interfaceJobBiz.loadExec(execFileLoader, execPath);
                // 创建CoverageBuilder 存储解析后的覆盖率数据
                CoverageBuilder coverageBuilder = new CoverageBuilder();
                Analyzer analyzer = new Analyzer(execFileLoader.getExecutionDataStore(), coverageBuilder);
                analyzer.analyzeAll(new File(classPath));
                String reportPath = jobBuildModel.getWorkSpacePath().getReportWorkSpacePath();
                // 生成覆盖率报告
                interfaceJobBiz.createCoverageReport(coverageBuilder.getBundle(""), execFileLoader, sourcePath, reportPath);
                /**
                 * 1.上传报告到s3
                 * 2.相关数据落库
                 * 3.删除workspace文件夹
                 * 4.终止job轮询
                 */
                interfaceJobBiz.successEndOpt(coverageBuilder.getBundle(""), jobBuildModel, commitId + jobName);
                log.info("now is {}, 完成jenkinsJob: {} 构建", DateUtils.format2Str(LocalDateTime.now(), DateFormatStr.DATE_FORMAT_VO), jobName);
            }
        }catch (JenkinsException e){
            log.error("jenkins获取构建信息异常：{}", e.getMessage());
            interfaceJobBiz.failEndOpt(jobBuildModel, e, jobName);
        }catch (Exception e){
            log.error("轮询jenkins job出现异常, err = {}", e.getMessage());
            interfaceJobBiz.failEndOpt(jobBuildModel, e, jobName);
        }finally {
            long nowTimeStamp = LocalDateTime.now().toInstant(ZoneOffset.of("+8")).toEpochMilli();
            long thresholdTimeStamp = jobExecutionContext.getJobDetail().getJobDataMap().getLong("thresholdTimeStamp");
            if (nowTimeStamp > thresholdTimeStamp){
                // 终止轮询并大象异常通知
                log.error("now is {}, 超时未获取到jenkins build,关闭轮询job: {}并发送大象通知为开发者和构建用户", DateUtils.format2Str(LocalDateTime.now(), DateFormatStr.DATE_FORMAT_VO), jobName);
                interfaceJobBiz.failEndOpt(jobBuildModel, new JenkinsException("超时未获取到jenkins build,关闭轮询job："  + jobName), jobName);
                interfaceJobBiz.stopAndCleanJob(triggerKey, jobKey);
            }
        }

    }
}
