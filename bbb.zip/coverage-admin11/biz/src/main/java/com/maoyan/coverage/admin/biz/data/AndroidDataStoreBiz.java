package com.maoyan.coverage.admin.biz.data;

import com.maoyan.coverage.admin.domain.enums.JavaCoverageIndexEnum;
import com.maoyan.coverage.admin.domain.enums.ReportTypeEnum;
import com.maoyan.coverage.admin.domain.model.buildhistory.BuildHistoryDetailModel;
import com.maoyan.coverage.admin.domain.model.data.BelowThresholdFileModel;
import com.maoyan.coverage.admin.domain.model.data.DataIndicatorsCounter;
import com.maoyan.coverage.admin.domain.model.data.DataIndicatorsModel;
import com.maoyan.coverage.admin.service.builddetail.IBuildHistoryDetailService;
import org.jacoco.core.analysis.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * 数据处理业务
 * 目前安卓端和服务端分别用两个类处理数据
 *
 * @author lizhuoran05
 * @date 2021/7/26
 */
@Service
public class AndroidDataStoreBiz {

    @Autowired
    IBuildHistoryDetailService buildHistoryDetailService;


    /**
     * 安卓端调用
     *
     * @param reportTypeEnum  增量报告还是全量报告
     * @param iBundleCoverage 解析后的数据结构
     * @param buildHistoryId  构建历史Id
     * @param reportUrl       报告上传后的首页链接
     * @param threshold       阈值
     */
    public void store(ReportTypeEnum reportTypeEnum, IBundleCoverage iBundleCoverage, Integer buildHistoryId, String reportUrl, Double threshold) {
        List<DataIndicatorsModel> dataIndicatorsModelList = new ArrayList<>();
        DataIndicatorsModel line = null;
        DataIndicatorsModel branch = null;
        DataIndicatorsModel method = null;
        DataIndicatorsModel classInfo = null;
        DataIndicatorsModel cxty = null;

        // 增量和全量模式下，指标的定义不同
        if (reportTypeEnum.equals(ReportTypeEnum.INCREMENT_REPORT)) {
            line = buildDataIndicatorsModel(iBundleCoverage, JavaCoverageIndexEnum.INCREMENT_LINE, threshold, reportUrl);
            branch = buildDataIndicatorsModel(iBundleCoverage, JavaCoverageIndexEnum.INCREMENT_BRANCH, threshold, reportUrl);
            method = buildDataIndicatorsModel(iBundleCoverage, JavaCoverageIndexEnum.INCREMENT_METHOD, threshold, reportUrl);
            classInfo = buildDataIndicatorsModel(iBundleCoverage, JavaCoverageIndexEnum.INCREMENT_CLASS, threshold, reportUrl);
//            cxty = buildDataIndicatorsModel(iBundleCoverage, JavaCoverageIndexEnum.INCREMENT_CXTY, threshold, reportUrl);
        } else if (reportTypeEnum.equals(ReportTypeEnum.FULL_REPORT)) {
            line = buildDataIndicatorsModel(iBundleCoverage, JavaCoverageIndexEnum.LINE, threshold, reportUrl);
            branch = buildDataIndicatorsModel(iBundleCoverage, JavaCoverageIndexEnum.BRANCH, threshold, reportUrl);
            method = buildDataIndicatorsModel(iBundleCoverage, JavaCoverageIndexEnum.METHOD, threshold, reportUrl);
            classInfo = buildDataIndicatorsModel(iBundleCoverage, JavaCoverageIndexEnum.CLASS, threshold, reportUrl);
//            cxty = buildDataIndicatorsModel(iBundleCoverage, JavaCoverageIndexEnum.CXTY, threshold, reportUrl);
        }

        dataIndicatorsModelList.add(line);
        dataIndicatorsModelList.add(branch);
        dataIndicatorsModelList.add(method);
        dataIndicatorsModelList.add(classInfo);
//        dataIndicatorsModelList.add(cxty);

        // 插入数据库
        store(dataIndicatorsModelList, buildHistoryId, reportUrl + "index.html");
    }

    private DataIndicatorsModel buildDataIndicatorsModel(IBundleCoverage iBundleCoverage, JavaCoverageIndexEnum javaCoverageIndexEnum, Double threshold, String reportUrl) {
        DataIndicatorsModel dataIndicatorsModel = new DataIndicatorsModel();
        dataIndicatorsModel.setName(javaCoverageIndexEnum.getDes());
        dataIndicatorsModel.setKey(javaCoverageIndexEnum.getType());

        // 获取项目级别的Counter
        ICounter iCounter = getICounterByCoverageIndexEnum(javaCoverageIndexEnum, iBundleCoverage);
        dataIndicatorsModel.setCovered(iCounter.getCoveredCount());
        dataIndicatorsModel.setTotal(iCounter.getTotalCount());

        // 获取低于阈值的文件列表
        if (javaCoverageIndexEnum.equals(JavaCoverageIndexEnum.INCREMENT_CLASS) || javaCoverageIndexEnum.equals(JavaCoverageIndexEnum.CLASS)) {
            dataIndicatorsModel.setBelowThresholdFiles(null);
        } else {
            dataIndicatorsModel.setBelowThresholdFiles(getBelowThresholdFileModels(javaCoverageIndexEnum, iBundleCoverage, threshold, reportUrl));
        }
        return dataIndicatorsModel;
    }

    /**
     * Server 端和 Android 端
     * 获取低于阈值的文件
     *
     * @return 低于阈值的文件列表
     */
    private ArrayList<BelowThresholdFileModel> getBelowThresholdFileModels(JavaCoverageIndexEnum javaCoverageIndexEnum, IBundleCoverage iBundleCoverage, Double threshold, String reportUrl) {
        ArrayList<BelowThresholdFileModel> belowThresholdFileModels = new ArrayList<>();
        // 分支，类级别；方法，类级别；圈复杂度，类级别的；行，类级别的；
        // 获取包级别的信息
        Collection<IPackageCoverage> packageCoverages = iBundleCoverage.getPackages();

        // 遍历包级别的信息
        packageCoverages.forEach(aPackageCoverage -> {
            // 获取某个包下面的类覆盖率信息
            Collection<IClassCoverage> classCoverages = aPackageCoverage.getClasses();

            // 遍历某个包下面的所有类，去筛低于阈值的
            classCoverages.forEach(aClassCoverage -> {
                ICounter iCounter = getICounterByCoverageIndexEnum(javaCoverageIndexEnum, aClassCoverage);
                // 理论上不会为空
                double ratio = iCounter.getCoveredRatio();
                // 安卓端没有增加必定是项目中文件的判断，如果出现需要加上
                if (ratio < threshold && !aClassCoverage.getName().contains("$")) {
                    BelowThresholdFileModel belowThresholdFileModel = new BelowThresholdFileModel();
                    belowThresholdFileModel.setUrl(reportUrl + aClassCoverage.getPackageName().replace("/", ".") + "/" + aClassCoverage.getSourceFileName() + ".html");
                    belowThresholdFileModel.setCovered(iCounter.getCoveredCount());
                    belowThresholdFileModel.setTotal(iCounter.getCoveredCount() + iCounter.getMissedCount());
                    belowThresholdFileModel.setName(aClassCoverage.getSourceFileName());

                    belowThresholdFileModels.add(belowThresholdFileModel);
                }
            });
        });

        return belowThresholdFileModels;
    }

    /**
     * 根据指标类型获取对应的 counter
     *
     * @param javaCoverageIndexEnum 指标类型
     * @param coverageNode          数据源
     * @return 数据源中的某一个 counter
     */
    private ICounter getICounterByCoverageIndexEnum(JavaCoverageIndexEnum javaCoverageIndexEnum, ICoverageNode coverageNode) {
        switch (javaCoverageIndexEnum) {
            case BRANCH:
            case INCREMENT_BRANCH:
                return coverageNode.getBranchCounter();
            case LINE:
            case INCREMENT_LINE:
                return coverageNode.getLineCounter();
            case METHOD:
            case INCREMENT_METHOD:
                return coverageNode.getMethodCounter();
            case CLASS:
            case INCREMENT_CLASS:
                return coverageNode.getClassCounter();
            case CXTY:
            case INCREMENT_CXTY:
                return coverageNode.getComplexityCounter();
            default:
                return null;
        }
    }


    /**
     * 插入数据
     *
     * @param buildHistoryDetailModel
     * @return
     */
    private int insertBuildDetailModel(BuildHistoryDetailModel buildHistoryDetailModel) {
        return buildHistoryDetailService.insert(buildHistoryDetailModel);
    }

    /**
     * 原子存储方法
     *
     * @param dataIndicatorsModels
     * @param buildHistoryId
     * @param reportUrl
     */
    public void store(List<DataIndicatorsModel> dataIndicatorsModels, Integer buildHistoryId, String reportUrl) {
        BuildHistoryDetailModel buildHistoryDetailModel = new BuildHistoryDetailModel();

        buildHistoryDetailModel.setBuildId(buildHistoryId);
        buildHistoryDetailModel.setReportDetailUrl(reportUrl);
        buildHistoryDetailModel.setDataIndicatorsModels(dataIndicatorsModels);

        insertBuildDetailModel(buildHistoryDetailModel);
    }

    public DataIndicatorsCounter buildDataIndicatorsCounter(ICounter counter) {
        DataIndicatorsCounter dataIndicatorsCounter = new DataIndicatorsCounter();
        dataIndicatorsCounter.setTotal(counter.getTotalCount());
        dataIndicatorsCounter.setCovered(counter.getCoveredCount());
        return dataIndicatorsCounter;
    }

    public DataIndicatorsCounter buildDataIndicatorsCounter(int covered, int total) {
        DataIndicatorsCounter dataIndicatorsCounter = new DataIndicatorsCounter();
        dataIndicatorsCounter.setTotal(total);
        dataIndicatorsCounter.setCovered(covered);
        return dataIndicatorsCounter;
    }
}
