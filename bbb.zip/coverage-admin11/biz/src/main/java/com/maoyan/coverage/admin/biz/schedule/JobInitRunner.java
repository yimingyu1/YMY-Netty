package com.maoyan.coverage.admin.biz.schedule;

import com.maoyan.coverage.admin.biz.jobtimer.JobTimerBiz;
import com.maoyan.coverage.admin.common.utils.XMPubUtil;
import com.maoyan.coverage.admin.domain.constant.PublisherConstant;
import com.maoyan.coverage.admin.domain.enums.JobTimerTypeEnum;
import com.maoyan.coverage.admin.domain.model.JobTimerModel;
import com.maoyan.coverage.admin.domain.model.job.msg.AppStartUpFailedMsgModel;
import org.quartz.SchedulerException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @author lizhuoran05
 * @date 2021/7/27
 */
@Component
public class JobInitRunner implements CommandLineRunner {
    private Logger logger = LoggerFactory.getLogger(JobInitRunner.class);

    @Autowired
    JobTimerBiz jobTimerBiz;

    @Autowired
    JobManager jobManager;

    @Override
    public void run(String... strings) throws Exception {
        initJob();
    }


    /**
     * 根据 job_timer 中的配置将 Job 初始化交给调度器
     */
    public void initJob() {
        try {
            // 理论上，这个查询上出错可能
            List<JobTimerModel> jobTimerModelList = jobTimerBiz.getUnClosedJobTimers();

            List<JobTimerModel> serverJobDumpList = new ArrayList<>();
            List<JobTimerModel> jobList = new ArrayList<>();

            jobTimerModelList.forEach(jobTimerModel -> {
                try {
                    jobManager.schedule(jobTimerModel);
                } catch (Exception e) {
                    logger.error("项目启动失败", e);
                    // job 启动失败
                    AppStartUpFailedMsgModel appStartUpFailedMsgModel = new AppStartUpFailedMsgModel();
                    appStartUpFailedMsgModel.setError(e.getClass() + ":" + e.getMessage() + "\n" + Arrays.toString(e.getStackTrace()));
                    appStartUpFailedMsgModel.setProjectLeader(Arrays.asList(PublisherConstant.SERVER_DEVELOPER));
                    appStartUpFailedMsgModel.setRemark("Job 导致的失败, 请尽快处理");
                    appStartUpFailedMsgModel.setJobId(jobTimerModel.getJobConfigId());
                    appStartUpFailedMsgModel.setJobTimerType(jobTimerModel.getType());
                    XMPubUtil.sendToDeveloper(appStartUpFailedMsgModel.getMsg());
                }
                if (JobTimerTypeEnum.JOB_BUILD_TIMER.getType() == jobTimerModel.getType()) {
                    jobList.add(jobTimerModel);
                } else if (JobTimerTypeEnum.SERVER_JOB_DUMP_TIMER.getType() == jobTimerModel.getType()) {
                    serverJobDumpList.add(jobTimerModel);
                }
            });

            logger.info("Job: 初始化成功, 初始化未关闭定时构建的 Job, 共 {} 个", jobList.size());
            logger.info("Job: 初始化成功, 初始化 Server Job Dump 任务, 共 {} 个", serverJobDumpList.size());
        } catch (Exception e) {
            // 未知异常
            logger.error("项目启动失败", e);

            AppStartUpFailedMsgModel appStartUpFailedMsgModel = new AppStartUpFailedMsgModel();
            appStartUpFailedMsgModel.setError(e.getClass() + ":" + e.getMessage() + "\n" + Arrays.toString(e.getStackTrace()));
            appStartUpFailedMsgModel.setProjectLeader(Arrays.asList(PublisherConstant.SERVER_DEVELOPER));
            appStartUpFailedMsgModel.setRemark("未知异常, 请尽快处理");
            XMPubUtil.sendToDeveloper(appStartUpFailedMsgModel.getMsg());
        }
    }

}
