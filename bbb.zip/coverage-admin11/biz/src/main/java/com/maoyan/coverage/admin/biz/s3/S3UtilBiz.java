package com.maoyan.coverage.admin.biz.s3;

import java.io.File;
import java.util.List;

/**
 * Created by lihongmei03 on 2020-12-01
 */
public interface S3UtilBiz {
    /**
     * 上传到[指定环境]：安卓端 & iOS端调用，
     * @param uploadFile 要上传的文件
     * @param path       S3上的path
     * @param env        S3的环境
     * @return 是否上传成功
     */
    Boolean putObjectFileWithEnv(File uploadFile, String path, String env);

    /**
     * 上传报告时调用，上传到[部署环境]
     * @param uploadFile 要上传的文件
     * @param relativePath 报告文件的相对路径
     * @return 是否上传成功
     */
    Boolean putReportFileV2(File uploadFile, String relativePath);

    /**
     * 上传到[指定环境]：前端项目调用
     * @param content    文件内容
     * @param objectName 文件名字
     * @param env        测试环境
     * @return 是否上传成功
     */
    Boolean putObjectWithEnv(String content, String objectName, String env);

    /**
     * 上传到[部署环境]：前端项目调用
     * @param content    文件内容
     * @param objectName 文件名字
     * @return 是否上传成功
     */
    Boolean putObject(String content, String objectName);

    /**
     * 上传到[部署环境]：服务端调用
     * @param uploadFile 要上传的文件
     * @param path 报告路径
     * @return 是否上传成功
     */
    Boolean putObjectFileV2(File uploadFile, String path);

    /**
     * 前端使用
     * @param filePrefix 文件前缀
     * @param testEnv    测试环境
     * @return 文件名称集合
     */
    List<String> getObjectListWithTestEnv(String filePrefix, String testEnv);

    /**
     * 根据前缀搜索文件名称集合，从[部署环境]查询：服务端调用
     * @param filePrefix 文件前缀
     * @return 文件名称集合
     */
    List<String> getObjectListV2(String filePrefix);

    /**
     * 根据文件名称，从[指定环境]下载数据：安卓端 & iOS端调用
     * @param objectName    文件名字
     * @param localFilePath 文件本地路径(下载到哪里)
     * @param env           测试环境
     */
    void downloadObjectWithEnv(String objectName, String localFilePath, String env);

    /**
     * 根据文件名称，从[部署环境]下载数据：服务端调用
     * @param objectName 文件名字
     * @param localFilePath 本地路径
     */
    void downloadObjectV2(String objectName, String localFilePath);
}
