package com.maoyan.coverage.admin.biz.schedule;

import com.alibaba.fastjson.JSONObject;
import com.maoyan.coverage.admin.biz.jobmanage.JobOptManageBiz;
import com.maoyan.coverage.admin.biz.jobtimer.JobTimerBiz;
import com.maoyan.coverage.admin.biz.projectmanage.ProjectOptManageBiz;
import com.maoyan.coverage.admin.common.utils.ShellUtils;
import com.maoyan.coverage.admin.common.utils.XMPubUtil;
import com.maoyan.coverage.admin.domain.constant.TimerConstant;
import com.maoyan.coverage.admin.domain.enums.*;
import com.maoyan.coverage.admin.domain.model.JobTimerModel;
import com.maoyan.coverage.admin.domain.model.TimerConfigModel;
import com.maoyan.coverage.admin.domain.model.job.IdentityModel;
import com.maoyan.coverage.admin.domain.model.job.ProjectInfoModel;
import com.maoyan.coverage.admin.domain.model.job.msg.CycleBuildCloseMsgModel;
import com.maoyan.coverage.admin.domain.model.job.msg.CycleBuildOpenMsgModel;
import com.maoyan.coverage.admin.domain.model.job.msg.CycleBuildUpdateMsgModel;
import com.maoyan.coverage.admin.domain.model.jobmanage.JobManageModel;
import com.maoyan.coverage.admin.domain.param.job.BuildParam;
import com.maoyan.coverage.admin.domain.param.job.CycleBuildParam;
import com.maoyan.coverage.admin.biz.schedule.impl.*;
import com.maoyan.coverage.admin.domain.param.job.CycleServerDumpParam;
import com.maoyan.coverage.admin.service.jobmanage.IJobManageService;
import com.sankuai.meituan.auth.util.UserUtils;
import com.sankuai.meituan.auth.vo.User;
import org.quartz.*;
import org.quartz.impl.matchers.GroupMatcher;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;

import static org.quartz.JobBuilder.newJob;
import static org.quartz.TriggerBuilder.newTrigger;

/**
 * 立即构建和定时构建都交给quartz去调度
 *
 * @author lizhuoran05
 * @date 2021/7/9
 */
@Service
public class JobManager {

    private final Logger logger = LoggerFactory.getLogger(JobManager.class);

    private final String SERVER_JOB_DUMP_INTERVAL = "5";

    @Qualifier("scheduler")
    @Autowired
    Scheduler schedule;

    @Autowired
    JobTimerBiz jobTimerBiz;

    @Autowired
    JobOptManageBiz jobOptManage;

    @Autowired
    ProjectOptManageBiz projectOptManageBiz;

    @Resource
    IJobManageService jobManageService;

    /**
     * 立即构建
     */
    public JobStartUpEnum immediateBuild(BuildParam buildParam) {
        JobTimerModel jobTimerModel = new JobTimerModel();
        jobTimerModel.setTimerType(TimerTypeEnum.IMMEDIATE.getType());
        jobTimerModel.setClosed(TimerStatusEnum.IN_PROCESSING.getType());
        // 立即构建没有 timerValue
        jobTimerModel.setTimerValue("null");
        jobTimerModel.setJobConfigId(buildParam.getJobId());
        jobTimerModel.setType(JobTimerTypeEnum.JOB_BUILD_TIMER.getType());

        try {
            schedule(jobTimerModel);
            return JobStartUpEnum.SUCCESS;
        } catch (Exception e) {
            logger.error("[Job]: 启动失败, 请求参数是 {}", buildParam.toString());
            sendErrorMsg(e.toString(), buildParam.toString());
            e.printStackTrace();
            return JobStartUpEnum.FAIL;
        }
    }

    /**
     * 定时构建
     */
    public JobStartUpEnum cycleBuild(CycleBuildParam cycleBuildParam) {
        int jobConfigId = cycleBuildParam.getJobId();
        TimerConfigModel timerConfigModel = cycleBuildParam.getTimerConfig();

        // 获取定时配置
        int timerType = timerConfigModel.getTimerType();
        String timerValue = timerConfigModel.getTimerValue();

        JobTimerModel jobTimerModel = new JobTimerModel();
        jobTimerModel.setJobConfigId(jobConfigId);
        jobTimerModel.setTimerType(timerType);
        jobTimerModel.setTimerValue(timerValue);
        jobTimerModel.setClosed(TimerStatusEnum.IN_PROCESSING.getType());
        jobTimerModel.setType(JobTimerTypeEnum.JOB_BUILD_TIMER.getType());

        // 当服务端Job开启定时构建后，在数据库中会有两条数据，所以这里只查 type = 1 的
        JobTimerModel jobTimerModelInDataBase = jobTimerBiz.selectByJobConfigIdAndType(jobConfigId, JobTimerTypeEnum.JOB_BUILD_TIMER.getType());
        if (jobTimerModelInDataBase != null && jobTimerModelInDataBase.getClosed() == TimerStatusEnum.IN_PROCESSING.getType()) {
            // 存在定时配置，且处于运行中
            if (jobTimerModelInDataBase.getType() == jobTimerModel.getType() &&
                    jobTimerModelInDataBase.getTimerType() == jobTimerModel.getTimerType() &&
                    jobTimerModelInDataBase.getTimerValue().equals(jobTimerModel.getTimerValue())) {
                logger.warn("Job: 当前配置的 Job 已在调度器中，无需重复开启");
                // 相同，直接返回
                return JobStartUpEnum.UPDATE_FAIL;
            } else {
                // 更新数据库
                jobTimerBiz.updateJobTimerByJobConfigIdAndType(jobTimerModel);
                // TODO 低优：(二期可考虑，只是影响机器存储空间)当一个 Job 在执行途中被关闭时，应该将相关的文件等删除
                try {
                    updateScheduleJob(jobTimerModel, jobTimerModelInDataBase);
                    sendUpdateCycleMsgToUser(jobConfigId, jobTimerModel, jobTimerModelInDataBase);
                    return JobStartUpEnum.UPDATE_SUCCESS;
                } catch (Exception e) {
                    logger.error("[Job]: 定时Job更新配置失败, 请求参数是 {}", cycleBuildParam.toString());
                    sendErrorMsg(e.toString(), cycleBuildParam.toString(), "定时Job更新配置失败");
                    return JobStartUpEnum.FAIL;
                }
            }
        } else {
            // 数据库中无定时配置 || 数据库中有配置，但是被关闭了
            if (jobTimerModelInDataBase == null) {
                logger.info("创建 JobTimer: {}", jobTimerModel.toString());
                // 数据库中无定时配置
                jobTimerBiz.insertJobTimer(jobTimerModel);
            } else if (jobTimerModelInDataBase.getClosed() == TimerStatusEnum.CLOSED.getType()) {
                // 数据库中有配置，但是被关闭了
                jobTimerBiz.updateJobTimerByJobConfigIdAndType(jobTimerModel);
            }
        }

        try {
            schedule(jobTimerModel);

            // 开启定时构建发送消息
            sendOpenCycleMsgToUser(jobConfigId, jobTimerModel);
            return JobStartUpEnum.SUCCESS;
        } catch (Exception e) {
            sendErrorMsg(e.toString(), cycleBuildParam.toString());
            e.printStackTrace();
            return JobStartUpEnum.FAIL;
        }
    }

    /**
     * 更新调度器中的Job
     */
    public void updateScheduleJob(JobTimerModel jobTimerModel, JobTimerModel originJobTimerModel) throws SchedulerException {
        IdentityModel identityModel = buildIdentity(originJobTimerModel);

        // 先移除
        TriggerKey triggerKey = new TriggerKey(identityModel.getName(), identityModel.getGroup());
        JobKey jobKey = new JobKey(identityModel.getName(), identityModel.getGroup());
        logger.info("Job: 更新定时配置信息, 移除调度器中的 Job, TriggerKey: {}, JobKey: {}", triggerKey.getName(), jobKey.getName());

        schedule.pauseTrigger(triggerKey);
        schedule.unscheduleJob(triggerKey);
        schedule.deleteJob(jobKey);

        // 调度
        schedule(jobTimerModel);
    }

    /**
     * @param jobTimerModel 构建逻辑所需的对象
     */
    public void schedule(JobTimerModel jobTimerModel) throws SchedulerException {
        IdentityModel identityModel = buildIdentity(jobTimerModel);
        SimpleTrigger trigger = buildTrigger(jobTimerModel, identityModel);
        JobDetail jobDetail = buildJobDetail(jobTimerModel, identityModel);

        logger.info("Job: 提交 [{}] 任务", TimerTypeEnum.typeMap.get(jobTimerModel.getTimerType()).getDes());
        // 开启一个 job
        schedule(jobDetail, trigger);
    }

    /**
     * 最小粒度的调度逻辑
     * 在这里处理异常
     */
    public void schedule(JobDetail jobDetail, Trigger trigger) throws SchedulerException {
        logger.info("Job: 开始调度, TriggerKey: {}, JobKey: {}", trigger.getKey().getName(), jobDetail.getKey().getName());
        // 开启一个 job
        schedule.scheduleJob(jobDetail, trigger);

        if (schedule.isShutdown()) {
            schedule.start();
        }
    }


    /**
     * 创建标示
     */
    private IdentityModel buildIdentity(JobTimerModel jobTimerModel) {
        IdentityModel identityModel = new IdentityModel();
        JSONObject identityName = new JSONObject();

        int jobId = jobTimerModel.getJobConfigId();

        JobManageModel jobManageModel = jobOptManage.getJobManageModelByJobConfigId(jobId);

        identityName.put("jobName", jobManageModel.getJobName());
        identityName.put("jobConfigId", jobTimerModel.getJobConfigId());
        identityName.put("jobTimerType", jobTimerModel.getTimerType());
        identityName.put("jobTimerValue", jobTimerModel.getTimerValue());
        identityName.put("type", jobTimerModel.getType());
        identityModel.setName(identityName.toJSONString());

        identityModel.setGroup(ProjectTypeEnum.typeMap.get(jobManageModel.getJobType()).toString());
        return identityModel;
    }

    private SimpleTrigger buildTrigger(JobTimerModel jobTimerModel, IdentityModel identityModel) {
        if (jobTimerModel.getTimerType() == TimerTypeEnum.INTERVAL.getType()) {
            return newTrigger()
                    .withIdentity(identityModel.getName(), identityModel.getGroup())
                    .withSchedule(SimpleScheduleBuilder.simpleSchedule()
                            .withIntervalInSeconds(Integer.parseInt(jobTimerModel.getTimerValue()) * 60)
                            .repeatForever())
                    .build();
        } else if (jobTimerModel.getTimerType() == TimerTypeEnum.CRON.getType()) {
            logger.error("暂未支持 cron 表达式");
            return null;
        } else if (jobTimerModel.getTimerType() == TimerTypeEnum.IMMEDIATE.getType()) {
            // 立即执行
            return newTrigger()
                    .withIdentity(identityModel.getName(), identityModel.getGroup())
                    .startNow()
                    .withSchedule(SimpleScheduleBuilder.simpleSchedule()
                            .withRepeatCount(TimerConstant.REPEAT_NUM_ZERO))
                    .build();
        }
        logger.error("未支持的类型");
        return null;
    }

    private JobDetail buildJobDetail(JobTimerModel jobTimerModel, IdentityModel identityModel) {
        JobManageModel jobConfig = jobManageService.getJobConfigById(jobTimerModel.getJobConfigId());
        int projectType = jobConfig.getJobType();
        int jobTestType = jobConfig.getJobTestType();
        ProjectTypeEnum projectTypeEnum = ProjectTypeEnum.typeMap.get(projectType);
        Class<? extends CoverageJob> jobClass = null;
        if (jobTimerModel.getType() == JobTimerTypeEnum.JOB_BUILD_TIMER.getType()) {
            jobClass = getJobByProjectType(projectTypeEnum);
        } else if (jobTimerModel.getType() == JobTimerTypeEnum.SERVER_JOB_DUMP_TIMER.getType()) {
            jobClass = CoverageServerDumpJob.class;
        }

        JobDetail jobDetail = newJob(jobClass)
                .withIdentity(identityModel.getName(), identityModel.getGroup())
                .usingJobData("jobConfigId", jobTimerModel.getJobConfigId())
                .usingJobData("projectType", projectType)
                .usingJobData("timerType", jobTimerModel.getTimerType())
                .usingJobData("timerValue", jobTimerModel.getTimerValue())
                .usingJobData("type", jobTimerModel.getType())
                .usingJobData("jobTestType", jobTestType)
                .usingJobData("builder", UserUtils.getUser() == null ? "SYSTEM" : UserUtils.getUser().getLogin())
                .build();
        return jobDetail;
    }

    /**
     * Job 创建时调用
     *
     * @return
     */
    public JobStartUpEnum cycleDump(CycleServerDumpParam cycleServerDumpParam) {
        int jobConfigId = cycleServerDumpParam.getJobId();
        String timerValue = cycleServerDumpParam.getTimerValue();
        try {

            // 提交 Server Cycle Dump 时，需要持久化到一个 jobTimer
            JobTimerModel jobTimerModel = new JobTimerModel();
            jobTimerModel.setJobConfigId(jobConfigId);
            // dump 固定是周期构建
            jobTimerModel.setTimerType(TimerTypeEnum.INTERVAL.getType());
            // 默认使用 5 分钟
            jobTimerModel.setTimerValue(timerValue);
            jobTimerModel.setClosed(TimerStatusEnum.IN_PROCESSING.getType());
            jobTimerModel.setType(JobTimerTypeEnum.SERVER_JOB_DUMP_TIMER.getType());
            // 判断有没有
            JobTimerModel jobTimerModelInDataBase = jobTimerBiz.selectByJobConfigIdAndType(jobConfigId, JobTimerTypeEnum.SERVER_JOB_DUMP_TIMER.getType());
            if (jobTimerModelInDataBase == null) {
                // 创建项目时都会执行这个逻辑
                jobTimerBiz.insertJobTimer(jobTimerModel);
            } else {
                // 如果有的话，可能存在三种情况，1：已经关闭了，2：开启,时间相同，3：开启,时间不同
                if (jobTimerModelInDataBase.getClosed() == TimerStatusEnum.IN_PROCESSING.getType() && jobTimerModelInDataBase.getTimerValue().equals(timerValue)) {
                    // 已存在，dump 周期相同
                    return JobStartUpEnum.UPDATE_FAIL;
                }

                if (jobTimerModelInDataBase.getClosed() == TimerStatusEnum.IN_PROCESSING.getType() && !jobTimerModelInDataBase.getTimerValue().equals(timerValue)) {
                    // 已存在，但是 dump 周期不相同，走更新逻辑
                    jobTimerBiz.updateJobTimerByJobConfigIdAndType(jobTimerModel);
                    // 发送更新 dump 的消息
                    updateScheduleJob(jobTimerModel, jobTimerModelInDataBase);
                    sendUpdateCycleMsgToUser(jobConfigId, jobTimerModel, jobTimerModelInDataBase);
                    return JobStartUpEnum.UPDATE_SUCCESS;
                }

                if (jobTimerModelInDataBase.getClosed() == TimerStatusEnum.CLOSED.getType()) {
                    // 已存在，但是是关闭的，走开启逻辑
                    jobTimerBiz.updateJobTimerByJobConfigIdAndType(jobTimerModel);
                }
            }

            IdentityModel identityModel = buildIdentity(jobTimerModel);
            JobDetail jobDetail = buildJobDetail(jobTimerModel, identityModel);
            SimpleTrigger trigger = buildTrigger(jobTimerModel, identityModel);

            schedule(jobDetail, trigger);
            sendOpenCycleMsgToUser(jobConfigId, jobTimerModel);
            return JobStartUpEnum.SUCCESS;
        } catch (SchedulerException e) {
            sendErrorMsg(e.toString(), Integer.toString(jobConfigId));
            logger.error("Server Dump Job 启动失败", e);
            return JobStartUpEnum.FAIL;
        }
    }

    private Class<? extends CoverageJob> getJobByProjectType(ProjectTypeEnum projectTypeEnum) {
        switch (projectTypeEnum) {
            case PC:
            case I_VERSION:
            case APPLETS:
            case MRN:
                return CoverageFrontJob.class;
            case IOS:
                return CoverageIOSJob.class;
            case SERVER:
                return CoverageServerJob.class;
            case ANDROID:
                return CoverageAndroidJob.class;
            default:
                return null;
        }
    }

    public void closeCycleBuild(int jobId, int jobTimerType) {
        try {
            // 查询数据库中
            JobTimerModel jobTimerModel = jobTimerBiz.selectByJobConfigIdAndType(jobId, jobTimerType);
            IdentityModel identityModel = buildIdentity(jobTimerModel);

            TriggerKey triggerKey = TriggerKey.triggerKey(identityModel.getName(), identityModel.getGroup());
            JobKey jobKey = JobKey.jobKey(identityModel.getName(), identityModel.getGroup());

            logger.info("正在停止循环构建任务，JobId是{}，触发器Key是{}，JobKey是{}", jobId, triggerKey.getName(), jobKey.getName());

            schedule.pauseTrigger(triggerKey);
            schedule.unscheduleJob(triggerKey);
            // 删除任务
            schedule.deleteJob(jobKey);

            // 更新数据库内容
            jobTimerBiz.updateClosedByJobConfigIdAndType(jobId, jobTimerType);

            // 发送关闭定时构建的信息给用户
            sendCloseCycleMsgToUser(jobId, jobTimerType);
        } catch (SchedulerException e) {
            logger.error("关闭 Job 时出现异常", e);
        }
    }

    private void sendCloseCycleMsgToUser(int jobId, int jobTimerType) {
        JobManageModel jobManageModel = jobOptManage.getJobManageModelByJobConfigId(jobId);
        ProjectInfoModel projectInfoModel = projectOptManageBiz.getProjectInfoModelByProjectId(jobManageModel.getProjectConfigId());
        // 获取发送请求的用户
        User user = UserUtils.getUser();

        CycleBuildCloseMsgModel cycleBuildCloseMsgModel = new CycleBuildCloseMsgModel();
        cycleBuildCloseMsgModel.setCurrentTime(LocalDateTime.now());
        cycleBuildCloseMsgModel.setJobName(jobManageModel.getJobName());
        cycleBuildCloseMsgModel.setOperatingUser(user != null ? user.getLogin() : "SYSTEM");
        cycleBuildCloseMsgModel.setProjectLeader(projectInfoModel.getProjectLeader());
        cycleBuildCloseMsgModel.setJobTimerType(jobTimerType);
        cycleBuildCloseMsgModel.setProjectName(ShellUtils.getRepositoryName(projectInfoModel.getGitAddress()));
        XMPubUtil.sendMessage(cycleBuildCloseMsgModel.getMsg(), projectInfoModel.getProjectLeader());
    }

    private void sendOpenCycleMsgToUser(int jobId, JobTimerModel jobTimerModel) {
        JobManageModel jobManageModel = jobOptManage.getJobManageModelByJobConfigId(jobId);
        ProjectInfoModel projectInfoModel = projectOptManageBiz.getProjectInfoModelByProjectId(jobManageModel.getProjectConfigId());
        // 获取发送请求的用户
        User user = UserUtils.getUser();
        String userName = "";
        if (user != null) {
            userName = user.getLogin();
        } else {
            userName = "SYSTEM";
        }

        CycleBuildOpenMsgModel cycleBuildOpenMsgModel = new CycleBuildOpenMsgModel();
        cycleBuildOpenMsgModel.setCurrentTime(LocalDateTime.now());
        cycleBuildOpenMsgModel.setJobName(jobManageModel.getJobName());
        cycleBuildOpenMsgModel.setOperatingUser(userName);
        cycleBuildOpenMsgModel.setProjectLeader(projectInfoModel.getProjectLeader());
        cycleBuildOpenMsgModel.setTimerType(jobTimerModel.getTimerType());
        cycleBuildOpenMsgModel.setTimerValue(jobTimerModel.getTimerValue());
        cycleBuildOpenMsgModel.setJobTimerType(jobTimerModel.getType());
        cycleBuildOpenMsgModel.setProjectName(ShellUtils.getRepositoryName(projectInfoModel.getGitAddress()));

        XMPubUtil.sendMessage(cycleBuildOpenMsgModel.getMsg(), projectInfoModel.getProjectLeader());
    }

    private void sendUpdateCycleMsgToUser(int jobId, JobTimerModel jobTimerModel, JobTimerModel originJobTimerModel) {
        JobManageModel jobManageModel = jobOptManage.getJobManageModelByJobConfigId(jobId);
        ProjectInfoModel projectInfoModel = projectOptManageBiz.getProjectInfoModelByProjectId(jobManageModel.getProjectConfigId());
        // 获取发送请求的用户
        User user = UserUtils.getUser();

        CycleBuildUpdateMsgModel cycleBuildUpdateMsgModel = new CycleBuildUpdateMsgModel();
        cycleBuildUpdateMsgModel.setCurrentTime(LocalDateTime.now());
        cycleBuildUpdateMsgModel.setJobName(jobManageModel.getJobName());
        cycleBuildUpdateMsgModel.setOperatingUser(user.getLogin());
        cycleBuildUpdateMsgModel.setProjectLeader(projectInfoModel.getProjectLeader());
        cycleBuildUpdateMsgModel.setTimerType(jobTimerModel.getTimerType());
        cycleBuildUpdateMsgModel.setTimerValue(jobTimerModel.getTimerValue());
        cycleBuildUpdateMsgModel.setOriginTimerType(originJobTimerModel.getTimerType());
        cycleBuildUpdateMsgModel.setOriginTimerValue(originJobTimerModel.getTimerValue());
        cycleBuildUpdateMsgModel.setProjectName(ShellUtils.getRepositoryName(projectInfoModel.getGitAddress()));
        cycleBuildUpdateMsgModel.setJobTimerType(jobTimerModel.getType());

        XMPubUtil.sendMessage(cycleBuildUpdateMsgModel.getMsg(), projectInfoModel.getProjectLeader());
    }

    private void sendErrorMsg(String error, String request) {
        XMPubUtil.sendToDeveloper("Job 构建出现异常, 错误详情如下: \n" + error + "\n 请求参数如下: \n" + request);
    }

    private void sendErrorMsg(String error, String request, String des) {
        XMPubUtil.sendToDeveloper("Job 构建出现异常, 错误详情如下: \n" + error + "\n 请求参数如下: \n" + request + "\n 其他内容:" + des);
    }


    public List<JobExecutionContext> getCurrentlyExecutingJobs() {
        try {
            return schedule.getCurrentlyExecutingJobs();
        } catch (SchedulerException e) {
            e.printStackTrace();
            return null;
        }
    }

    public List<String> getJobGroupNames() {
        try {
            return schedule.getJobGroupNames();
        } catch (SchedulerException e) {
            e.printStackTrace();
            return null;
        }
    }

    public Set<JobKey> getJobs() {
        try {
            return schedule.getJobKeys(GroupMatcher.anyGroup());
        } catch (SchedulerException e) {
            e.printStackTrace();
            return null;
        }
    }
}
