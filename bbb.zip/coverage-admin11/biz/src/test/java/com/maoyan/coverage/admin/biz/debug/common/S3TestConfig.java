package com.maoyan.coverage.admin.biz.debug.common;

import lombok.Data;

/**
 * @author lizhuoran05
 * @date 2021/11/3
 */
public class S3TestConfig {
    private static String accessKey = "94989233a9554dc3923d523458c05429";
    private static String secretKey = "dabf3b57d40d4b909e675cf2323a056a";
    private static String host = "msstest.vip.sankuai.com";
    private static String bucket = "coverage-report-test-data";

    public static String getAccessKey() {
        return accessKey;
    }

    public static String getSecretKey() {
        return secretKey;
    }

    public static String getHost() {
        return host;
    }

    public static String getBucket() {
        return bucket;
    }
}
