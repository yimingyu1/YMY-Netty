package com.maoyan.coverage.admin.biz.debug.android;

import com.maoyan.coverage.admin.biz.debug.common.S3Common;
import com.maoyan.coverage.admin.common.utils.ShellUtils;
import com.maoyan.coverage.admin.common.utils.ZipUtils;

import com.meituan.jacoco.report.MtAnalyzer;
import com.meituan.jacoco.report.MtJacocoReport;
import com.meituan.jacoco.report.model.BranchCodePath;
import com.meituan.jacoco.report.model.JobBuildPath;
import org.jacoco.core.analysis.Analyzer;
import org.jacoco.core.analysis.CoverageBuilder;
import org.jacoco.core.tools.ExecFileLoader;
import org.jacoco.report.DirectorySourceFileLocator;
import org.jacoco.report.FileMultiReportOutput;
import org.jacoco.report.IReportVisitor;
import org.jacoco.report.html.HTMLFormatter;


import java.io.File;
import java.io.IOException;

/**
 * @author lizhuoran05
 * @date 2021/11/3
 */
public class AndroidDebug {

    private static final String currentPath = System.getProperty("user.dir") + "/biz/src/test/java/com/maoyan/coverage/admin/biz/debug/android/";
    private static final String gitUrl = "ssh://git@git.sankuai.com/myan/aimovie.git";

    private static final String CODE_CURRENT = "code/current";
    private static final String CODE_ORIGIN = "code/origin";
    private static final String DATA = "data";
    private static final String CLASS = "class";
    private static final String SRC = "src";
    private static final String REPORT_MY_JACOCO = "report-myjacoco";
    private static final String REPORT_JACOCO = "report-jacoco";

    private static final String J_CODE_CURRENT = currentPath + CODE_CURRENT;
    private static final String J_CODE_ORIGIN = currentPath + CODE_ORIGIN;
    private static final String J_EC_PATH = currentPath + DATA;
    private static final String J_CLASS_PATH = currentPath + CLASS;
    private static final String J_SRC_PATH = currentPath + SRC;
    private static final String J_REPORT_MY_JACOCO_PATH = currentPath + REPORT_MY_JACOCO;
    private static final String J_REPORT_JACOCO_PATH = currentPath + REPORT_JACOCO;

    private static final String CURRENT_BRANCH = "feature/feature/tapd-1021118-compare";
    private static final String ORIGIN_BRANCH = "feature/tapd-1021118";

    public static void main(String[] args) throws Exception {
        // 如何确定是否插桩成功？
        // 如何确定是生产报告的问题？
        generateReportByJacoco();
    }

    public static void prepare() {
        downloadClass();
        downloadSrc();
        downloadEc();
        cloneCode(CURRENT_BRANCH, J_CODE_CURRENT);
        cloneCode(ORIGIN_BRANCH, J_CODE_ORIGIN);
    }

    public static void generateReportByMyJacoco() {
        BranchCodePath branchCodePath = new BranchCodePath();
        branchCodePath.setCurrentBranchCodePath(J_CODE_CURRENT);
        branchCodePath.setOriginBranchCodePath(J_CODE_ORIGIN);

        JobBuildPath jobBuildPath = new JobBuildPath();
        jobBuildPath.setEcPath(J_EC_PATH);
        jobBuildPath.setClsPath(J_CLASS_PATH);
        jobBuildPath.setSrcPath(J_SRC_PATH);
        jobBuildPath.setOutputPath(J_REPORT_MY_JACOCO_PATH);

        MtJacocoReport mtJacocoReport = new MtJacocoReport();
        mtJacocoReport.generate(jobBuildPath, branchCodePath);
    }

    private static ExecFileLoader loadExecutionDataByJacoco(File ecFile) throws Exception {
        ExecFileLoader execFileLoader = new ExecFileLoader();
        File[] ecFileArray = ecFile.listFiles();
        //合并ec文件
        for (File curFile : ecFileArray) {
            execFileLoader.load(curFile);
        }
        return execFileLoader;
    }

    public static void generateReportByJacoco() throws Exception {
        ExecFileLoader execFileLoader = loadExecutionDataByJacoco(new File(J_EC_PATH));

        final CoverageBuilder coverageBuilder = new CoverageBuilder();
        final Analyzer analyzer = new Analyzer(
                execFileLoader.getExecutionDataStore(), coverageBuilder);

        analyzer.analyzeAll(new File(J_CLASS_PATH));

        final HTMLFormatter htmlFormatter = new HTMLFormatter();
        final IReportVisitor visitor = htmlFormatter
                .createVisitor(new FileMultiReportOutput(new File(J_REPORT_JACOCO_PATH)));

        visitor.visitInfo(execFileLoader.getSessionInfoStore().getInfos(),
                execFileLoader.getExecutionDataStore().getContents());


        visitor.visitBundle(coverageBuilder.getBundle(""),
                new DirectorySourceFileLocator(new File(J_SRC_PATH), "utf-8", 4));


        visitor.visitEnd();
    }

    private static void cloneCode(String branch, String codePath) {
        ShellUtils.cloneCode(gitUrl, branch, codePath);
    }

    public static void downloadEc() {
        S3Common s3Common = new S3Common("prod");
        String ecFileObjectName = "android/coverage_data/com.sankuai.movie/9.26.0.0/114/ec";
        s3Common.downloadFile(ecFileObjectName, currentPath + "data/");
    }

    public static void downloadClass() {
        S3Common s3Common = new S3Common("prod");
        String className = "android/coverage_data/com.sankuai.movie/9.26.0.0/114/class";
        String localFilePath = s3Common.downloadFile(className, currentPath + "class/");
        ZipUtils.unzip(localFilePath, currentPath + "class/");
    }

    public static void downloadSrc() {
        S3Common s3Common = new S3Common("prod");
        String className = "android/coverage_data/com.sankuai.movie/9.26.0.0/114/src";
        String localFilePath = s3Common.downloadFile(className, currentPath + "src/");
        ZipUtils.unzip(localFilePath, currentPath + "src/");
    }

}
