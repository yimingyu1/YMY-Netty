package com.maoyan.coverage.admin.biz.debug.common;

import lombok.Data;

/**
 * @author lizhuoran05
 * @date 2021/11/3
 */
public class S3ProdConfig {
    private static String accessKey = "cc87244abb354e34b8e0b116e758dcf9";
    private static String secretKey = "9b4c6e3e1d6e4bd7b1ae06393ed61829";
    private static String host = "s3plus.vip.sankuai.com";
    private static String bucket = "coverage-report-data";

    public static String getAccessKey() {
        return accessKey;
    }

    public static String getSecretKey() {
        return secretKey;
    }

    public static String getHost() {
        return host;
    }

    public static String getBucket() {
        return bucket;
    }
}
