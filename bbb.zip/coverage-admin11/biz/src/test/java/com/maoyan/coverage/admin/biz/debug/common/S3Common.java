package com.maoyan.coverage.admin.biz.debug.common;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.S3ClientOptions;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.ListObjectsRequest;
import com.amazonaws.services.s3.model.ObjectListing;
import com.amazonaws.services.s3.model.S3ObjectSummary;

import java.io.File;
import java.util.ArrayList;

/**
 * @author lizhuoran05
 * @date 2021/11/3
 */
public class S3Common {

    private AmazonS3 s3Client;
    private String accessKey = "";
    private String secretKey = "";
    private String host = "";
    private String bucket = "";

    public S3Common(String env) {

        if (env.equals("test")) {
            accessKey = S3TestConfig.getAccessKey();
            secretKey = S3TestConfig.getSecretKey();
            host = S3TestConfig.getHost();
            bucket = S3TestConfig.getBucket();
        } else if (env.equals("prod")) {
            accessKey = S3ProdConfig.getAccessKey();
            secretKey = S3ProdConfig.getSecretKey();
            host = S3ProdConfig.getHost();
            bucket = S3ProdConfig.getBucket();
        }


        S3ClientOptions s3ClientOptions = new S3ClientOptions();
        s3ClientOptions.setPathStyleAccess(true);

        AWSCredentials credentials = new BasicAWSCredentials(accessKey, secretKey);
        //生成云存储api client
        s3Client = new AmazonS3Client(credentials);
        //配置云存储服务地址
        s3Client.setEndpoint(host);
        s3Client.setS3ClientOptions(s3ClientOptions);
    }

    public String downloadFile(String prefix, String localFilePath) {
        ListObjectsRequest listObjectsRequest = new ListObjectsRequest()
                .withBucketName(bucket)
                //查询bucket下固定的前缀
                .withPrefix(prefix);
        ObjectListing objectListing = null;
        objectListing = s3Client.listObjects(listObjectsRequest);

        StringBuilder localFilePathBuilder = new StringBuilder(localFilePath);
        for (S3ObjectSummary objectSummary : objectListing.getObjectSummaries()) {

            String[] paths = objectSummary.getKey().split("/");

            s3Client.getObject(new GetObjectRequest(bucket, objectSummary.getKey()), new File(localFilePathBuilder + paths[paths.length - 1]));
            if (objectListing.getObjectSummaries().size() == 1) {
                localFilePathBuilder.append(paths[paths.length - 1]);
            }
            System.out.println("download：" + localFilePathBuilder + paths[paths.length - 1]);
        }
        localFilePath = localFilePathBuilder.toString();
        return localFilePath;
    }


}
