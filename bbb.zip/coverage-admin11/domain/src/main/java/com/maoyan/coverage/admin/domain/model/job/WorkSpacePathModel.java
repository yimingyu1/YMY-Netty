package com.maoyan.coverage.admin.domain.model.job;

import lombok.Data;

/**
 * 工作区路径
 * @author lizhuoran05
 * @date 2021/8/3
 */
@Data
public class WorkSpacePathModel {

    private String codeWorkSpacePath;

    private String dataWorkSpacePath;

    private String reportWorkSpacePath;

    private String baseWorkSpacePath;

    public WorkSpacePathModel(String baseWorkSpacePath) {
        this.baseWorkSpacePath = baseWorkSpacePath;
    }

    public WorkSpacePathModel() {
    }
}
