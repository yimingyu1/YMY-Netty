package com.maoyan.coverage.admin.domain.model.job.msg;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author lizhuoran05
 * @date 2021/9/14
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class BuildFailedToDeveloperMsgModel extends BuildFailedToUserMsgModel {

    /**
     * jobId
     */
    private int jobId;


    /**
     * 错误信息
     */
    private String error;

    private String info;


    /**
     * 获取发送给开发者的信息
     *
     * @return
     */
    public String getMsg() {
        String lineFeed = "\n";
        String info = "【 信息 】: " + getInfo() + lineFeed;
        String jobId = "【 jobId 】: " + getJobId() + lineFeed;
        String buildName = "【 buildNum 】: " + getBuildNum() + lineFeed;
        String jobName = "【 jobName 】: " + getJobName() + lineFeed;
        String projectName = "【 关联项目 】: " + getProjectName() + lineFeed;
        String buildHistory = "【 构建历史 】: " + "[点击查看|" + getBuildHistoryUrl() + "]" + lineFeed;
        String error = "【 错误信息 】" + getError() + lineFeed;
        String remarks = "【 备注 】: " + getRemarks();

        // 拼接字符串
        return info.concat(jobId).concat(buildName).concat(jobName).concat(projectName).concat(buildHistory).concat(error).concat(remarks);
    }
}
