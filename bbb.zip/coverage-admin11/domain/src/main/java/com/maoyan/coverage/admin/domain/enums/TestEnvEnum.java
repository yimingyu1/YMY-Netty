package com.maoyan.coverage.admin.domain.enums;

/**
 * 测试环境枚举
 *
 * @author lizhuoran05
 * @date 2021/7/9
 */
public enum TestEnvEnum {
    STAGING("staging", "测试在 st 环境"),

    TEST("test", "测试在 test 环境");

    private String env;

    public String getEnv() {
        return env;
    }

    public void setEnv(String env) {
        this.env = env;
    }

    public String getDec() {
        return dec;
    }

    public void setDec(String dec) {
        this.dec = dec;
    }

    private String dec;

    private TestEnvEnum(String env, String dec) {
        this.env = env;
        this.dec = dec;
    }
}
