package com.maoyan.coverage.admin.domain.schema.businessline;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * @author yimingyu
 * @date 2021/07/19
 */
@Data
public class BusinessLineDO implements Serializable {
    private static final long serialVersionUID = 9201942109062252573L;

    private Integer id;
    private String businessLine;
    private String creator;
    private String updater;
    /**
     * '删除状态， 0：未删除 1：已删除'
     */
    private Integer deleted;
    private LocalDateTime createTime;
    private LocalDateTime updateTime;

}
