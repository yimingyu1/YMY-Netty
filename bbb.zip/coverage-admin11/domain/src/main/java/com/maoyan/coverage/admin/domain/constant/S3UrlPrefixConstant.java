package com.maoyan.coverage.admin.domain.constant;

/**
 * @author lizhuoran05
 * @date 2021/8/11
 */
public class S3UrlPrefixConstant {

    public static final String TEST_URL = "http://msstest.vip.sankuai.com/coverage-report-test-data/";

    public static final String PROD_URL = "http://s3plus.vip.sankuai.com/coverage-report-data/";

}
