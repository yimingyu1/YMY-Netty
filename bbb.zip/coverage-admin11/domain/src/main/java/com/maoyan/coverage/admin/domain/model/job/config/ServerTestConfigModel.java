package com.maoyan.coverage.admin.domain.model.job.config;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.LocalDateTime;
import java.util.HashMap;

/**
 * 服务端测试配置
 * @author lizhuoran05
 * @date 2021/7/29
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class ServerTestConfigModel extends TestConfigModel{

    /**
     * 测试环境
     */
    private String testEnv;

    /**
     * ip：port
     */
    private HashMap<String, String> ipAndPortMap;

    /**
     * 发布项Id
     */
    private int releaseId;

    /**
     * 服务端项目的在服务器上的存放地址
     * 与manifest中配置的targetDir一致
     */
    private String targetDir;

    private LocalDateTime testStartTime;

    private LocalDateTime testEndTime;

}
