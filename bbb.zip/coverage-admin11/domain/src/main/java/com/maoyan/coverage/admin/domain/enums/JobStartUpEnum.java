package com.maoyan.coverage.admin.domain.enums;

/**
 * @author lizhuoran05
 * @date 2021/7/27
 */
public enum JobStartUpEnum {

    SUCCESS(0, "启动成功"),
    FAIL(1, "启动失败"),
    UPDATE_SUCCESS(2, "更新构建周期成功"),
    UPDATE_FAIL(3, "相同配置的任务已存在, 无需更新");

    int type;
    String des;

    JobStartUpEnum(int type, String des) {
        this.type = type;
        this.des = des;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getDes() {
        return des;
    }

    public void setDes(String des) {
        this.des = des;
    }

}
