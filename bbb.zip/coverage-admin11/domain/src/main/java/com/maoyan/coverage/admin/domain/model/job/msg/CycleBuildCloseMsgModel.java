package com.maoyan.coverage.admin.domain.model.job.msg;

import com.maoyan.coverage.admin.domain.enums.JobTimerTypeEnum;
import lombok.Data;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;

/**
 * 关闭定时构建发送的消息
 * @author lizhuoran05
 * @date 2021/9/14
 */
@Data
public class CycleBuildCloseMsgModel {

    private String jobName;

    /**
     * 关闭时间
     */
    private LocalDateTime currentTime;

    /**
     * 操作用户
     */
    private String operatingUser;

    private List<String> projectLeader;

    private int jobTimerType;

    /**
     * 关联项目
     */
    private String projectName;

    public String getMsg() {
        String lineFeed = "\n";
        String info = "";
        if(jobTimerType == JobTimerTypeEnum.JOB_BUILD_TIMER.getType()) {
            info = "【 信息 】: 关闭定时构建" + lineFeed;
        }else if(jobTimerType == JobTimerTypeEnum.SERVER_JOB_DUMP_TIMER.getType()) {
            info = "【 信息 】: 服务端 Dump 任务已关闭" + lineFeed;
        }
        String jobName = "【 job 名称 】: " + getJobName() + lineFeed;
        String projectName = "【 关联项目 】: " + getProjectName() + lineFeed;
        String operatingUser = "【 操作用户 】: " + getOperatingUser() + lineFeed;
        String closeTime = "【 关闭时间 】: " + getCurrentTime().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")) + lineFeed;
        String projectLeader = "【 通知用户 】: " + getProjectLeader().toString() + lineFeed;

        // 拼接字符串
        return info.concat(jobName).concat(projectName).concat(operatingUser).concat(closeTime).concat(projectLeader);
    }

}
