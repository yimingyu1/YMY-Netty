package com.maoyan.coverage.admin.domain.model.job.path;

import lombok.Data;

/**
 * @author lizhuoran05
 * @date 2021/8/30
 */
@Data
public class AndroidWorkSpacePathModel {

    private String ecFilePath;

    private String classPath;

    private String srcPath;

    private String commitPath;

}
