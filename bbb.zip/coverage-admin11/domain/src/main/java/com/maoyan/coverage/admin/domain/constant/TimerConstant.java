package com.maoyan.coverage.admin.domain.constant;

/**
 * @author lizhuoran05
 * @date 2021/7/30
 */
public class TimerConstant {

    /**
     * 重复次数：0次
     */
    public static final int REPEAT_NUM_ZERO = 0;

    public static final int interval = 0;

}
