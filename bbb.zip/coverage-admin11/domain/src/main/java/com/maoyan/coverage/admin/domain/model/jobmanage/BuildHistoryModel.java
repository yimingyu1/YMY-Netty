package com.maoyan.coverage.admin.domain.model.jobmanage;

import lombok.Data;

import java.time.LocalDateTime;

/**
 * @author lizhuoran05
 * @date 2021/7/29
 */
@Data
public class BuildHistoryModel {

    private Integer id;

    /**
     * 关联的 job_config 的 id
     */
    private Integer jobConfigId;

    /**
     * buildNum
     */
    private Integer buildNum;

    /**
     * 构建类型
     * 1：手动
     * 2：定时
     */
    private Integer buildType;

    /**
     * 构建开始时间
     */
    private LocalDateTime startTime;

    /**
     * 构建结束时间
     */
    private LocalDateTime endTime;

    /**
     * commit
     */
    private String commit;

    /**
     * 本次覆盖的行数
     * 新增或者全量
     */
    private Integer linesCovered;

    /**
     * 本次分析的代码的总行数
     * 新增或者全量
     */
    private Integer lineNum;

    /**
     * 本次覆盖的分支数
     * 新增或者全量
     */
    private Integer branchesCovered;

    /**
     * 本次分析的代码的总分支数
     * 新增或者全量
     */
    private Integer branches;

    /**
     * 构建者
     * 如果是定时，则是 System
     */
    private String builder;

    /**
     * 构建状态
     * 0:空闲 1：构建中 2: 构建结束
     */
    private Integer buildStatus;

    /**
     * 构建结果
     * 0：未知 1：成功 2：失败
     */
    private Integer buildResult;

    /**
     * Job 构建使用的配置
     */
    private String jobBuildConfig;

}
