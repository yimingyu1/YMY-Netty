package com.maoyan.coverage.admin.domain.vo.projectmanage;

import lombok.Data;

import java.io.Serializable;

/**
 * @author yimingyu
 * @date 2021/10/27
 * 给chaoyue平台提供的VO
 */
@Data
public class CProjectManageVO implements Serializable {

    private static final long serialVersionUID = -1444939660285646536L;
    private int id;
    private String projectName;
}
