package com.maoyan.coverage.admin.domain.model;

import lombok.Data;

/**
 * @author lizhuoran05
 * @date 2021/7/19
 */
@Data
public class TimerConfigModel {

    private int timerType;

    private String timerValue;

}
