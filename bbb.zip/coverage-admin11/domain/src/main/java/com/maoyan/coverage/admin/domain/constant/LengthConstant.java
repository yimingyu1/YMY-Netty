package com.maoyan.coverage.admin.domain.constant;

/**
 * @author yimingyu
 * @date 2021/09/16
 */
public class LengthConstant {
    public static final int BUSINESS_LINE_MAX_LENGTH = 64;
    public static final int JOB_NAME_MAX_LENGTH = 64;
    public static final int PROJECT_LEADER_MAX_LENGTH = 15;
    public static final int PROJECT_NAME_MAX_LENGTH = 100;
    public static final int PROJECT_REPOSITORY_ADDRESS_MAX_LENGTH = 120;
}
