package com.maoyan.coverage.admin.domain.schema.projectmanage;

import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * @author yimingyu
 * @date 2021/07/22
 */
@Data
public class ProjectManageDO implements Serializable {
    private static final long serialVersionUID = -7386650668433612977L;

    private Integer id;
    private Integer businessLineId;
    private String projectName;
    private String projectLeader;
    private Integer type;
    private String creator;
    private String updater;
    private String repositoryAddress;
    /**
     * 0:未删除  1:已删除
     */
    private Integer deleted;
    private LocalDateTime createTime;
    private LocalDateTime updateTime;


}
