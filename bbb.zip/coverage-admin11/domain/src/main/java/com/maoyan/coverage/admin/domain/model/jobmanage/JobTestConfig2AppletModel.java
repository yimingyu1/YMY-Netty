package com.maoyan.coverage.admin.domain.model.jobmanage;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @author yimingyu
 * @date 2021/07/27
 */
@Data
public class JobTestConfig2AppletModel implements Serializable {
    private static final long serialVersionUID = -8320113959865702965L;

    private String commit;
    private List<String> testTime;
    private String testEnv;
}
