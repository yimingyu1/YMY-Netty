package com.maoyan.coverage.admin.domain.model.job;

import lombok.Data;

/**
 * @author lizhuoran05
 * @date 2021/7/27
 */
@Data
public class IdentityModel {

    private String name;

    private String group;
}
