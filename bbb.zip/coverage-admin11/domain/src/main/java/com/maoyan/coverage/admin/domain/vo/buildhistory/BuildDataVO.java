package com.maoyan.coverage.admin.domain.vo.buildhistory;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @author yimingyu
 * @date 2021/08/02
 */
@Data
public class BuildDataVO implements Serializable {

    private static final long serialVersionUID = 2849031578943963144L;

    private String key;
    private String name;
    private String data;
    private String dataRate;
    private String dataRateColor;
    private List<BelowThresholdFilesVO> belowThresholdFiles;
}
