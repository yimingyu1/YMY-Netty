package com.maoyan.coverage.admin.domain.schema.buildHistory;

import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * @author yimingyu
 * @date 2021/07/30
 */
@Data
public class BuildHistoryDetailDO implements Serializable {
    private static final long serialVersionUID = -3648298142539679156L;

    private Integer id;
    private Integer buildHistoryId;
    private String dataIndicators;
    private String reportDetailUrl;
    private LocalDateTime createTime;
    private LocalDateTime updateTime;
}
