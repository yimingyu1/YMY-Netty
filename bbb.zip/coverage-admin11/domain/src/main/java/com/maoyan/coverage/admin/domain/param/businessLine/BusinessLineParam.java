package com.maoyan.coverage.admin.domain.param.businessLine;

import lombok.Data;
import org.springframework.web.bind.annotation.RequestParam;

import java.io.Serializable;

/**
 * @author yimingyu
 * @date 2021/08/19
 */
@Data
public class BusinessLineParam implements Serializable {
    private static final long serialVersionUID = 6241956965405470939L;

    private  String businessLineName;
    private  Integer businessLineId;

}
