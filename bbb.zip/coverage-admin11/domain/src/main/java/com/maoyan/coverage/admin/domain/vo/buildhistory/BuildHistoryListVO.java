package com.maoyan.coverage.admin.domain.vo.buildhistory;

import com.maoyan.coverage.admin.domain.constant.BuildHistoryListVOConstant;
import com.maoyan.coverage.admin.domain.enums.CoveredRateColorEnum;
import lombok.Data;

import java.io.Serializable;

/**
 * @author yimingyu
 * @date 2021/07/29
 */
@Data
public class BuildHistoryListVO implements Serializable {
    private static final long serialVersionUID = -1250316503095037039L;

    private int id;
    private int buildNum;
    private int buildHistoryId;
    // 构建类型  '构建类型  0：未知 1：手动 2：定时'
    private String buildType;
    // 构建人
    private String builder;
    // 构建状态 '构建状态 0:空闲 1：构建中 2: 构建结束'
    private int buildStatus;
    // 'build结果 0：未知 1：成功 2：失败'
    private int buildResult;
    private String startTime;
    private String endTime = BuildHistoryListVOConstant.defaultStr;
    private String commit = BuildHistoryListVOConstant.defaultStr;
    private String commitRef = BuildHistoryListVOConstant.defaultStr;
    private String coveredLines = BuildHistoryListVOConstant.defaultStr;
    private String coveredBranches = BuildHistoryListVOConstant.defaultStr;
    private String coveredLinesColor = CoveredRateColorEnum.BUILDING_RATE_COLOR.getCoveredRateColor();
    private String coveredBranchesColor = CoveredRateColorEnum.BUILDING_RATE_COLOR.getCoveredRateColor();
    private String jenkinsBuildNum;
    private String jenkinsRef;
}
