package com.maoyan.coverage.admin.domain.vo.businessline;

import lombok.Data;

import java.io.Serializable;

@Data
public class BusinessLineVO implements Serializable {
    private static final long serialVersionUID = 9109789486775753545L;
    private int id;
    private String businessLineName;
    private String creator;
    private String createTime;

}
