package com.maoyan.coverage.admin.domain.model.job.front;

import lombok.Data;

/**
 * 增量构建对象 -> 发送给Node服务的
 * @author lizhuoran05
 * @date 2021/8/17
 */
@Data
public class IncrementBuildModel {

    /**
     * 项目名称（其实是 仓库名称）
     */
    private String projectName;

    /**
     * 项目类型
     */
    private String projectType;

    /**
     * git 仓库地址
     */
    private String gitUrl;

    /**
     * 原始分支
     */
    private String originBranch;

    /**
     * 当前测试分支
     */
    private String currentBranch;

    /**
     * 测试开始时间
     */
    private String testStartTime;

    /**
     * 测试结束时间
     */
    private String testEndTime;

    /**
     * 要上传的S3环境
     */
    private String testEnv;

    /**
     * 该 Job 的buildNum
     */
    private String buildNumber;

    /**
     * 阈值
     */
    private Double threshold;

    /**
     * jobId
     */
    private Integer jobId;
}
