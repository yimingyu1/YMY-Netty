package com.maoyan.coverage.admin.domain.constant;

/**
 * @author lizhuoran05
 * @date 2021/8/2
 */
public class PublisherConstant {

    public static final String[] SERVER_DEVELOPER = {
            "lizhuoran05",
            "yimingyu",
            "guoyixuan",
            "weibin05",
            "fengxingbing"
    };

//    public static final String[] SERVER_DEVELOPER = {
//            "lizhuoran05",
//    };

}
