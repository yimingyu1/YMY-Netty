package com.maoyan.coverage.admin.domain.param.job;

import com.maoyan.coverage.admin.domain.model.TimerConfigModel;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author lizhuoran05
 * @date 2021/7/19
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class CycleBuildParam extends BuildParam{

    private TimerConfigModel timerConfig;

}
