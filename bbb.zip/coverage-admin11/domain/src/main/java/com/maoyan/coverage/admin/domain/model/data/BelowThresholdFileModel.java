package com.maoyan.coverage.admin.domain.model.data;

import lombok.Data;
import java.util.ArrayList;
import java.util.List;
import com.opencsv.CSVParser;
import com.opencsv.CSVReader;
import java.math.BigDecimal;
import java.io.*;

/**
 * 低于阈值的文件对象
 * @author lizhuoran05
 * @date 2021/7/26
 */
@Data
public class BelowThresholdFileModel {

    /**
     * 文件名字
     */
    private String name;

    private String url;

    private int total;

    private int covered;

}


