package com.maoyan.coverage.admin.domain.constant;

/**
 * @author yimingyu
 * @date 2021/08/25
 */
public class DateFormatStr {
    public static final String DATE_FORMAT_VO = "yyyy-MM-dd HH:mm:ss";
    public static final String DATE_FORMAT_DO = "yyyy/MM/dd-HH:mm:ss";
    public static final String DATE_FORMAT_UPLOAD = "yyyy-MM-dd";
    public static final String DATE_FORMAT_TIME_STAMP = "timeStamp";
}
