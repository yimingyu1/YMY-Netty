package com.maoyan.coverage.admin.domain.vo.buildhistory;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @author yimingyu
 * @date 2021/07/30
 */
@Data
public class BuildHistoryDetailVO implements Serializable {
    private static final long serialVersionUID = 4505860233769071400L;

    private String projectName;
    private String jobName;
    private int buildNum;
    private String currentBranch;
    private String originBranch;
    private double threshold;
    private String reportDetailUrl;
    private List<BuildDataVO> dataIndicatorsFileList;
}
