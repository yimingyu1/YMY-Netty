package com.maoyan.coverage.admin.domain.vo.jobmanage;

import lombok.Data;

import java.io.Serializable;

/**
 * @author yimingyu
 * @date 2021/10/27
 */
@Data
public class CJobConfigVO implements Serializable {
    private static final long serialVersionUID = -5184041208947839031L;
    private int id;
    private String jobName;
}
