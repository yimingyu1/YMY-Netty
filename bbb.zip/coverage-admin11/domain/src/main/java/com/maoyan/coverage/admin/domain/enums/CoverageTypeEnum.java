package com.maoyan.coverage.admin.domain.enums;

/**
 * 这是上传覆盖率数据时使用的枚举，后续考虑优化掉
 * Created by lihongmei03 on 2020-12-07
 */
public enum CoverageTypeEnum {
    SERVER(0, "server"),
    WEB(1, "web"),
    WECHAT(2, "wechat"),
    ANDROID(3, "android"),
    iOS(5, "iOS");

    private CoverageTypeEnum(int type, String path) {
        this.type = type;
        this.path = path;
    }

    private final int type;
    private final String path;

    public int getType() {
        return type;
    }

    public String getPath() {
        return path;
    }
}
