package com.maoyan.coverage.admin.domain.constant;

/**
 * @author yimingyu
 * @date 2021/09/03
 */
public class RepositoryRefConstant {
    public static final String REPOSITORY_PREFIX = "https://dev.sankuai.com/code/repo-detail/";
    public static final String REPOSITORY_SUFFIX = "/file/list";
    public static final String REPOSITORY_COMMIT_SUFFIX = "/commit/";
    public static final String DEFAULT_REPOSITORY_ROUTE = "http://dev.sankuai.com/code/repository/group";
}
