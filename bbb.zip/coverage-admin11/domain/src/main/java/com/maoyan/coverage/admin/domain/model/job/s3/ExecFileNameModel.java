package com.maoyan.coverage.admin.domain.model.job.s3;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * 服务端文件名字对象
 * <p>
 * commit-ip-{uploadTime}.exec
 *
 * @author lizhuoran05
 * @date 2021/8/6
 */
@Data
@AllArgsConstructor
public class ExecFileNameModel {

    private String commit;

    private String ip;

    /**
     * 时间戳的toString
     */
    private String uploadTime;

    private String objectName;

    public static ExecFileNameModel format(String objectUrl) {
        String[] pathArray = objectUrl.split("/");
        String ecFile = pathArray[pathArray.length - 1];
        String[] identifies = ecFile.split("-");
        String commit = identifies[0];
        String ip = identifies[1];
        String[] uploadTimeAndSuffix = null;
        if (identifies.length == 4) {
            uploadTimeAndSuffix = identifies[3].split("\\.");
        }
        if (identifies.length == 3){
            uploadTimeAndSuffix = identifies[2].split("\\.");
        }
        String uploadTime = uploadTimeAndSuffix[0];

        return new ExecFileNameModel(commit, ip, uploadTime, objectUrl);
    }
}
