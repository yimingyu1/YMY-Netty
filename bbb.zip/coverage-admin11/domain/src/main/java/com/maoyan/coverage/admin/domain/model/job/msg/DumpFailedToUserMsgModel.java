package com.maoyan.coverage.admin.domain.model.job.msg;

import lombok.Data;

import java.util.List;

/**
 * dump 失败时，发送异常消息给用户
 * @author lizhuoran05
 * @date 2021/9/14
 */
@Data
public class DumpFailedToUserMsgModel {

    /**
     * jobName
     */
    private String jobName;

    /**
     * projectName
     */
    private String projectName;


    /**
     * 备注
     */
    private String remarks;

    private List<String> projectLeader;

    /**
     * 获取发给用户的信息
     *
     * @return
     */
    public String getMsg() {
        String lineFeed = "\n";
        String info = "【 信息 】: 获取被测试服务器上的 exec 异常" + lineFeed;
        String jobName = "【 job 名称 】: " + getJobName() + lineFeed;
        String projectName = "【 关联项目 】: " + getProjectName() + lineFeed;
        String projectLeader = "【 通知用户 】: " + getProjectLeader().toString() + lineFeed;
        String remarks = "【 备注 】: " + getRemarks();

        // 拼接字符串
        return info.concat(jobName).concat(projectName).concat(projectLeader).concat(remarks);
    }
}
