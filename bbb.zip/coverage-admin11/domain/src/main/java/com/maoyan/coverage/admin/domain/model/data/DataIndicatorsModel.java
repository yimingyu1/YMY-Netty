package com.maoyan.coverage.admin.domain.model.data;

import lombok.Data;

import java.util.ArrayList;
import com.opencsv.CSVParser;
import com.opencsv.CSVReader;
import java.math.BigDecimal;

import java.io.*;

/**
 * 数据指标对象
 * @author lizhuoran05
 * @date 2021/7/26
 */
@Data
public class DataIndicatorsModel {

    private String key;

    private String name;

    /**
     * 该指标下的总数
     */
    private int total;

    /**
     * 该指标下覆盖的数量
     */
    private int covered;

    /**
     * 该指标下低于阈值的文件列表
     */
    private ArrayList<BelowThresholdFileModel> belowThresholdFiles;

}

