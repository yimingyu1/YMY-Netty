package com.maoyan.coverage.admin.domain.model.job.config;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * iOS测试配置
 * @author lizhuoran05
 * @date 2021/7/29
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class IOSTestConfigModel extends TestConfigModel{

    /**
     * 测试版本
     */
    private String testVersion;

    /**
     * 项目版本
     * TODO 确定项目版本格式
     */
    private Integer projectVersion;
}
