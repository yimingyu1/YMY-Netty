package com.maoyan.coverage.admin.domain.model.jobmanage;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * @author yimingyu
 * @date 2021/07/27
 */
@Data
public class JobBaseConfigModel implements Serializable {
    private static final long serialVersionUID = -2176025651714090548L;

    private String jobName;
    private Integer reportType;
    private String currentBranch;
    private String originBranch;
    private Double threshold;

}
