package com.maoyan.coverage.admin.domain.constant;

/**
 * @author yimingyu
 * @date 2021/07/22
 */
public class ErrorMessageConstant {
    public static final String USER_NOT_LOGIN = "未获取到用户信息,请先登录";
    public static final String BUSINESS_LINE_ID_ERROR = "业务线Id错误,请确认后重试";
    public static final String JOB_CONFIG_ID_ERROR = "jobId错误,请确认后重试";
    public static final String BUILD_HISTORY_CONFIG_ID_ERROR = "buildHistoryId错误,请确认后重试";
    public static final String PAGE_ERROR_NO_DATA= "没有更多数据了,请检查分页信息";
}
