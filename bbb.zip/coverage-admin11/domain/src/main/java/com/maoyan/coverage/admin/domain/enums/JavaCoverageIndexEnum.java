package com.maoyan.coverage.admin.domain.enums;

import com.google.common.collect.Maps;

import java.util.Map;

/**
 * java 中会使用覆盖率指标
 * @author lizhuoran05
 * @date 2021/8/9
 */
public enum JavaCoverageIndexEnum {

    INCREMENT_LINE("incrementLine", "增量行覆盖率"),
    INCREMENT_BRANCH("incrementBranch", "增量分支覆盖率"),
    INCREMENT_METHOD("incrementMethod","增量方法覆盖率"),
    INCREMENT_INST("incrementInst", "增量指令覆盖率"),
    INCREMENT_CLASS("incrementClass", "增量类覆盖率"),
    // 圈复杂度先不暴露给用户
    INCREMENT_CXTY("incrementCxty","增量圈复杂度"),

    LINE("line", "行覆盖率"),
    BRANCH("branch", "分支覆盖率"),
    METHOD("method", "方法覆盖率"),
    INST("inst", "指令覆盖率"),
    CLASS("class", "类覆盖率"),
    CXTY("cxty", "圈复杂度");

    String type;
    String des;

    JavaCoverageIndexEnum(String type, String des) {
        this.type = type;
        this.des = des;
    }

    public static Map<String, JavaCoverageIndexEnum> typeMap = Maps.newHashMap();

    static {
        for (JavaCoverageIndexEnum value : values()) {
            typeMap.put(value.getType(), value);
        }
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDes() {
        return des;
    }

    public void setDes(String des) {
        this.des = des;
    }
}
