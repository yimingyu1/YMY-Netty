package com.maoyan.coverage.admin.domain.enums;

/**
 * @author lizhuoran05
 * @date 2021/7/29
 */
public enum JobBuildResultEnum {

    UN_KNOWN(0, "未知"),
    SUCCESS(1, "构建成功"),
    FAIL(2, "构建失败");

    int type;
    String des;

    JobBuildResultEnum(int type, String des) {
        this.type = type;
        this.des = des;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getDes() {
        return des;
    }

    public void setDes(String des) {
        this.des = des;
    }

}
