package com.maoyan.coverage.admin.domain.model.job.config;

import com.maoyan.coverage.admin.domain.enums.ProjectTypeEnum;
import lombok.Data;

/**
 * @author lizhuoran05
 * @date 2021/7/29
 */
@Data
public class TestConfigModel {


}
