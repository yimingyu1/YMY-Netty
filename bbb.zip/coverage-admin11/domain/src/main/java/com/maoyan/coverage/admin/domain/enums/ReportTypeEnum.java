package com.maoyan.coverage.admin.domain.enums;

import com.google.common.collect.Maps;

import java.util.Map;

/**
 * @author lizhuoran05
 * @date 2021/8/9
 */
public enum  ReportTypeEnum {
    INCREMENT_REPORT(0, "增量报告"),
    FULL_REPORT(1, "全量报告");

    int type;
    String des;

    ReportTypeEnum(int type, String des) {
        this.type = type;
        this.des = des;
    }

    public static Map<Integer, ReportTypeEnum> typeMap = Maps.newHashMap();

    static {
        for (ReportTypeEnum value : values()) {
            typeMap.put(value.getType(), value);
        }
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getDes() {
        return des;
    }

    public void setDes(String des) {
        this.des = des;
    }
}
