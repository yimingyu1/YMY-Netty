package com.maoyan.coverage.admin.domain.model.job.msg;

import com.maoyan.coverage.admin.domain.enums.JobTimerTypeEnum;
import com.maoyan.coverage.admin.domain.enums.TimerTypeEnum;
import lombok.Data;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * 开启定时构建发送的消息
 *
 * @author lizhuoran05
 * @date 2021/9/14
 */
@Data
public class CycleBuildOpenMsgModel {

    private String jobName;

    /**
     * {@link com.maoyan.coverage.admin.domain.enums.TimerTypeEnum}
     */
    private int timerType;

    /**
     * 定时构建的数值
     */
    private String timerValue;

    /**
     * 操作用户
     */
    private String operatingUser;

    private List<String> projectLeader;

    private LocalDateTime currentTime;

    /**
     * {@link com.maoyan.coverage.admin.domain.enums.JobTimerTypeEnum}
     */
    private int jobTimerType;

    private String projectName;

    public String getMsg() {
        String lineFeed = "\n";

        if (jobTimerType == JobTimerTypeEnum.SERVER_JOB_DUMP_TIMER.getType()) {
            // server dump job
            String info = "【 信息 】: 服务端 Dump 任务已开启" + lineFeed;
            String jobName = "【 job 名称 】: " + getJobName() + lineFeed;
            String projectName = "【 关联项目 】: " + getProjectName() + lineFeed;
            String operatingUser = "【 操作用户 】: " + getOperatingUser() + lineFeed;
            String openTime = "【 开启时间 】: " + getCurrentTime().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")) + lineFeed;
            String timeValue = "【 Dump周期 】: " + getTimerValue() + " 分钟" + lineFeed;
            String projectLeader = "【 通知用户 】: " + getProjectLeader().toString() + lineFeed;
            String remark = "【 备注 】: 服务端 Job 创建时会自动开启";
            // 拼接字符串
            return info.concat(jobName).concat(projectName).concat(operatingUser).concat(openTime).concat(timeValue).concat(projectLeader).concat(remark);
        } else {
            // 普通 job
            String info = "【 信息 】: 开启定时构建" + lineFeed;
            String jobName = "【 job 名称 】: " + getJobName() + lineFeed;
            String projectName = "【 关联项目 】: " + getProjectName() + lineFeed;
            String timeType = "【 定时构建类型 】: " + TimerTypeEnum.typeMap.get(getTimerType()).getDes() + lineFeed;
            String timeValue = "";
            if (getTimerType() == TimerTypeEnum.INTERVAL.getType()) {
                timeValue = "【 构建周期 】: " + getTimerValue() + " 分钟" + lineFeed;
            }
            String operatingUser = "【 操作用户 】: " + getOperatingUser() + lineFeed;
            String openTime = "【 开启时间 】: " + getCurrentTime().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")) + lineFeed;
            String projectLeader = "【 通知用户 】: " + getProjectLeader().toString();

            // 拼接字符串
            return info.concat(jobName).concat(projectName).concat(timeType).concat(timeValue).concat(operatingUser).concat(openTime).concat(projectLeader);
        }
    }
}
