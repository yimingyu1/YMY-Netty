package com.maoyan.coverage.admin.domain.enums;

import com.google.common.collect.Maps;

import java.util.Map;

/**
 * @author yimingyu
 * @date 2021/07/14
 */
public enum ProjectTypeEnum {
    UNKNOWN(0, "未知"),
    PC(1, "PC"),
    I_VERSION(2, "i版"),
    APPLETS(3, "小程序"),
    ANDROID(4, "安卓"),
    IOS(5, "iOS"),
    SERVER(6, "服务端"),
    MRN(7, "MRN");

    private int id;
    private String type;

    public static Map<Integer, ProjectTypeEnum> typeMap = Maps.newHashMap();

    static {
        for (ProjectTypeEnum value : values()) {
            typeMap.put(value.getId(), value);
        }
    }

    public static ProjectTypeEnum getById(int id){
        ProjectTypeEnum[] values = ProjectTypeEnum.values();
        for (ProjectTypeEnum pte: values
             ) {
            if (pte.getId() == id){
                return pte;
            }
        }
        return null;
    }

    private ProjectTypeEnum(int id, String type) {
        this.id = id;
        this.type = type;
    }

    public int getId() {
        return id;
    }

    public String getType() {
        return type;
    }
}
