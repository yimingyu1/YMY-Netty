package com.maoyan.coverage.admin.domain.vo;

import java.util.List;

/**
 * Created by lihongmei03 on 2020-12-07
 */
public class S3ObjectListVO {
    private List<String> objectList;

    public List<String> getObjectList() {
        return objectList;
    }

    public void setObjectList(List<String> objectList) {
        this.objectList = objectList;
    }

}
