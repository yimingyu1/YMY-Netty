package com.maoyan.coverage.admin.domain.constant;

/**
 * @author yimingyu
 * @date 2021/09/07
 */
public class BuildHistoryListVOConstant {
    // 构建中状态 endTime、commit、coveredLines、coveredBranches 默认字符形式
    public static final String defaultStr = "-";
}
