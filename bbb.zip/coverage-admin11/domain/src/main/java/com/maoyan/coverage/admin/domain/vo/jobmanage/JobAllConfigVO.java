package com.maoyan.coverage.admin.domain.vo.jobmanage;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @author yimingyu
 * @date 2021/07/26
 */
@Data
public class JobAllConfigVO implements Serializable {
    private static final long serialVersionUID = 2387791084091455836L;

    private int id;
    private String jobName;
    private int reportType;
    private String currentBranch;
    private String originBranch;
    private double threshold;
    private String testEnv;
    private List<Long> testTime;
    private List<String> deployHost;
    private String commit;
    private List<String> serverIp;
    private List<String> agentPort;
    private int releaseId;
//    private String targetDir;
    private String testVersion;
    private int projectNum;
    private int jobTestType;
    private String jenkinsRef;
    private String jenkinsGitAddress;
    private String jenkinsGitBranch;

}
