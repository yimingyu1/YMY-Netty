package com.maoyan.coverage.admin.domain.model.job;

import com.maoyan.coverage.admin.domain.enums.TimerTypeEnum;
import com.maoyan.coverage.admin.domain.model.jobmanage.JobBaseConfigModel;
import lombok.Data;

/**
 * 交给各业务的参数
 *
 * @author lizhuoran05
 * @date 2021/7/19
 */
@Data
public class JobBuildModel<T> {

    /**
     * 工作区
     */
    private WorkSpacePathModel workSpacePath;

    /**
     * 构建历史
     */
    private int buildHistoryId;

    /**
     * jobId
     */
    private int jobConfigId;

    /**
     * 本次构建的 buildNum
     */
    private int buildNum;

    /**
     * 基础配置
     */
    private JobBaseConfigModel baseConfig;

    /**
     * 项目信息
     */
    private ProjectInfoModel projectInfo;

    /**
     * 构建类型
     */
    private TimerTypeEnum timerType;

    /**
     * 构建数据
     */
    private String timerValue;

    /**
     * 测试配置
     */
    T testConfig;
}
