package com.maoyan.coverage.admin.domain.enums;

/**
 * @author lizhuoran05
 * @date 2021/7/29
 */
public enum JobBuildStatusEnum {

    FREE(0, "空闲"),
    BUILDING(1, "构建中"),
    END(2, "构建结束");

    int type;
    String des;

    JobBuildStatusEnum(int type, String des) {
        this.type = type;
        this.des = des;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getDes() {
        return des;
    }

    public void setDes(String des) {
        this.des = des;
    }

}
