package com.maoyan.coverage.admin.domain.model.job.msg;

import com.maoyan.coverage.admin.domain.enums.JobTimerTypeEnum;
import com.maoyan.coverage.admin.domain.enums.TimerTypeEnum;
import lombok.Data;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * 更新定时构建发送的消息
 *
 * @author lizhuoran05
 * @date 2021/9/14
 */
@Data
public class CycleBuildUpdateMsgModel {

    private String jobName;

    /**
     * {@link com.maoyan.coverage.admin.domain.enums.TimerTypeEnum}
     */
    private int timerType;

    /**
     * 定时构建的数值
     */
    private String timerValue;

    /**
     * 操作用户
     */
    private String operatingUser;

    private List<String> projectLeader;

    private LocalDateTime currentTime;

    /**
     * 之前的 timer 类型
     */
    private int originTimerType;

    /**
     * 之前的定时器数据
     */
    private String originTimerValue;

    private String projectName;

    /**
     * 是 dump job还是普通job
     * {@link com.maoyan.coverage.admin.domain.enums.JobTimerTypeEnum}
     */
    private int jobTimerType;

    public String getMsg() {
        String lineFeed = "\n";
        String info = "";
        String tip = "";

        if (jobTimerType == JobTimerTypeEnum.JOB_BUILD_TIMER.getType()) {
            info = "【 信息 】: 更新定时构建配置" + lineFeed;
            tip = "构建";
        } else if (jobTimerType == JobTimerTypeEnum.SERVER_JOB_DUMP_TIMER.getType()) {
            info = "【 信息 】: 更新 Dump Job 配置" + lineFeed;
            tip = "Dump";
        }

        String jobName = "【 job 名称 】: " + getJobName() + lineFeed;
        String projectName = "【 关联项目 】: " + getProjectName() + lineFeed;
        String originTimerType = "【 旧定时构建类型 】: " + TimerTypeEnum.typeMap.get(getOriginTimerType()).getDes() + lineFeed;
        String timerType = "【 新定时构建类型 】: " + TimerTypeEnum.typeMap.get(getTimerType()).getDes() + lineFeed;
        String originTimerValue = "";
        String timerValue = "";
        if (getTimerType() == TimerTypeEnum.INTERVAL.getType()) {
            originTimerValue = "【 旧" + tip + "周期 】: " + getOriginTimerValue() + " 分钟" + lineFeed;
            timerValue = "【 新" + tip + "周期 】: " + getTimerValue() + " 分钟" + lineFeed;
        }
        String operatingUser = "【 操作用户 】: " + getOperatingUser() + lineFeed;
        String updateTime = "【 更新时间 】: " + getCurrentTime().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")) + lineFeed;
        String projectLeader = "【 通知用户 】: " + getProjectLeader().toString() + lineFeed;

        // 拼接字符串
        return info.concat(jobName).concat(projectName).concat(originTimerType).concat(originTimerValue).concat(timerType).concat(timerValue).concat(operatingUser).concat(updateTime).concat(projectLeader);
    }
}
