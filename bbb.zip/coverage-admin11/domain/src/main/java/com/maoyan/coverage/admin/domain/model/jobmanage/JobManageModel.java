package com.maoyan.coverage.admin.domain.model.jobmanage;

import com.alibaba.fastjson.JSONObject;
import com.maoyan.coverage.admin.domain.enums.JobTestTypeEnum;
import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * @author yimingyu
 * @date 2021/07/29
 */
@Data
public class JobManageModel implements Serializable {

    private static final long serialVersionUID = 6259377287477546624L;
    private Integer id;
    private Integer projectConfigId;
    private Integer jobType;
    private String jobName;
    private JobBaseConfigModel jobBaseConfig;
    private String jobTestConfig;
    private Integer deleted;
    private String creator;
    private String updater;
    private LocalDateTime createTime;
    private LocalDateTime updateTime;
    /**
     * {@link JobTestTypeEnum}
     */
    private Integer jobTestType;
    private JobAutoTestConfigModel jobAutoTestConfig;



}
