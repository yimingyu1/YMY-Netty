package com.maoyan.coverage.admin.domain.param.projectmanage;

import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;

/**
 * @author yimingyu
 * @date 2021/07/29
 */
@Data
public class ProjectParam implements Serializable {
    private static final long serialVersionUID = 4535791503378644886L;

    private int id;
    private int businessLineId;
    private String projectName;
    private String gitAddress;
    private int projectType;
    private List<String> projectLeader;
}
