package com.maoyan.coverage.admin.domain.vo.jobmanage;

import lombok.Data;

/**
 * @author yimingyu
 * @date 2021/09/02
 */
@Data
public class IOSJobDetailHeaderVO extends JobDetailHeaderVO{
    private String testVersion;
    private int buildNum;
}
