package com.maoyan.coverage.admin.domain.model.job.s3;

import lombok.Data;

import java.time.LocalDateTime;


/**
 * 安卓端文件搜索对象
 *
 * 安卓端文件存放路径
 * android/coverage_data/{projectNaem}/{testVersion}/{buildNum}/src/{XXX}.zip
 * android/coverage_data/{projectNaem}/{testVersion}/{buildNum}/class/{XXX}.zip
 * android/coverage_data/{projectNaem}/{testVersion}/{buildNum}/ec/{XXX}.ec
 *
 * 安卓端 ec 文件以时间戳命名
 *
 * @author lizhuoran05
 * @date 2021/8/6
 */
@Data
public class SearchAndroidFileModel {

    /**
     * 猫眼的安卓包名固定
     */
    private final String maoyanAndroidProjectName = "com.sankuai.movie";

    /**
     * 测试版本
     */
    private String testVersion;

    /**
     * 打包平台的构建号
     */
    private String buildNum;

    /**
     * 安卓端fileType
     * src: 该路径下存放源码.zip
     * class: 该路径下存放class.zip
     * ec: 该路径下存放很多.ec
     */
    private String fileType;

    private LocalDateTime testStartTime;

    private LocalDateTime testEndTime;

    public SearchAndroidFileModel(Builder builder) {
        this.testVersion = builder.testVersion;
        this.buildNum = builder.buildNum;
        this.fileType = builder.fileType;
        this.testStartTime = builder.testStartTime;
        this.testEndTime = builder.testEndTime;
    }

    public static class Builder {

        private String testVersion;

        private String buildNum;

        private String fileType;

        private LocalDateTime testStartTime;

        private LocalDateTime testEndTime;

        public Builder addTestVersion(String testVersion) {
            this.testVersion = testVersion;
            return this;
        }

        public Builder addBuildNum(String buildNum) {
            this.buildNum = buildNum;
            return this;
        }

        public Builder addFileType(String fileType) {
            this.fileType = fileType;
            return this;
        }

        public Builder addTestTime(LocalDateTime testStartTime, LocalDateTime testEndTime) {
            this.testStartTime = testStartTime;
            this.testEndTime = testEndTime;
            return this;
        }

        public SearchAndroidFileModel build() {
            return new SearchAndroidFileModel(this);
        }
    }
}
