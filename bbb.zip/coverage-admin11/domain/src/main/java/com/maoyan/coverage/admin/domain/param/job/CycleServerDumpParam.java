package com.maoyan.coverage.admin.domain.param.job;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author lizhuoran05
 * @date 2021/9/24
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class CycleServerDumpParam extends BuildParam{

    /**
     * server dump 修改只支持时间间隔的
     */
    private String timerValue;

    public static CycleServerDumpParam build(int jobId) {
        String serverJobDumpInterval = "10";
        CycleServerDumpParam cycleServerDumpParam = new CycleServerDumpParam();
        cycleServerDumpParam.setJobId(jobId);
        cycleServerDumpParam.setTimerValue(serverJobDumpInterval);
        return cycleServerDumpParam;
    }
}
