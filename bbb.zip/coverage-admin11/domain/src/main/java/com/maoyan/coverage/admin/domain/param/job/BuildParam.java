package com.maoyan.coverage.admin.domain.param.job;

import lombok.Data;

/**
 * @author lizhuoran05
 * @date 2021/7/19
 */
@Data
public class BuildParam {

    private int jobId;

}
