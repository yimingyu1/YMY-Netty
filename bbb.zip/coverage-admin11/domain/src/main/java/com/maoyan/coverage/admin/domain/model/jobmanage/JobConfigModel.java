package com.maoyan.coverage.admin.domain.model.jobmanage;

import com.maoyan.coverage.admin.domain.enums.ProjectTypeEnum;
import lombok.Data;

import java.time.LocalDateTime;

/**
 * @author yimingyu
 * @date 2021/07/27
 */
@Data
public class JobConfigModel {

    private int projectConfigId;

    private ProjectTypeEnum type;

    private String jobName;

    private String basicConfig;

    private String testConfig;
}
