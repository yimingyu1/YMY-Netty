package com.maoyan.coverage.admin.domain.constant;

/**
 * @author yimingyu
 * @date 2021/09/01
 */
public class GitBranchConstant {
    public static final String PROJECT_PATH = System.getProperty("user.dir");
    public static final String GIT_BRANCH_PATH = "/common/src/main/java/com/maoyan/coverage/admin/common/shell/git_branch.sh";
    public static final String GIT_COMPONENT_PATH =  "/tmp/gitBranch/repositories/";
    public static final String BRANCH_FILE_PATH = "/tmp/gitBranch/branchFiles/";
    public static final String SUFFIX = ".txt";
}
