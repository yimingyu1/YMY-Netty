package com.maoyan.coverage.admin.domain.model;

import lombok.Data;

/**
 * @author lizhuoran05
 * @date 2021/7/20
 */
@Data
public class JobTimerModel {

    private int jobConfigId;

    /**
     * 定时器类型：0：理解构建 1时间间隔；2cron表达式   也可以区分构建类型 0立即构建 非0定时构建
     */
    private int timerType;

    /**
     * 定时器的值
     */
    private String timerValue;

    /**
     * 构建是否关闭  1：已关闭 2：未关闭
     */
    private int closed;

    /**
     * {@link com.maoyan.coverage.admin.domain.enums.JobTimerTypeEnum}
     * 定时器类型 1：Job定时器 2：server Dump 定时器
     */
    private int type;
}
