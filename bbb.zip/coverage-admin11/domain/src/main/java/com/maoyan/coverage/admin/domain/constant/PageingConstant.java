package com.maoyan.coverage.admin.domain.constant;

/**
 * @author yimingyu
 * @date 2021/07/21
 */
public class PageingConstant {
    public static final int MAX_LIMIT = 200;
}
