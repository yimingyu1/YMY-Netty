package com.maoyan.coverage.admin.domain.enums;

/**
 * @author yimingyu
 * @date 2021/08/02
 */
public enum CoveredRateColorEnum {
    // 绿色
    SUPRA_COVERED_RATE_COLOR("#52c41a"),
    // 红色
    LOW_COVERED_RATE_COLOR("#f5222d"),
    // 构建中状态，rate color
    BUILDING_RATE_COLOR("#262626");

    private String coveredRateColor;

    CoveredRateColorEnum(String coveredRateColor){
        this.coveredRateColor = coveredRateColor;
    }

    public String getCoveredRateColor() {
        return coveredRateColor;
    }
}
