package com.maoyan.coverage.admin.domain.vo.jobmanage;

import lombok.Data;

import java.io.Serializable;

/**
 * @author yimingyu
 * @date 2021/07/27
 */
@Data
public class JobConfigListVO implements Serializable {
    private static final long serialVersionUID = 7039774681479876011L;

    private int id;
    private int jobId;
    private String jobName;
    // 报告类型
    private String reportType;
    private String testEnv;
    private String currentBranch;
    // 最新的构建结果
    private int newestBuildResult;
    private String newestCoveredLines;
    private String newestCoveredBranches;
    private String jenkinsRef;
    private int jobType;


}
