package com.maoyan.coverage.admin.domain.model.buildhistory;

import com.maoyan.coverage.admin.domain.model.jobmanage.JobBaseConfigModel;
import com.maoyan.coverage.admin.domain.model.jobmanage.JobManageModel;
import lombok.Data;

import java.io.Serializable;

/**
 * @author yimingyu
 * @date 2021/07/30
 */
@Data
public class BuildHistoryChartModel implements Serializable {
    private static final long serialVersionUID = -6084338418967438780L;

    private Integer id;
    private Integer jobId;
    private Integer buildNum;
    private Integer linesCovered;
    private Integer lineNum;
    private Integer branchesCovered;
    private Integer branches;
    // '构建状态 0:空闲 1：构建中 2: 构建结束'
    private Integer buildStatus;
    // 'build结果 0：未知 1：成功 2：失败'
    private Integer buildResult;
    private JobManageModel jobManageModel;
}
