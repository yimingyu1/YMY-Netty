package com.maoyan.coverage.admin.domain.model.job.config;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.time.LocalDateTime;
import java.util.Date;

/**
 * 安卓端测试配置
 * @author lizhuoran05
 * @date 2021/7/29
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class AndroidTestConfigModel extends TestConfigModel{

    private String testVersion;

    private int buildNum;

    private LocalDateTime testStartTime;

    private LocalDateTime testEndTime;
}
