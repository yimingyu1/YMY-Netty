package com.maoyan.coverage.admin.domain.vo.jobmanage;

import lombok.Data;

/**
 * @author lizhuoran05
 * @date 2021/9/14
 */
@Data
public class JobTimerVO {
    private Integer jobId;

    /**
     * 定时器类型
     * 1：周期构建，单位分钟
     * 2：cron
     */
    private Integer timerType;

    private String timerValue;
}
