package com.maoyan.coverage.admin.domain.model.job.s3;

import lombok.Data;

import java.time.LocalDateTime;
import java.util.Set;

/**
 * 服务端文件搜索对象
 * <p>
 * 服务端exec文件存储路径
 * <p>
 * server/coverage_data/{项目名称}/{分支}/commit-ip-上传时间.exec
 *
 * @author lizhuoran05
 * @date 2021/8/4
 */
@Data
public class SearchServerFileModel {

    /**
     * 测试环境
     * 确定从S3的哪个环境查数据
     */
    private String testEnv;

    /**
     * 代码仓库名字，与项目名字(projectName)区分开
     * 可以通过 gitUrl 截取出来
     */
    private String repositoryName;

    /**
     * 分支
     */
    private String branch;

    /**
     * 服务器ip集合
     */
    private Set<String> ipSet;

    /**
     * 测试开始时间
     */
    private LocalDateTime testStartTime;

    /**
     * 测试结束时间
     */
    private LocalDateTime testEndTime;

    public SearchServerFileModel(Builder builder) {
        this.branch = builder.branch;
        this.ipSet = builder.ipSet;
        this.repositoryName = builder.repositoryName;
        this.testEndTime = builder.testEndTime;
        this.testStartTime = builder.testStartTime;
        this.testEnv = builder.testEnv;
    }

    public static class Builder {

        private String branch;

        private String repositoryName;

        private String testEnv;

        private LocalDateTime testStartTime;

        private LocalDateTime testEndTime;

        private Set<String> ipSet;

        public Builder addBranch(String branch) {
            this.branch = branch;
            return this;
        }

        public Builder addRepositoryName(String repositoryName) {
            this.repositoryName = repositoryName;
            return this;
        }

        public Builder addTestEnv(String testEnv) {
            this.testEnv = testEnv;
            return this;
        }

        public Builder addTestStartTime(LocalDateTime testStartTime) {
            this.testStartTime = testStartTime;
            return this;
        }

        public Builder addTestEndTime(LocalDateTime testEndTime) {
            this.testEndTime = testEndTime;
            return this;
        }

        public Builder addIp(Set<String> ipSet) {
            this.ipSet = ipSet;
            return this;
        }

        public SearchServerFileModel build() {
            return new SearchServerFileModel(this);
        }
    }
}
