package com.maoyan.coverage.admin.domain.model.jobmanage;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @author yimingyu
 * @date 2021/07/27
 * PC/i版共用此DO
 */
@Data
public class JobTestConfig2WebModel implements Serializable {
    private static final long serialVersionUID = -168985585915285489L;

    private String testEnv;
    private List<String> testTime;
    private List<String> deployHost;

}
