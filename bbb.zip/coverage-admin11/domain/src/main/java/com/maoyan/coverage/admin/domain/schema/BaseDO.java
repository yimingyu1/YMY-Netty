package com.maoyan.coverage.admin.domain.schema;

import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Date;

/**
 * @author lizhuoran05
 * @date 2021/7/19
 */
@Data
public class BaseDO implements Serializable {

    private static final long serialVersionUID = 1L;

    // id
    private Integer id;

    // 创建时间
    private LocalDateTime createTime;

    // 更新时间
    private LocalDateTime updateTime;
}
