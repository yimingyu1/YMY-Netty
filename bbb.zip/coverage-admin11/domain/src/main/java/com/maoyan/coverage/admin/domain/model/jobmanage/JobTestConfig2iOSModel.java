package com.maoyan.coverage.admin.domain.model.jobmanage;

import lombok.Data;

import java.io.Serializable;

/**
 * @author yimingyu
 * @date 2021/07/27
 */
@Data
public class JobTestConfig2iOSModel implements Serializable {
    private static final long serialVersionUID = -3482734022107473165L;

    private String testVersion;
    private Integer projectVersion;

}
