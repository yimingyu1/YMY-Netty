package com.maoyan.coverage.admin.domain.model.jobmanage;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @author yimingyu
 * @date 2021/07/29
 */
@Data
public class JobTestConfig2MRNModel implements Serializable {

    private static final long serialVersionUID = -97318136168162156L;

    private String releaseEnv;
    private List<String> testTime;

}
