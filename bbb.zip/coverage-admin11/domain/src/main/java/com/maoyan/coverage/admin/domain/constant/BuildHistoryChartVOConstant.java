package com.maoyan.coverage.admin.domain.constant;

/**
 * @author yimingyu
 * @date 2021/09/09
 */
public class BuildHistoryChartVOConstant {

    public static final String PREFIX = "build_";
}
