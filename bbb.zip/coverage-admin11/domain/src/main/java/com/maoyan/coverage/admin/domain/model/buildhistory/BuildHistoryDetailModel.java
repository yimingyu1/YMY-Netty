package com.maoyan.coverage.admin.domain.model.buildhistory;

import com.maoyan.coverage.admin.domain.model.data.DataIndicatorsModel;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @author yimingyu
 * @date 2021/07/30
 */
@Data
public class BuildHistoryDetailModel implements Serializable {
    private static final long serialVersionUID = 14343350346096814L;

    private int buildId;
    private List<DataIndicatorsModel> dataIndicatorsModels;
    private String reportDetailUrl;
}
