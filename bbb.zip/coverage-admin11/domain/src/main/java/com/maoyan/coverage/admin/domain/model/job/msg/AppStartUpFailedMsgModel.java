package com.maoyan.coverage.admin.domain.model.job.msg;

import com.maoyan.coverage.admin.domain.enums.JobTimerTypeEnum;
import lombok.Data;

import java.util.List;

/**
 * @author lizhuoran05
 * @date 2021/9/26
 */
@Data
public class AppStartUpFailedMsgModel {

    private String error;

    private String remark;

    private List<String> projectLeader;

    /**
     * jobId: 如果是 job 导致失败的话
     */
    private int jobId;

    /**
     * {@link com.maoyan.coverage.admin.domain.enums.JobTimerTypeEnum}
     */
    private int jobTimerType;

    public String getMsg() {
        String lineFeed = "\n";
        String info = "【 信息 】: 项目启动时遇到问题，请尽快处理" + lineFeed;
        String error = "【 错误信息 】: " + getError() + lineFeed;
        String projectLeader = "【 通知用户 】: " + getProjectLeader().toString() + lineFeed;
        String remark = "【 类型 】: " + getRemark() + lineFeed;
        String jobInfo = "";
        if (jobTimerType != 0 && jobId != 0) {
            jobInfo = "【 job信息】: jobId: " + getJobId() + "  job类型: " + JobTimerTypeEnum.typeMap.get(getJobTimerType()).getDes() + lineFeed;
        }

        return info.concat(remark).concat(error).concat(jobInfo).concat(projectLeader);
    }

}
