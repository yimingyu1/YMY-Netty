package com.maoyan.coverage.admin.domain.model.job.result;

import com.maoyan.coverage.admin.domain.enums.S3EnvEnum;
import com.maoyan.coverage.admin.domain.enums.TestEnvEnum;
import org.jacoco.core.analysis.IBundleCoverage;
import lombok.Data;

/**
 * Job 构建结果对象
 * 适用于 安卓、服务端
 *
 * @author lizhuoran05
 * @date 2021/8/10
 */
@Data
public class JobJavaBuildResultModel {

    public void setS3Env(String s3Env) {
        this.s3Env = s3Env;
    }

    public void setS3Env(TestEnvEnum testEnvEnum) {
        if (testEnvEnum.equals(TestEnvEnum.STAGING)) {
            this.s3Env = S3EnvEnum.PROD.getEnv();
        } else if (testEnvEnum.equals(TestEnvEnum.TEST)) {
            this.s3Env = S3EnvEnum.TEST.getEnv();
        }
    }



    /**
     * 生成报告使用到的 commit
     */
    String commit;

    /**
     * 测试报告要保存到哪个 S3 的环境
     * 当 TestEnv 是 staging 时，s3Env 应该使用 prod
     * 当 TestEnv 是 test 时，s3Env 应该使用 test
     *
     * 安卓端使用 "prod"
     * 服务端根据 TestEnv 设置
     */
    String s3Env;


}
