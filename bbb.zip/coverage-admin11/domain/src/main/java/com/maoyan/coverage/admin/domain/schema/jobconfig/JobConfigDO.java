package com.maoyan.coverage.admin.domain.schema.jobconfig;

import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * @author yimingyu
 * @date 2021/07/27
 */
@Data
public class JobConfigDO implements Serializable {

    private static final long serialVersionUID = -6621619393050492879L;

    private Integer id;
    private Integer projectConfigId;
    private Integer type;
    private String jobName;
    private String jobBaseConfig;
    private String jobTestConfig;
    private Integer deleted;
    private String creator;
    private String updater;
    private LocalDateTime createTime;
    private LocalDateTime updateTime;
    private Integer jobType;
    private String jobAutoTestConfig;

}
