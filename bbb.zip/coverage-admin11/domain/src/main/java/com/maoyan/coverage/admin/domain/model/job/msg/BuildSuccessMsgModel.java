package com.maoyan.coverage.admin.domain.model.job.msg;

import com.maoyan.coverage.admin.domain.enums.TimerTypeEnum;
import lombok.Data;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * @author lizhuoran05
 * @date 2021/9/14
 */
@Data
public class BuildSuccessMsgModel {

    private String jobName;

    /**
     * 前端报告详情页
     */
    private String reportDetailUrl;

    /**
     * 构建历史页面
     */
    private String buildHistoryUrl;

    /**
     * 通知用户
     */
    private List<String> projectLeader;

    /**
     * 通知时间
     */
    private LocalDateTime currentTime;

    /**
     * 关联项目
     */
    private String projectName;

    /**
     * 触发方式
     * {@link TimerTypeEnum}
     */
    private int timerType;

    private String timerValue;

    /**
     * 操作用户：立即构建时才有
     */
    private String operatingUser;

    public String getMsg() {
        String lineFeed = "\n";
        String info = "【 信息 】: Job构建成功" + lineFeed;
        String jobName = "【 job 名称 】: " + getJobName() + lineFeed;
        String projectName = "【 关联项目 】: " + getProjectName() + lineFeed;
//        后续开放，目前只关注构建结果即可
//        String timeType = "【 构建类型 】: " + TimerTypeEnum.typeMap.get(getTimerType()).getDes() + lineFeed;
//        String timeValue = "";
//        String operatingUser = "";

//        if (getTimerType() == TimerTypeEnum.INTERVAL.getType()) {
//            timeValue = "【 构建周期 】: " + getTimerValue() + " 分钟" + lineFeed;
//        } else if (getTimerType() == TimerTypeEnum.IMMEDIATE.getType()) {
//            operatingUser = "【 操作用户 】: " + getOperatingUser() + lineFeed;
//        }

        String notifyTime = "【 通知时间 】: " + getCurrentTime().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")) + lineFeed;
        String projectLeader = "【 通知用户 】: " + getProjectLeader().toString() + lineFeed;
        String reportDetailUrl = "【 构建结果 】: " + "[点击查看|" + getReportDetailUrl() + "]" + lineFeed;
        String buildHistoryUrl = "【 构建历史 】: " + "[点击查看|" + getBuildHistoryUrl() + "]" + lineFeed;

        // 拼接字符串
        return info.concat(jobName).concat(projectName).concat(reportDetailUrl).concat(buildHistoryUrl).concat(notifyTime).concat(projectLeader);
    }
}
