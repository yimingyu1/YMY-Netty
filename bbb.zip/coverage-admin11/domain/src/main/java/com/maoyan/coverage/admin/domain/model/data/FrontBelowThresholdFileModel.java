package com.maoyan.coverage.admin.domain.model.data;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 低于阈值的文件对象
 * @author lizhuoran05
 * @date 2021/7/26
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class FrontBelowThresholdFileModel extends BelowThresholdFileModel{

    /**
     * 相对路径
     */
   private String path;

}
