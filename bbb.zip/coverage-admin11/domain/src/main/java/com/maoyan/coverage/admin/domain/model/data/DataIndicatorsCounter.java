package com.maoyan.coverage.admin.domain.model.data;

import lombok.Data;

/**
 * 数据指标计数器
 * @author lizhuoran05
 * @date 2021/7/26
 */
@Data
public class DataIndicatorsCounter {

    /**
     * 覆盖了多少
     */
    private int covered;

    /**
     * 总数是多少
     */
    private int total;

    public DataIndicatorsCounter(int covered, int total) {
        this.covered = covered;
        this.total = total;
    }

    public DataIndicatorsCounter() {
    }
}
