package com.maoyan.coverage.admin.domain.enums;

public enum S3EnvEnum {
    PROD("prod","s3 prod环境"),
    TEST("test","s3 test环境");

    private String env;

    public String getEnv() {
        return env;
    }

    public void setEnv(String env) {
        this.env = env;
    }

    public String getDec() {
        return dec;
    }

    public void setDec(String dec) {
        this.dec = dec;
    }

    private String dec;

    private S3EnvEnum(String env, String dec) {
        this.env = env;
        this.dec = dec;
    }
}
