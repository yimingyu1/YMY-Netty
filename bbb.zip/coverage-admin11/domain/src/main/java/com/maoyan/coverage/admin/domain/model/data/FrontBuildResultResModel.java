package com.maoyan.coverage.admin.domain.model.data;

import lombok.Data;

/**
 * 前端 Node 服务的响应对象
 *
 * @author lizhuoran05
 * @date 2021/8/17
 */
@Data
public class FrontBuildResultResModel {

    private String success;

    private Integer code;

    private String errMsg;

    private FrontBuildResultDataModel data;
}
