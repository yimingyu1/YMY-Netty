package com.maoyan.coverage.admin.domain.model.job.s3;

import lombok.Data;

/**
 * ios 文件存放路径
 * ios/coverage_data/
 *
 * @author lizhuoran05
 * @date 2021/8/6
 */
@Data
public class SearchIOSFileModel {

    /**
     * 猫眼的iOS包名固定
     */
    private String maoyanIOSProjectName = "movie";

    /**
     * 测试版本
     */
    private String testVersion;

    /**
     * 项目版本
     */
    private Integer projectVersion;

    /**
     * gcda 或者 gcno
     */
    private String fileType;

    public SearchIOSFileModel(Builder builder) {
        this.testVersion = builder.testVersion;
        this.projectVersion = builder.projectVersion;
        this.fileType = builder.fileType;
    }

    public static class Builder {

        private String testVersion;

        private Integer projectVersion;

        private String fileType;

        public Builder addTestVersion(String testVersion) {
            this.testVersion = testVersion;
            return this;
        }


        public Builder addProjectVersion(Integer projectVersion) {
            this.projectVersion = projectVersion;
            return this;
        }

        public Builder addFileType(String fileType) {
            this.fileType = fileType;
            return this;
        }

        public SearchIOSFileModel build() {
            return new SearchIOSFileModel(this);
        }
    }

}
