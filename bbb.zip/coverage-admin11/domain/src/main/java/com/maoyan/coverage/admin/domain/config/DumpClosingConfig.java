package com.maoyan.coverage.admin.domain.config;

import com.meituan.service.mobile.service.movieconfig.model.ConfigBase;

public class DumpClosingConfig extends ConfigBase {

    private int startDumpClosingTime;
    private int closeDumpClosingTime;


    public int getStartDumpClosingTime() {
        return startDumpClosingTime;
    }
    public void setStartDumpClosingTime(int startDumpClosingTime) {
        this.startDumpClosingTime = startDumpClosingTime;
    }

    public int getCloseDumpClosingTime() {
        return closeDumpClosingTime;
    }

    public void setCloseDumpClosingTime(int closeDumpClosingTime) {
        this.closeDumpClosingTime = closeDumpClosingTime;
    }



}
