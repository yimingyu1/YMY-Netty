package com.maoyan.coverage.admin.domain.model;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
public class Paging implements Serializable {

    /**
     * 起始页
     */
    private int offset;
    /**
     * 每页的总数
     */
    private int limit;
    /**
     * 总个数
     */
    private int total;
    /**
     * 是否还有更多数据
     */
    private boolean hasMore;

}
