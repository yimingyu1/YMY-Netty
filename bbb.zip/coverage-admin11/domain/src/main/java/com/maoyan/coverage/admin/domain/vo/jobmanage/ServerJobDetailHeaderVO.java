package com.maoyan.coverage.admin.domain.vo.jobmanage;

import lombok.Data;

import java.util.List;

/**
 * @author yimingyu
 * @date 2021/09/02
 */
@Data
public class ServerJobDetailHeaderVO extends JobDetailHeaderVO{
    private List<String> serverIp;
    private List<String> agentPort;
    private String testEnv;
    private int releaseId;
    private List<String> testTime;
    private int jobTestType;
    private String jenkinsRef;
    private String jenkinsGitAddress;
}
