package com.maoyan.coverage.admin.domain.model.job;

import com.maoyan.coverage.admin.domain.enums.ProjectTypeEnum;
import lombok.Data;

import java.util.List;

/**
 * @author lizhuoran05
 * @date 2021/7/30
 */
@Data
public class ProjectInfoModel {

    /**
     * git 仓库地址
     * 拉代码使用
     */
    private String gitAddress;

    /**
     * 仓库名称
     */
    private String repositoryName;

    /**
     * 项目负责人
     * 构建完成或者报错的时候使用
     */
    private List<String> projectLeader;

    /**
     * 项目类型
     */
    private ProjectTypeEnum projectType;
}
