package com.maoyan.coverage.admin.domain.model.job.s3;

import lombok.Data;

/**
 * @author lizhuoran05
 * @date 2021/9/15
 */
@Data
public class EcFileNameModel {

    private String objectUrl;

    private long uploadTime;

    public EcFileNameModel(String objectUrl, long uploadTime) {
        this.objectUrl = objectUrl;
        this.uploadTime = uploadTime;
    }

    public static EcFileNameModel format(String objectUrl) {
        String[] pathArray = objectUrl.split("/");
        String ecFile = pathArray[pathArray.length - 1];
        String[] uploadTimeAndSuffix = ecFile.split("\\.");
        long uploadTime = Long.parseLong(uploadTimeAndSuffix[0]);

        return new EcFileNameModel(objectUrl, uploadTime);
    }
}
