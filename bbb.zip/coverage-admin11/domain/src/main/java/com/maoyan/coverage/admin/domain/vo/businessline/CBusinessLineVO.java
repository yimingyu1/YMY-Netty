package com.maoyan.coverage.admin.domain.vo.businessline;

import lombok.Data;

import java.io.Serializable;

/**
 * @author yimingyu
 * @date 2021/10/27
 * 给chaoyue平台提供的VO
 */
@Data
public class CBusinessLineVO implements Serializable {
    private static final long serialVersionUID = -8977964711371209188L;

    private int id;
    private String businessLineName;
}
