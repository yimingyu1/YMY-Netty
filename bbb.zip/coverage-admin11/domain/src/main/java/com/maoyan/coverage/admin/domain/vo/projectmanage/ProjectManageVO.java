package com.maoyan.coverage.admin.domain.vo.projectmanage;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @author yimingyu
 * @date 2021/07/14
 */
@Data
public class ProjectManageVO implements Serializable {

    private static final long serialVersionUID = -6935513270870174356L;
    private int id;
    private String projectName;
    private Integer projectType;
    private String projectCreator;
    private String gitAddress;
    private List<String> projectLeader;


}
