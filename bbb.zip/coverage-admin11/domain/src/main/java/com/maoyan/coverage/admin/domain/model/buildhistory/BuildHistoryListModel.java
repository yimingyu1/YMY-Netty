package com.maoyan.coverage.admin.domain.model.buildhistory;

import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * @author yimingyu
 * @date 2021/07/30
 */
@Data
public class BuildHistoryListModel implements Serializable {
    private static final long serialVersionUID = 3187370216651638353L;

    private Integer id;
    private Integer buildNum;
    /**
     * '构建类型  0：未知 1：手动 2：定时'
     */
    private Integer buildType;
    /**
     * 构建人
     */
    private String builder;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private String commit;
    private Integer linesCovered;
    private Integer lineNum;
    private Integer branchesCovered;
    private Integer branches;
    /**
     * 构建状态 0:空闲 1：构建中 2: 构建结束'
     */
    private Integer buildStatus;
    /**
     * build结果 0：未知 1：成功 2：失败'
     */
    private Integer buildResult;
    private Integer jenkinsBuildNum;
}
