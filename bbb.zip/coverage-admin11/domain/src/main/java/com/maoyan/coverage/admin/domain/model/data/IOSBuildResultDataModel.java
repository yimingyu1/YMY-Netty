package com.maoyan.coverage.admin.domain.model.data;

import lombok.Data;

import java.util.ArrayList;

/**
 * @author lizhuoran05
 * @date 2021/8/18
 */
@Data
public class IOSBuildResultDataModel {

    /**
     * 上传到S3后报告首页地址
     */
    private String reportUrl;

    /**
     * 生成报告使用的 commit
     */
    private String commit;

    /**
     * 指标对象
     */
    private ArrayList<DataIndicatorsModel> dataIndicators;

}
