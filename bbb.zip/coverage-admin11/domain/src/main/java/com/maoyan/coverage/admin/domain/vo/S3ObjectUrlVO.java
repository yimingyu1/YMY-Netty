package com.maoyan.coverage.admin.domain.vo;

/**
 * Created by lihongmei03 on 2020-12-07
 */
public class S3ObjectUrlVO {
    private String objectUrl;

    public String getObjectUrl() {
        return objectUrl;
    }

    public void setObjectUrl(String objectUrl) {
        this.objectUrl = objectUrl;
    }

}
