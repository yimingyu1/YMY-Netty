package com.maoyan.coverage.admin.domain.enums;

public enum MTConfigKeyEnum {

    dumpClosingConfig("dumpClosingConfig", "控制dump上传s3的时间"),;

    private String key;
    private String desc;

    MTConfigKeyEnum(String key, String desc) {
        this.key = key;
        this.desc = desc;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }
}
