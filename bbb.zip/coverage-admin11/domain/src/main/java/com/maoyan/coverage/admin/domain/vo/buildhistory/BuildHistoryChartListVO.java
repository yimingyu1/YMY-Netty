package com.maoyan.coverage.admin.domain.vo.buildhistory;

import lombok.Data;

import java.io.Serializable;

/**
 * @author yimingyu
 * @date 2021/07/30
 */
@Data
public class BuildHistoryChartListVO implements Serializable {
    private static final long serialVersionUID = -3187255353684974501L;

    private Integer id;
    private Integer buildNum;
    private String buildNumStr;
    // 'build结果 0：未知 1：成功 2：失败'
    private Integer buildResult;
    private Integer coveredLinesRate;
    private Integer coveredBranches;
    private BuildConfigDiffInfoVO diffDesc;
}
