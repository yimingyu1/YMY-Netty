package com.maoyan.coverage.admin.domain.vo.buildhistory;

import lombok.Data;

import java.io.Serializable;

/**
 * @author yimingyu
 * @date 2021/07/30
 */
@Data
public class BuildConfigDiffInfoVO implements Serializable {
    private static final long serialVersionUID = 6607126962478749598L;

    private String jobName;
    private String testTime;
    private String deployHost;
    private String serverIp;
    private String agentPort;

}
