package com.maoyan.coverage.admin.domain.enums;

import com.google.common.collect.Maps;

import java.util.Map;

/**
 * @author lizhuoran05
 * @date 2021/9/13
 */
public enum JobTimerTypeEnum {

    JOB_BUILD_TIMER(1, "Job构建定时器"),
    SERVER_JOB_DUMP_TIMER(2, "服务端 dump Job定时器");

    int type;
    String des;

    public static Map<Integer, JobTimerTypeEnum> typeMap = Maps.newHashMap();

    static {
        for (JobTimerTypeEnum value : values()) {
            typeMap.put(value.getType(), value);
        }
    }

    JobTimerTypeEnum(int type, String des) {
        this.type = type;
        this.des = des;
    }


    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getDes() {
        return des;
    }

    public void setDes(String des) {
        this.des = des;
    }

}
