package com.maoyan.coverage.admin.domain.model.projectmanage;

import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.collections.CollectionUtils;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;

/**
 * @author yimingyu
 * @date 2021/07/22
 */
@Data
public class ProjectManageModel implements Serializable {
    private static final long serialVersionUID = 3354046898935839648L;

    private Integer id;
    private Integer projectId;
    private Integer businessLineId;
    private String projectName;
    private String gitAddress;
    private Integer projectType;
    private List<String> projectLeader;
    private String creator;
    private String updater;
    /**
     * 0:未删除  1:已删除
     */
    private Integer deleted;
    private LocalDateTime createTime;
    private LocalDateTime updateTime;





}
