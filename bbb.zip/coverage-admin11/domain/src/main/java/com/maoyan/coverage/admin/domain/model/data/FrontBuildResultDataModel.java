package com.maoyan.coverage.admin.domain.model.data;

import com.maoyan.coverage.admin.domain.enums.ReportTypeEnum;
import lombok.Data;

import java.util.ArrayList;

/**
 * 前端 Node 服务的响应对象
 *
 * @author lizhuoran05
 * @date 2021/8/17
 */
@Data
public class FrontBuildResultDataModel {

    /**
     * 项目名称(其实是仓库名称)
     */
    private String projectName;

    /**
     * 上传到S3后报告首页地址
     */
    private String reportUrl;

    /**
     * 生成报告使用的 commit
     */
    private String commit;

    /**
     * 指标对象
     */
    private ArrayList<DataIndicatorsModel> dataIndicators;

    private ReportTypeEnum reportType;
}
