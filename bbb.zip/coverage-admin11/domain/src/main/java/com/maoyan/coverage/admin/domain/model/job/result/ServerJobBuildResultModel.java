package com.maoyan.coverage.admin.domain.model.job.result;


import com.maoyan.coverage.jacocoplus.core.analysis.IBundleCoverage;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author lizhuoran05
 * @date 2021/9/5
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class ServerJobBuildResultModel extends JobJavaBuildResultModel{

    /**
     * 项目覆盖率结果
     */
    IBundleCoverage coverageResult;
}
