package com.maoyan.coverage.admin.domain.model.jobmanage;

import com.maoyan.coverage.admin.domain.enums.ProjectTypeEnum;
import lombok.Data;

/**
 * 详情类
 * @author lizhuoran05
 * @date 2021/07/29
 */
@Data
public class JobDetailConfigModel<T> {

    private int projectConfigId;

    private ProjectTypeEnum type;

    private String jobName;

    private JobBaseConfigModel basicConfig;

    private T testConfig;

}
