package com.maoyan.coverage.admin.domain.vo.buildhistory;

import lombok.Data;

import java.io.Serializable;

/**
 * @author yimingyu
 * @date 2021/08/02
 */
@Data
public class BelowThresholdFilesVO implements Serializable {
    private static final long serialVersionUID = -4588327981024474067L;

    private String name;
    private String url;
}
