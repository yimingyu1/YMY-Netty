package com.maoyan.coverage.admin.domain.model.businessline;

import lombok.Data;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * @author yimingyu
 * @date 2021/07/29
 */
@Data
public class BusinessLineModel implements Serializable {
    private static final long serialVersionUID = -2271554287511698637L;

    private Integer id;
    private String businessLine;
    private String creator;
    private String updater;
    /**
     * '删除状态， 0：未删除 1：已删除'
     */
    private Integer deleted;
    private LocalDateTime createTime;
    private LocalDateTime updateTime;
}
