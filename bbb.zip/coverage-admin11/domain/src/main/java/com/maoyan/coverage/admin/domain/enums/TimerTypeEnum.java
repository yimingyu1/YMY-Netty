package com.maoyan.coverage.admin.domain.enums;

import com.google.common.collect.Maps;

import java.util.Map;

/**
 * @author lizhuoran05
 * @date 2021/7/20
 */
public enum TimerTypeEnum {

    IMMEDIATE(0, "立即构建"),
    INTERVAL(1, "周期构建"),
    CRON(2, "使用 cron 表达式的构建");

    int type;
    String des;

    TimerTypeEnum(int type, String des) {
        this.type = type;
        this.des = des;
    }

    public static Map<Integer, TimerTypeEnum> typeMap = Maps.newHashMap();

    static {
        for (TimerTypeEnum value : values()) {
            typeMap.put(value.getType(), value);
        }
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getDes() {
        return des;
    }

    public void setDes(String des) {
        this.des = des;
    }
}
