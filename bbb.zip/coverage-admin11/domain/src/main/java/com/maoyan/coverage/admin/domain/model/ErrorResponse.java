package com.maoyan.coverage.admin.domain.model;

import com.maoyan.coverage.admin.domain.enums.CoverageAdminErrorCodeEnum;

import java.io.Serializable;

public class ErrorResponse implements Serializable {
    private static final long serialVersionUID = 2311329575134478642L;
    private String request;
    private int code;
    private String message;
    private String type;

    public ErrorResponse(){}

    public ErrorResponse (CoverageAdminErrorCodeEnum errorCodeEnum){
        this.code = errorCodeEnum.getCode();
        this.message = errorCodeEnum.getDesc();
    }

    public ErrorResponse (int code, String message){
        this.code = code;
        this.message = message;
    }

    public ErrorResponse(String request, int code, String message, String type){
        this.request = request;
        this.code = code;
        this.message = message;
        this.type = type;
    }

    public String getRequest() {
        return request;
    }

    public void setRequest(String request) {
        this.request = request;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
