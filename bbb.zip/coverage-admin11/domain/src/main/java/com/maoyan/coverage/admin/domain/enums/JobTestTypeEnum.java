package com.maoyan.coverage.admin.domain.enums;

import java.util.HashMap;
import java.util.Map;

/**
 * @author yimingyu
 * @date 2021/11/08
 */
public enum  JobTestTypeEnum {
    DEMAND_TEST(0, "需求测试"),
    INTERFACE_TEST(1, "接口测试");

    int type;
    String dec;

    JobTestTypeEnum(int type, String dec){
        this.type = type;
        this.dec = dec;
    }

    public static Map<Integer, JobTestTypeEnum> jobTestTypeEnumMap = new HashMap<>();
    static {
        for (JobTestTypeEnum jobTestTypeEnum: values()
             ) {
            jobTestTypeEnumMap.put(jobTestTypeEnum.type, jobTestTypeEnum);
        }
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getDec() {
        return dec;
    }

    public void setDec(String dec) {
        this.dec = dec;
    }
}
