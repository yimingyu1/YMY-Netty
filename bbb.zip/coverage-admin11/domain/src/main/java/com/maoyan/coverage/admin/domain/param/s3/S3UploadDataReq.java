package com.maoyan.coverage.admin.domain.param.s3;

import java.util.ArrayList;

/**
 * Created by lihongmei03 on 2020-11-30
 */
public class S3UploadDataReq {
    private String projectName;
    private String content;
    private String fileName;
    private int coverageType;
    private String env;

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public int getCoverageType() {
        return coverageType;
    }

    public void setCoverageType(int coverageType) {
        this.coverageType = coverageType;
    }

    public String getEnv() {
        return env;
    }

    public void setEnv(String env) {
        this.env = env;
    }

    @Override
    public String toString() {
        return "S3UploadDataReq{" +
                "projectName='" + projectName + '\'' +
                ", fileName='" + fileName + '\'' +
                ", coverageType=" + coverageType +
                ", env='" + env + '\'' +
                '}';
    }

    public ArrayList<String> getEmptyKey() {
        ArrayList<String> arrayList = new ArrayList<String>();
        if (this.getContent() == null) {
            arrayList.add("content");
        }
        if (this.getEnv() == null) {
            arrayList.add("env");
        }
        if (this.getProjectName() == null) {
            arrayList.add("projectName");
        }
        if (this.getFileName() == null) {
            arrayList.add("fileName");
        }
        if (this.getCoverageType() == 0) {
            arrayList.add("coverageType");
        }
        return arrayList;
    }
}
