package com.maoyan.coverage.admin.domain.model.job.msg;

import lombok.Data;

/**
 * @author lizhuoran05
 * @date 2021/9/29
 */
@Data
public class ReportUploadFailedMsgModel {

    private String targetPath;

    public String getMsg() {
        String lineFeed = "\n";
        String info = "【 信息 】: 上传报告时出现失败" + lineFeed;
        String targetPath = "【 目标路径 】: " + getTargetPath() + lineFeed;
        String remarks = "【 备注 】: 请检查是否是机器性能问题";

        // 拼接字符串
        return info.concat(targetPath).concat(remarks);
    }

}
