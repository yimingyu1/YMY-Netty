package com.maoyan.coverage.admin.domain.model.job.msg;

import lombok.Data;

import java.util.List;

/**
 * @author lizhuoran05
 * @date 2021/9/14
 */
@Data
public class BuildFailedToUserMsgModel {

    /**
     * jobName
     */
    private String jobName;

    /**
     * projectName
     */
    private String projectName;

    /**
     * buildNum
     */
    private int buildNum;

    /**
     * 构建历史url
     */
    private String buildHistoryUrl;

    /**
     * 备注
     */
    private String remarks;

    private List<String> projectLeader;


    /**
     * 获取发给用户的信息
     *
     * @return
     */
    public String getMsg() {
        String lineFeed = "\n";
        String info = "【 信息 】: Job 构建失败" + lineFeed;
        String jobName = "【 job 名称 】: " + getJobName() + lineFeed;
        String buildName = "【 构建号 】: " + getBuildNum() + lineFeed;
        String projectName = "【 关联项目 】: " + getProjectName() + lineFeed;
        String buildHistory = "【 构建历史 】: " + "[点击查看|" + getBuildHistoryUrl() + "]" + lineFeed;
        String projectLeader = "【 通知用户 】: " + getProjectLeader() + lineFeed;
        String remarks = "【 备注 】: " + getRemarks();

        // 拼接字符串
        return info.concat(jobName).concat(buildName).concat(projectName).concat(buildHistory).concat(projectLeader).concat(remarks);
    }

}
