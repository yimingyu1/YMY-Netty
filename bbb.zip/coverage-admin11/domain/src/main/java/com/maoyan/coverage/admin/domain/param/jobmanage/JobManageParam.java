package com.maoyan.coverage.admin.domain.param.jobmanage;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @author yimingyu
 * @date 2021/07/29
 */
@Data
public class JobManageParam implements Serializable {

    private static final long serialVersionUID = -3794491058473755817L;
    private int id;
    private String jobName;
    private int reportType;
    private String currentBranch;
    private String originBranch;
    private double threshold;
    // MRN PC I server applet
    private String testEnv;
    // MRN PC I applet android
    private List<String> testTime;
    // PC I
    private List<String> deployHost;
    // applet
    private String commit;
    // server
    private List<String> serverIp;
    // server
    private List<String> agentPort;
    // server
    private int releaseId;
    // server
    // 去掉targetDir字段
//    private String targetDir;
    // android ios
    private String testVersion;
    // android ios
    private int projectNum;
    private String jenkinsRef;
    private String jenkinsGitAddress;
    private String jenkinsGitBranch;
}
