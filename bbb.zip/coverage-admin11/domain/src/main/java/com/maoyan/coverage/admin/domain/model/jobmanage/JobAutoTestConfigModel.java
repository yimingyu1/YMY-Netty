package com.maoyan.coverage.admin.domain.model.jobmanage;

import lombok.Data;

import java.io.Serializable;

/**
 * @author fengxingbing
 * @date 2021/11/1
 */
@Data
public class JobAutoTestConfigModel implements Serializable {
    private static final long serialVersionUID = -2176025651714090548L;

    private String jenkinsRef;
    private String jenkinsGitAddress;
    private String jenkinsGitBranch;

}
