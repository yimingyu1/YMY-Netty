package com.maoyan.coverage.admin.domain.param.s3;

/**
 * Created by lihongmei03 on 2020-11-30
 */
public class S3UploadReportsReq {

    private int coverageType;
    private String projectName;
    private String reportPath;
    private String projectVersion;
    private String buildNum;

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public String getBuildNum() {
        return buildNum;
    }

    public void setBuildNum(String buildNum) {
        this.buildNum = buildNum;
    }

    public String getReportPath() {
        return reportPath;
    }

    public void setReportPath(String reportPath) {
        this.reportPath = reportPath;
    }

    public int getCoverageType() {
        return coverageType;
    }

    public void setCoverageType(int coverageType) {
        this.coverageType = coverageType;
    }

    public String getProjectVersion() {
        return projectVersion;
    }

    public void setProjectVersion(String projectVersion) {
        this.projectVersion = projectVersion;
    }
}
