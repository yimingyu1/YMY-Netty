package com.maoyan.coverage.admin.domain.vo.jobmanage;

import lombok.Data;

import java.util.List;

/**
 * @author yimingyu
 * @date 2021/07/29
 */
@Data
public class JobDetailHeaderVO {
    private String projectName;
    // job名
    private String jobName;
    // 报告类型
    private String jobType;
    private String gitAddress;
    // 测试分支
    private String testBranch;
    // 对比分支
    private String originBranch;
    // 阈值
    private double threshold;
    private int projectType;
    private int buildStatus;
}
