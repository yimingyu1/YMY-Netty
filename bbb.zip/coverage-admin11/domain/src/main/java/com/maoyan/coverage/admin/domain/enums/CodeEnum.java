package com.maoyan.coverage.admin.domain.enums;

/**
 * Created by lihongmei03 on 2020-12-07
 */
public enum  CodeEnum {
    SUC(100000, "COMMON_SUC", "请求成功");

    private final Integer code;
    private final String type;
    private final String message;

    private CodeEnum(Integer code, String type, String message) {
        this.code = code;
        this.type = type;
        this.message = message;
    }

    public Integer getCode() {
        return this.code;
    }

    public String getType() {
        return this.type;
    }

    public String getMessage() {
        return this.message;
    }

}
