package com.maoyan.coverage.admin.domain.enums;

public enum  CoverageAdminErrorCodeEnum {

    ERROR_CODE_ENUM(0, "通用"),
    ERROR_BUSINESS_LINE_ISNULL(1, "业务线名不能为空");


    private int code;
    private String desc;

    private CoverageAdminErrorCodeEnum(int code, String desc){
        this.code = code;
        this.desc = desc;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
