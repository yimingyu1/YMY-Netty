package com.maoyan.coverage.admin.domain.model.jobmanage;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

/**
 * @author yimingyu
 * @date 2021/07/27
 */

@Data
public class JobTestConfig2ServerModel implements Serializable {
    private static final long serialVersionUID = 7768718628802404865L;

    private String testEnv;
    private List<String> serverIp;
    private List<String> agentPort;
    private Integer releaseId;
    // 去掉targetDir字段
//    private String targetDir;
    private List<String> testTime;


}
