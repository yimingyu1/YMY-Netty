package com.maoyan.coverage.admin.domain.schema;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author lizhuoran05
 * @date 2021/7/19
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class JobTimerDO extends BaseDO {

    private Integer jobConfigId;

    private Integer timerType;

    private String timerValue;

    private Integer closed;

    /**
     * {@link com.maoyan.coverage.admin.domain.enums.JobTimerTypeEnum}
     */
    private Integer type;
}
