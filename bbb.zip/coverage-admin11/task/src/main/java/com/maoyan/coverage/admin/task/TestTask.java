package com.maoyan.coverage.admin.task;

/**
 * @author gaobaoyu on 2018/11/06
 * @version 1.0
 **/
public class TestTask {

}