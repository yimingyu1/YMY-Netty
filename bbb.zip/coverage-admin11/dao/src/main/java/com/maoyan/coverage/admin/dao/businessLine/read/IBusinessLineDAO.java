package com.maoyan.coverage.admin.dao.businessLine.read;

import com.maoyan.coverage.admin.domain.schema.businessline.BusinessLineDO;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author yimingyu
 * @date 2021/07/19
 */
@Repository
public interface IBusinessLineDAO {

    List<BusinessLineDO> getBusinessLineList(@Param("offset") int offset, @Param("limit") int limit);

    List<BusinessLineDO> getAllBusinessLines();

    BusinessLineDO getBusinessLineByName(@Param("businessLineName") String businessLineName);

    BusinessLineDO getBusinessLineById(@Param("businessLineId") int businessLineId);

}
