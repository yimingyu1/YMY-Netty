package com.maoyan.coverage.admin.dao.jobmanage.write;

import com.maoyan.coverage.admin.domain.schema.buildHistory.BuildHistoryDO;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

/**
 * @author lizhuoran05
 * @date 2021/7/29
 */
@Repository
public interface IWriteJobBuildHistoryDAO {

    int insert(BuildHistoryDO jobBuildHistoryDO);

    // 很多字段其实不需要修改，考虑是否修改
    int update(BuildHistoryDO buildHistoryDO);

    int updateJenkinsBuildNum(@Param("buildId") int buildId, @Param("jenkinsBuildNum") int jenkinsBuildNum);
}
