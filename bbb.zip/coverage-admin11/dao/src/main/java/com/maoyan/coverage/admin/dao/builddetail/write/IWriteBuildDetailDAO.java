package com.maoyan.coverage.admin.dao.builddetail.write;

import com.maoyan.coverage.admin.domain.schema.buildHistory.BuildHistoryDetailDO;

/**
 * @author lizhuoran05
 * @date 2021/8/10
 */
public interface IWriteBuildDetailDAO {

    int insert(BuildHistoryDetailDO buildHistoryDetailDO);

}
