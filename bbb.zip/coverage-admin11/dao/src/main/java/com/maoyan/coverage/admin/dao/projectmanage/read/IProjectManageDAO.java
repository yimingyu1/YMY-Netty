package com.maoyan.coverage.admin.dao.projectmanage.read;

import com.maoyan.coverage.admin.domain.schema.projectmanage.ProjectManageDO;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author yimingyu
 * @date 2021/07/21
 */
@Repository
public interface IProjectManageDAO {

    List<ProjectManageDO> getProjectManageDOListByBusinessLineId(@Param("businessLineId") int businessLineId);

    ProjectManageDO getSameProjectManageDOByModel(@Param("businessLineId") int businessLineId,
                                                  @Param("projectName") String projectName,
                                                  @Param("repositoryAddress") String repositoryAddress,
                                                  @Param("projectLeader") String projectLeader,
                                                  @Param("type") int type);

    List<ProjectManageDO> getProjectMangeByName(@Param("projectManageName") String projectManageName);

    ProjectManageDO getProjectMangeById(@Param("id") int id);

    List<ProjectManageDO> getAllProjectManages(@Param("businessLineId") int businessLineId);

    List<ProjectManageDO> getProjectManageList(@Param("businessLineId") int businessLineId,
                                               @Param("offset") int offset, @Param("limit") int limit);

    List<ProjectManageDO> getAllProjectManagesWithType(@Param("businessLineId") int businessLineId,
                                                       @Param("projectType") int projectType);

    List<ProjectManageDO> getProjectManageListWithType(@Param("businessLineId") int businessLineId,
                                                       @Param("offset") int offset, @Param("limit") int limit,
                                                       @Param("projectType") int projectType);
}
