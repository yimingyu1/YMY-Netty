package com.maoyan.coverage.admin.dao.projectmanage.write;

import com.maoyan.coverage.admin.domain.schema.projectmanage.ProjectManageDO;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.Map;

/**
 * @author yimingyu
 * @date 2021/07/21
 */
@Repository
public interface IWriteProjectManageDAO {
    /**
     * 插入时注意更新projectId
     * @return
     */
    int insertProject(ProjectManageDO projectManageDO);

    int updateProject(ProjectManageDO projectManageDO);

    int deleteProject(Map<String, Object> delProjectMap);


}
