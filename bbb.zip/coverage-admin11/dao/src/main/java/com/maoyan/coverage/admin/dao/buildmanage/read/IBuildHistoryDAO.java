package com.maoyan.coverage.admin.dao.buildmanage.read;

import com.maoyan.coverage.admin.domain.model.projectmanage.ProjectManageModel;
import com.maoyan.coverage.admin.domain.schema.buildHistory.BuildHistoryDO;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author yimingyu
 * @date 2021/07/21
 */
@Repository
public interface IBuildHistoryDAO {

    List<BuildHistoryDO> getBuildHistoryListByJobId(@Param("jobId") int jobId);

    List<BuildHistoryDO> getBuildHistoryPageListByJobId(@Param("offset") int offset, @Param("limit") int limit, @Param("jobId") int jobId);

    BuildHistoryDO getBuildHistoryByJobId(@Param("jobId") int jobId);

    BuildHistoryDO getNewestBuildHistoryByJobId(@Param("jobId") int jobId);

    BuildHistoryDO getBuildHistoryByBuildId(@Param("buildId") int buildId);

}
