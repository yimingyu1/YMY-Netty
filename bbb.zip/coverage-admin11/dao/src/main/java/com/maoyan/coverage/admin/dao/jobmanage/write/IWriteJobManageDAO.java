package com.maoyan.coverage.admin.dao.jobmanage.write;

import com.maoyan.coverage.admin.domain.schema.jobconfig.JobConfigDO;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

/**
 * @author yimingyu
 * @date 2021/07/21
 */
@Repository
public interface IWriteJobManageDAO {

    int insertJob(JobConfigDO jobConfig);

    int updateJob(JobConfigDO jobConfig);

    int deleteJob(@Param("id") int id, @Param("updater") String updater, @Param("updateTime")LocalDateTime updateTime);

    int deleteJobBranch(Map<String, Object> delJobMap);
}
