package com.maoyan.coverage.admin.dao.jobtimer;

import com.maoyan.coverage.admin.domain.schema.JobTimerDO;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author lizhuoran05
 * @date 2021/7/19
 */
@Repository
public interface JobTimerDAO {

    /**
     * 测试连通性使用
     */
    List<JobTimerDO> selectAll();

    int insert(JobTimerDO jobTimerDO);

    /**
     * 更新timerType和timerValue
     */
    int updateByJobConfigIdAndType(JobTimerDO jobTimerDO);

    JobTimerDO getJobTimerDOByJobConfigId(int jobConfigId);

    int deleteById(int id);

    List<JobTimerDO> getJobTimerDOByClosed(int closed);

    JobTimerDO getJobTimerDOByJobConfigIdAndType(@Param("jobConfigId") int jobConfigId, @Param("type") int type);

    JobTimerDO getJobTimerDOByJobConfigIdAndTypeAndClosed(@Param("jobConfigId") int jobConfigId, @Param("type") int type, @Param("closed") int closed);

    List<JobTimerDO> getJobTimerDOByJobConfigIdAndClosed(@Param("jobConfigId") int jobConfigId, @Param("closed") int closed);
}
