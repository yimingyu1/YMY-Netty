package com.maoyan.coverage.admin.dao.jobmanage.read;

import com.maoyan.coverage.admin.domain.model.projectmanage.ProjectManageModel;
import com.maoyan.coverage.admin.domain.schema.jobconfig.JobConfigDO;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author yimingyu
 * @date 2021/07/21
 */
@Repository
public interface IJobManageDAO {

    List<JobConfigDO> getJobConfigListByProjectConfigIdAndJobType(@Param("projectConfigId") int projectConfigId,
                                                        @Param("jobType") int jobType);
    List<JobConfigDO> getJobConfigListByProjectConfigId(@Param("projectConfigId") int projectConfigId);

    JobConfigDO getJobConfigByName(@Param("jobName") String jobName);

    JobConfigDO getJobConfigById(@Param("id") int id);

    String getBuildHistoryProjectManageModelByBuildId(@Param("buildId") int buildId);

    List<JobConfigDO> getJobConfigListWithLimit(@Param("projectConfigId") int projectConfigId,
                                                @Param("jobType") int jobType,
                                                @Param("offset") int offset, @Param("limit") int limit);

    String getJobNameByJobConfigId(@Param("id") int id);

    int getProjectTypeByJobConfigId(@Param("id") int id);

    String getJobBasicConfigModelByJobConfigId(@Param("id") int id);

    String getJobTestConfigByJobConfigId(@Param("id") int id);

    List<Integer> getAllJobConfigId();
}
