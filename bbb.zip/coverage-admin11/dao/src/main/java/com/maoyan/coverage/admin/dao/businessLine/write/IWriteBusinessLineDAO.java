package com.maoyan.coverage.admin.dao.businessLine.write;

import com.maoyan.coverage.admin.domain.schema.businessline.BusinessLineDO;

/**
 * @author yimingyu
 * @date 2021/07/19
 */
public interface IWriteBusinessLineDAO {

    int insertBusinessLine(BusinessLineDO businessLine);

    int updateBusinessLine(BusinessLineDO businessLine);

    int deleteBusinessLineById(BusinessLineDO businessLine);
}
