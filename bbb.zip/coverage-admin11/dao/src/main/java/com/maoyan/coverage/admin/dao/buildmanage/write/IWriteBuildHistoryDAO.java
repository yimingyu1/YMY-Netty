package com.maoyan.coverage.admin.dao.buildmanage.write;

/**
 * @author yimingyu
 * @date 2021/07/21
 */
public interface IWriteBuildHistoryDAO {
}
