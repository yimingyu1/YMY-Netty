package com.maoyan.coverage.admin.dao.builddetail.read;

import com.maoyan.coverage.admin.domain.schema.buildHistory.BuildHistoryDetailDO;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

/**
 * @author yimingyu
 * @date 2021/07/30
 */
@Repository
public interface IBuildDetailDAO {

    BuildHistoryDetailDO getBuildDetailByBuildId(@Param("buildId") int BuildId);
}
