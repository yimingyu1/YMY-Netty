package com.maoyan.coverage.admin.common.utils;

/**
 * @author yimingyu
 * @date 2021/07/30
 */
public class BuildHistoryStringUtils {

    public static String getFormatString(String st1, String st2){
        return st1 + " -> " + st2;
    }
}
