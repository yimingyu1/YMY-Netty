package com.maoyan.coverage.admin.common.exception;

/**
 * @author lizhuoran05
 * @date 2021/9/26
 */
public class DeveloperConfigException extends RuntimeException{

    public DeveloperConfigException() {
        super();
    }

    public DeveloperConfigException(String message) {
        super(message);
    }

    public DeveloperConfigException(String message, Throwable cause) {
        super(message, cause);
    }

    public DeveloperConfigException(Throwable cause) {
        super(cause);
    }

    protected DeveloperConfigException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
