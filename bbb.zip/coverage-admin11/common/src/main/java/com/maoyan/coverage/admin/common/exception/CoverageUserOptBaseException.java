package com.maoyan.coverage.admin.common.exception;

/**
 * @author yimingyu
 * @date 2021/11/17
 */
public interface CoverageUserOptBaseException {

}
