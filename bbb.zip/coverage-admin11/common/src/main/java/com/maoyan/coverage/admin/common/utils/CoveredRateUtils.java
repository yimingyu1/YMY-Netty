package com.maoyan.coverage.admin.common.utils;

import com.maoyan.coverage.admin.domain.enums.CoveredRateColorEnum;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

/**
 * @author yimingyu
 * @date 2021/07/29
 */
public class CoveredRateUtils {

    /**
     * 返回计算覆盖率列表   返回形式： 第一个值  a/b   第二个值  a/b的结果保留整数  第三个值   a/b结果保留两位小数
     * @param covered
     * @param linesOrBranches
     * @return
     */
    public static List<String> getCoveredRate(double covered, double linesOrBranches){
        List<String> list = new ArrayList<>();
        list.add((int)covered + "/" + (int)linesOrBranches);
        if (linesOrBranches == 0){
            list.add("0");
            list.add("0.00");
        } else {
            list.add(new DecimalFormat("0").format(covered * 100 / linesOrBranches));
            list.add(new DecimalFormat("0.00").format(covered * 100 / linesOrBranches));
        }
        return list;
    }

    public static String getCoveredRateColor(double coveredRate, double threshold){
        if (threshold <= 1){
            threshold = Math.round(threshold * 100);
        }
        if (coveredRate >= threshold){
            return CoveredRateColorEnum.SUPRA_COVERED_RATE_COLOR.getCoveredRateColor();
        } else {
            return CoveredRateColorEnum.LOW_COVERED_RATE_COLOR.getCoveredRateColor();
        }
    }
}
