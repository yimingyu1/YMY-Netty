package com.maoyan.coverage.admin.common.utils;

import com.maoyan.coverage.admin.domain.enums.ProjectTypeEnum;

/**
 * 工作区路径工具类
 *
 * @author lizhuoran05
 * @date 2021/7/21
 */
public class PathUtils {

    /**
     * 本地工作区路径：workspace/${projectType}/${projectId}/${jobId}/${build_num}/code/
     * 本地工作区路径：workspace/${projectType}/${projectId}/${jobId}/${build_num}/data/
     * 报告本地路径：workspace/${projectType}/${projectId}/${jobId}/${build_num}/report/
     * s3 存放路径：${bucket}/${projectType}/${projectId}/${jobId}/${build_num}/report/
     */

    private static final String WORK_SPACE = "workspace";

    private static final String DIR = System.getProperty("user.dir");

    private static final String DATA = "data";

    private static final String DUMP_DATA = "dumpData";

    private static final String REPORT = "report";

    private static final String CODE = "code";

    public static String getWorkSpace(ProjectTypeEnum projectTypeEnum, long projectId, long jobId, long buildNum) {
        return DIR + "/" + WORK_SPACE + "/" + projectTypeToPath(projectTypeEnum) + fillProjectId(projectId) + "/" + fillJobId(jobId) + "/" + fillBuildNum(buildNum) + "/";
    }

    public static String getWorkSpaceOfCode(ProjectTypeEnum projectTypeEnum, long projectId, long jobId, long buildNum) {
        return DIR + "/" + WORK_SPACE + "/" + projectTypeToPath(projectTypeEnum) + fillProjectId(projectId) + "/" + fillJobId(jobId) + "/" + fillBuildNum(buildNum) + "/" + CODE + "/";
    }

    public static String getWorkSpaceOfData(ProjectTypeEnum projectTypeEnum, long projectId, long jobId, long buildNum) {
        return DIR + "/" + WORK_SPACE + "/" + projectTypeToPath(projectTypeEnum) + fillProjectId(projectId) + "/" + fillJobId(jobId) + "/" + fillBuildNum(buildNum) + "/" + DATA + "/";
    }

    public static String getDumpWorkSpaceOfData(ProjectTypeEnum projectTypeEnum, long projectId, long jobId) {
        return DIR + "/" + WORK_SPACE + "/" + projectTypeToPath(projectTypeEnum) + fillProjectId(projectId) + "/" + fillJobId(jobId) + "/" + DUMP_DATA + "/";
    }

    public static String getWorkSpaceOfReport(ProjectTypeEnum projectTypeEnum, long projectId, long jobId, long buildNum) {
        return DIR + "/" + WORK_SPACE + "/" + projectTypeToPath(projectTypeEnum) + fillProjectId(projectId) + "/" + fillJobId(jobId) + "/" + fillBuildNum(buildNum) + "/" + REPORT + "/";
    }

    public static String getBaseWorkSpace(ProjectTypeEnum projectTypeEnum, long projectId, long jobId, long buildNum) {
        return DIR + "/" + WORK_SPACE + "/" + projectTypeToPath(projectTypeEnum) + fillProjectId(projectId) + "/" + fillJobId(jobId) + "/" + fillBuildNum(buildNum) + "/";
    }

    private static String fillProjectId(long projectId) {
        return "projectId:" + projectId;
    }

    private static String fillJobId(long jobId) {
        return "jobId:" + jobId;
    }

    private static String fillBuildNum(long buildNum) {
        return "buildNum:" + buildNum;
    }

    public static void main(String[] args) {
        System.out.println(getWorkSpace(ProjectTypeEnum.ANDROID, 1, 1, 1));
    }

    public static String projectTypeToPath(ProjectTypeEnum projectTypeEnum) {
        String coveragePath = "";
        switch (projectTypeEnum) {
            case SERVER:
                coveragePath = "server/";
                break;
            case PC:
            case I_VERSION:
                coveragePath = "web/";
                break;
            case MRN:
                coveragePath = "mrn/";
                break;
            case ANDROID:
                coveragePath = "android/";
                break;
            case IOS:
                coveragePath = "ios/";
                break;
            case APPLETS:
                coveragePath = "applets/";
                break;
            default:
                break;
        }
        return coveragePath;
    }

}
