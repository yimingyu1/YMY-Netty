package com.maoyan.coverage.admin.common.utils;

import com.maoyan.coverage.admin.domain.model.Paging;
import com.meituan.mobile.movie.common.response.ApiResponse;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.io.Serializable;

/**
 * @author yimingyu
 * @date 2021/07/21
 */
@EqualsAndHashCode(callSuper = true)
@Data
public class ApiResponseCoverage<T> extends ApiResponse<T> implements Serializable {
    private static final long serialVersionUID = 8504033275688909347L;
    private boolean success;
    private int code;
    private String errMsg;
    private T data;
    private Paging paging;


    public static <T> ApiResponseCoverage<T> buildSuccess(T data, Paging paging){
        ApiResponseCoverage<T> apiResponseCoverage = new ApiResponseCoverage<T>();
        apiResponseCoverage.setData(data);
        apiResponseCoverage.setSuccess(true);
        apiResponseCoverage.setPaging(paging);
        return apiResponseCoverage;
    }

}
