package com.maoyan.coverage.admin.common;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.S3ClientOptions;
import com.amazonaws.services.s3.model.DeleteObjectRequest;
import com.amazonaws.services.s3.model.ListObjectsRequest;
import com.amazonaws.services.s3.model.ObjectListing;
import com.amazonaws.services.s3.model.S3ObjectSummary;
import com.maoyan.coverage.admin.domain.enums.TestEnvEnum;

import java.util.ArrayList;

/**
 * Created by lihongmei03 on 2020-12-07
 */
public class S3Util {

    /**
     * 老方法，上传覆盖率数据时调用。
     * 上传报告时不使用此方法匹配路径
     *
     * @param coverageType
     * @return
     */
    public String coverageTypeMapping(int coverageType) {
        String coveragePath = "";
        switch (coverageType) {
            case 0:
                coveragePath = "server/";
                break;
            case 1:
                coveragePath = "web/";
                break;
            case 2:
                coveragePath = "wechat/";
                break;
            case 3:
                coveragePath = "android/";
                break;
            case 4:
                coveragePath = "mrn/";
                break;
            case 5:
                coveragePath = "ios/";
                break;
            default:
                break;
        }
        return coveragePath;
    }

    /**
     * 为方便测试，提供一个删除方法
     * !!!需要删除什么环境就选择什么环境的配置，每次用完后把赋值清除掉，清除掉
     * prod
     * env.mss.accessKey=cc87244abb354e34b8e0b116e758dcf9
     * env.mss.secretKey=9b4c6e3e1d6e4bd7b1ae06393ed61829
     * env.mss.host=s3plus.vip.sankuai.com
     * env.mss.bucket=coverage-report-data
     * test
     * env.mss.accessKey=94989233a9554dc3923d523458c05429
     * env.mss.secretKey=dabf3b57d40d4b909e675cf2323a056a
     * env.mss.host=msstest.vip.sankuai.com
     * env.mss.bucket=coverage-report-test-data
     *
     * @param prefix 前缀
     */
    private static void deleteFile(String prefix) {
        String accessKey = "";
        String secretKey = "";
        String host = "";
        String bucket = "";

        S3ClientOptions s3ClientOptions = new S3ClientOptions();
        s3ClientOptions.setPathStyleAccess(true);

        AWSCredentials credentials = new BasicAWSCredentials(accessKey, secretKey);
        //生成云存储api client
        AmazonS3 s3Client = new AmazonS3Client(credentials);
        //配置云存储服务地址
        s3Client.setEndpoint(host);
        s3Client.setS3ClientOptions(s3ClientOptions);

        ListObjectsRequest listObjectsRequest = new ListObjectsRequest()
                .withBucketName(bucket)
                //查询bucket下固定的前缀
                .withPrefix(prefix);
        ObjectListing objectListing = null;
        objectListing = s3Client.listObjects(listObjectsRequest);

        ArrayList<String> objectList = new ArrayList<>();
        for (S3ObjectSummary objectSummary : objectListing.getObjectSummaries()) {
            objectList.add(objectSummary.getKey());
        }

        for (int i = 0; i < objectList.size(); i++) {
            s3Client.deleteObject(new DeleteObjectRequest(bucket, objectList.get(i)));
            try {
                Thread.sleep(200);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println("删除成功, 共" + objectList.size() + "个, 已删除" + (i + 1) + "个");
        }
    }
}
