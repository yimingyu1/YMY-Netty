package com.maoyan.coverage.admin.common.utils;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author yimingyu
 * @date 2021/09/23
 */
@Slf4j
public class FormatUtils {

    public static final String IS_LETTER_OR_NUMBER = "^([0-9|a-z|A-Z]+)$";
    public static final String IS_NUMBER = "^(\\d+)$";

    public static boolean formatJudge(String str, String regex){
        if (StringUtils.isEmpty(str)){
            return false;
        }
        Pattern compile = Pattern.compile(regex);
        Matcher matcher = compile.matcher(str);
        if (matcher.find()){
            return true;
        }
        return false;
    }


    public static boolean formatJudgeBatch(List<String> strings, String regex){
        log.info("list isLetterOrNumber, list is {}, regex is {}", strings, regex);
        if (CollectionUtils.isEmpty(strings)){
            return false;
        }
        return strings.stream().allMatch( str -> formatJudge(str, regex));
    }
}
