package com.maoyan.coverage.admin.common.utils;

import com.maoyan.coverage.admin.dao.buildmanage.read.IBuildHistoryDAO;
import com.maoyan.coverage.admin.domain.schema.buildHistory.BuildHistoryDO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @author yimingyu
 * @date 2021/07/30
 */
@Component
public class BuildUtils {

    private static IBuildHistoryDAO buildHistoryDAO;


    @Autowired
    public BuildUtils (IBuildHistoryDAO buildHistoryDAO){
        BuildUtils.buildHistoryDAO = buildHistoryDAO;
    }

    /**
     *获取插入buildHistory的buildNum
     * @return
     */
    public static int getInsertBuildNum(int jobId){
        List<BuildHistoryDO> buildHistoryDOS = buildHistoryDAO.getBuildHistoryListByJobId(jobId);
        return buildHistoryDOS.size() + 1;
    }

}
