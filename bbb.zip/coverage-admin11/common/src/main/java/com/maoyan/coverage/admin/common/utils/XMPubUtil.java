package com.maoyan.coverage.admin.common.utils;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.maoyan.coverage.admin.common.PropUtil;
import com.maoyan.coverage.admin.domain.constant.PublisherConstant;
import com.sankuai.xm.pub.push.Pusher;
import com.sankuai.xm.pub.push.PusherBuilder;

import java.util.List;

/**
 * @author lizhuoran05
 * @date 2021/8/02
 */
public class XMPubUtil {

    /**
     * 推送给个人的大象pusher
     */
    private static final Pusher pusher;

    private static final String APP_KEY = "10051262K315P121";

    private static final String APP_TOKEN = "6b1fbf2fce5a3f8721419e21a0a210c5";

    private static final String TARGET_URL = "http://dxw-in.sankuai.com/api/pub/push";

    private static final long FROM_UID = 137438955760L;

    private static final String env = PropUtil.getProperty("publish.env");

    static {
        pusher = PusherBuilder.defaultBuilder().withAppkey(APP_KEY)
                .withApptoken(APP_TOKEN)
                .withTargetUrl(TARGET_URL)
                .withFromUid(FROM_UID).withFromName("coverage")
                .build();
    }

    public static boolean sendMessage(String msg, String... misIds) {
        JSONObject result = pusher.push(msg, misIds);
        JSONArray mids = result.getJSONArray("mids");
        return mids != null && !mids.isEmpty();
    }

    /**
     * 推送消息给指定misId
     */
    public static boolean sendMessage(String msg, List<String> misIdList) {
        String[] misIds = new String[misIdList.size()];
        misIdList.toArray(misIds);
        JSONObject result = pusher.push(buildMsg(msg), misIds);
        JSONArray mids = result.getJSONArray("mids");
        return mids != null && !mids.isEmpty();
    }

    /**
     * 推送消息给项目开发者
     */
    public static boolean sendToDeveloper(String msg) {
        JSONObject result = pusher.push(buildMsg(msg), PublisherConstant.SERVER_DEVELOPER);
        JSONArray mids = result.getJSONArray("mids");
        return mids != null && !mids.isEmpty();
    }

    private static String buildMsg(String msg) {
        String envMsg = "【 环境 】: " + env + "\n" +
                msg;
        return envMsg;
    }
}