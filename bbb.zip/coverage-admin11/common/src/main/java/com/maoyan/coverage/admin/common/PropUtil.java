package com.maoyan.coverage.admin.common;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class PropUtil {
    private static Properties propUtil = new Properties();

    public PropUtil() {
    }

    public static String getProperty(String key) {
        return propUtil.getProperty(key);
    }

    static {
        InputStream inputStream = PropUtil.class.getResourceAsStream("/common.properties");

        if (inputStream != null) {
            try {
                propUtil.load(inputStream);
            } catch (IOException var10) {
                var10.printStackTrace();
            } finally {
                try {
                    inputStream.close();
                } catch (IOException var9) {
                    var9.printStackTrace();
                }

            }
        }

    }
    public static void main(String[] args) {
        System.out.println(getProperty("mss.accessKey"));
    }
}
