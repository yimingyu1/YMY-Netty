package com.maoyan.coverage.admin.common.utils;

import com.maoyan.coverage.admin.common.exception.JenkinsException;
import com.offbytwo.jenkins.JenkinsServer;
import com.offbytwo.jenkins.model.Build;
import com.offbytwo.jenkins.model.BuildResult;
import com.offbytwo.jenkins.model.JobWithDetails;
import com.offbytwo.jenkins.model.QueueReference;
import lombok.extern.slf4j.Slf4j;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import javax.annotation.PostConstruct;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author yimingyu
 * @date 2021/11/09
 * 操作jenkins的工具类
 */
@Component
@Slf4j
public class JenkinsUtils {


    private static JenkinsServer jenkinsServer;
    private static String jenkinsServerUri;
    private static String jenkinsPathRegex;

    @Autowired
    private JenkinsServer server;

    @Value("${interfaceJenkins.jenkinsServerUri}")
    private String jenkinsUri;



    @PostConstruct
    public void init(){
        JenkinsUtils.jenkinsServer = server;
        JenkinsUtils.jenkinsServerUri = jenkinsUri;
        JenkinsUtils.jenkinsPathRegex = "^" + jenkinsUri + ".*job/(.+?)/*$";
    }

    /**
     * 获取jenkins job配置中的git地址和branch
     * 1.判断jenkins地址是否存在，不存在返回null
     * 2.如果存在，返回git地址和branch（map形式）
     * @param jenkinsPath  jenkins的http路径
     * @return
     */
    public static Map<String, String> getJenkinsGitInfo(String jenkinsPath){
        String rest = isExistJenkinsPath(jenkinsPath);
        if (rest == null){
            throw new JenkinsException("接口自动化jenkins路径错误,请检查后重试");
        }
        Map<String, String> map = new HashMap<>();
        Element gitElement = null;
        Element branchElement = null;
        try {
            String jobXml = jenkinsServer.getJobXml(rest);
            Document document = DocumentHelper.parseText(jobXml);
            Element rootElement = document.getRootElement();
            gitElement = rootElement.element("scm").element("userRemoteConfigs").element("hudson.plugins.git.UserRemoteConfig")
                    .element("url");
            branchElement = rootElement.element("scm").element("branches").element("hudson.plugins.git.BranchSpec")
                    .element("name");
        }catch (Exception e){
            log.error(e.getMessage());
            throw new JenkinsException("解析【" + rest + "】job配置出错，请联系管理员");
        }
        map.put("jenkinsGit", gitElement.getText());
        map.put("jenkinsBranch", branchElement.getText());
        return map;

    }

    public static Integer build(String jenkinsPath){
        String rest = isExistJenkinsPath(jenkinsPath);
        try {
            JobWithDetails job = jenkinsServer.getJob(rest);
            int buildNumber = job.getNextBuildNumber();
            job.build();
            return buildNumber;
        }catch (Exception e){
            throw new JenkinsException("接口job：" + rest + "构建失败, 请检查job是否配置远程触发构建");
        }

    }

    public static Build getBuildById(String jenkinsPath, int buildId){
        String rest = isExistJenkinsPath(jenkinsPath);
        try {
            JobWithDetails job = jenkinsServer.getJob(rest);
            return job.getBuildByNumber(buildId);
        }catch (Exception e){
            log.error("构建job不存在 {} ", e.getMessage());
            throw new JenkinsException(e.getMessage());
        }
    }



    public static String isExistJenkinsPath(String jenkinsPath){
        Pattern compile = Pattern.compile(jenkinsPathRegex);
        Matcher matcher = compile.matcher(jenkinsPath);
        if (matcher.find()){
            return matcher.group(1);
        }
        return null;
    }

    public static int getLastBuildNum(String jenkinsPath){
        int lastBuildNum = 0;
        String rest = isExistJenkinsPath(jenkinsPath);
        try {
            lastBuildNum = jenkinsServer.getJob(rest).getLastBuild().getNumber();
            if (lastBuildNum == 0){
                lastBuildNum++;
            }
        }catch (Exception e){
            log.error("构建job不存在 {} ", e.getMessage());
            throw new JenkinsException(e.getMessage());
        }
        log.info("last jenkins job buildNum = {}", lastBuildNum);
        return lastBuildNum;
    }


}
