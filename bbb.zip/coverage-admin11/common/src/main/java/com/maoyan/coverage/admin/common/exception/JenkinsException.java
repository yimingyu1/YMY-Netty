package com.maoyan.coverage.admin.common.exception;

/**
 * @author yimingyu
 * @date 2021/11/11
 */
public class JenkinsException extends RuntimeException implements CoverageUserOptBaseException{
    private static final long serialVersionUID = -1476724668545388040L;

    public JenkinsException(){
        super();
    }

    public JenkinsException(String message){
        super(message);
    }

}
