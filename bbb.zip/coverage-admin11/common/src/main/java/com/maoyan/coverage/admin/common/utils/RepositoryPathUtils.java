package com.maoyan.coverage.admin.common.utils;

import com.maoyan.coverage.admin.domain.constant.RepositoryRefConstant;
import org.apache.commons.lang3.StringUtils;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author yimingyu
 * @date 2021/09/03
 */
public class RepositoryPathUtils {

    public static String getRepositoryGroupPath(String gitAddress){
        if (StringUtils.isEmpty(gitAddress)){
            return null;
        }
        String regex = "^ssh://git@git.sankuai.com/(.+?).git$";
        Pattern compile = Pattern.compile(regex);
        Matcher matcher = compile.matcher(gitAddress);
        if(matcher.find()){
            return matcher.group(1);
        }
        return null;
    }
}
