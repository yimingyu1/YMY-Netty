package com.maoyan.coverage.admin.common.utils;

import com.maoyan.coverage.admin.domain.constant.DateFormatStr;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashSet;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.maoyan.coverage.admin.domain.constant.DateFormatStr.DATE_FORMAT_DO;
import static com.maoyan.coverage.admin.domain.constant.DateFormatStr.DATE_FORMAT_UPLOAD;

/**
 * @author yimingyu
 * @date 2021/07/21
 */
@Slf4j
public class DateUtils {

    public static String format2Str(LocalDateTime localDateTime, String formatStr) {
        return localDateTime.format(DateTimeFormatter.ofPattern(formatStr));
    }

    public static LocalDateTime format2Date(String formatStr, String dateTimeStr) {
        log.info("formatStr = {}, dateTimeStr = {}", formatStr, dateTimeStr);
        LocalDateTime newDatetime = null;
        try {
            if (formatStr.equals(DateFormatStr.DATE_FORMAT_TIME_STAMP)) {
                newDatetime = LocalDateTime.ofEpochSecond(Long.parseLong(dateTimeStr) / 1000, 0, ZoneOffset.ofHours(8));
            } else {
                DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern(formatStr);
                newDatetime = LocalDateTime.parse(dateTimeStr, dateTimeFormatter);
            }
        } catch (Exception e) {
            log.error("DateTimeFormat error! error = {}", e.getMessage());
        }
        return newDatetime;
    }

    public static List<String> turnTimeFormatBatch(List<String> DateTimeList, String oldFormatStr, String newFormatStr) {
        log.info("old DateTime = {}", DateTimeList);
        List<String> newDateTimeList = new ArrayList<>();
        if (CollectionUtils.isEmpty(DateTimeList)) {
            return newDateTimeList;
        }
        for (String DateTimeStr : DateTimeList
        ) {
            LocalDateTime localDateTime = format2Date(oldFormatStr, DateTimeStr);
            if (localDateTime == null) {
                break;
            }
            if (newFormatStr.equals(DateFormatStr.DATE_FORMAT_TIME_STAMP)) {
                newDateTimeList.add("" + localDateTime.toInstant(ZoneOffset.of("+8")).toEpochMilli());
            } else {
                newDateTimeList.add(format2Str(localDateTime, newFormatStr));
            }
        }
        log.info("new DateTime = {}", newDateTimeList);
        return newDateTimeList;
    }

    public static String getTodayStr() {
        DateTimeFormatter df = DateTimeFormatter.ofPattern(DATE_FORMAT_UPLOAD);
        LocalDateTime now = LocalDateTime.now();
        return df.format(now);
    }

    /**
     * 获取两个日期之间的所有日期，需要支持跨月
     * 如 2021-09-29 ～ 2021-10-02：2021-09-29、2021-09-30、2021-10-01、2021-10-02
     */
    public static List<String> collectLocalDates(LocalDateTime timeStart, LocalDateTime timeEnd) {
        DateTimeFormatter df = DateTimeFormatter.ofPattern(DATE_FORMAT_UPLOAD);

        String testStartDate = timeStart.format(df);
        String testEndDate = timeEnd.format(df);

        return collectLocalDates(LocalDate.parse(testStartDate), LocalDate.parse(testEndDate));
    }

    public static List<String> collectLocalDates(LocalDate start, LocalDate end) {
        return Stream.iterate(start, localDate -> localDate.plusDays(1))
                .limit(ChronoUnit.DAYS.between(start, end) + 1)
                .map(LocalDate::toString)
                .collect(Collectors.toList());
    }
}
