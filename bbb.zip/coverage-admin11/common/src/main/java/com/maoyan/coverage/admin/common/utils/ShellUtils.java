package com.maoyan.coverage.admin.common.utils;

import com.maoyan.coverage.admin.common.exception.DeveloperConfigException;
import com.maoyan.coverage.admin.common.exception.UserInputException;
import com.maoyan.coverage.admin.domain.constant.GitBranchConstant;
import com.meituan.mobile.movie.common.response.ApiResponse;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.stream.Collectors;

/**
 * @author lizhuoran05
 * @date 2021/7/30
 */
@Slf4j
public class ShellUtils {

    private static final Logger logger = LoggerFactory.getLogger(ShellUtils.class);

    // shell 存在的文件夹
    private static String SHELL_DIR = "";

    // 本地存放脚本的地址
    private static final String DIR = System.getProperty("user.dir") + "/provider/deploy";

    // 服务器上脚本存放的地址
    private static final String MACHINE_BASE_DIR = "/opt/meituan/mobile/coverage-admin/deploy";

    private static String CLONE_SHELL = "";

    private static String RM_SHELL = "";

    private static String GCOVR_HTML_SHELL = "";

    private static String GCOVR_CSV_SHELL = "";

    private static String MERGECLASS_SHELL = "";

    private static String CODE_SHELL = "";

    private static String CODE_COMMIT_SHELL = "";

    private static String GIT_BRANCH = "";

    private static String LCOV_INFO_SHELL = "";

    private static String LCOV_HTML_SHELL = "";

    static {
        Properties prop = System.getProperties();
        String os = prop.getProperty("os.name");
        if (os.startsWith("Mac")) {
            // 本地
            SHELL_DIR = DIR;
        } else if (os.startsWith("Linux")) {
            // 服务器上
            SHELL_DIR = MACHINE_BASE_DIR;
        }

        CLONE_SHELL = SHELL_DIR + "/biz-shell/clone.sh";
        RM_SHELL = SHELL_DIR + "/biz-shell/rm.sh";
        GCOVR_HTML_SHELL = SHELL_DIR + "/biz-shell/gcovr_html.sh";
        GCOVR_CSV_SHELL = SHELL_DIR + "/biz-shell/gcovr_csv.sh";
        MERGECLASS_SHELL = SHELL_DIR + "/biz-shell/dump_mergeclass.sh";
        CODE_SHELL = SHELL_DIR + "/biz-shell/clone_code.sh";
        CODE_COMMIT_SHELL = SHELL_DIR + "/biz-shell/clone_code_by_commit.sh";
        GIT_BRANCH = SHELL_DIR + "/biz-shell/git_branch.sh";
        LCOV_INFO_SHELL = SHELL_DIR + "/biz-shell/lcov_info.sh";
        LCOV_HTML_SHELL = SHELL_DIR + "/biz-shell/lcov_html.sh";
    }

    /**
     * 克隆代码
     *
     * @param gitUrl        仓库地址ssh
     * @param branch        要clone的分支
     * @param localCodePath 本地代码存放路径
     */
    public static boolean cloneCode(String gitUrl, String branch, String localCodePath) {
        ProcessBuilder pb = new ProcessBuilder(CLONE_SHELL, gitUrl, branch,
                localCodePath);
        pb.directory(new File(SHELL_DIR));
        // 合并标准输出流和错误输出流
        pb.redirectErrorStream(true);
        BufferedReader bufferedReader = null;
        Process p = null;
        try {
            p = pb.start();
            bufferedReader = new BufferedReader(new InputStreamReader(p.getInputStream(), StandardCharsets.UTF_8));

            String line;
            while ((line = bufferedReader.readLine()) != null) {
                logger.info("[Git]: {}", line);

                if (line.indexOf("在上游 origin 未发现") != -1 || line.indexOf("not found in upstream origin") != -1) {
                    throw new UserInputException("拉取分支代码失败，请检查分支" + branch + "是否正确");
                }
            }

            int exitCode = p.waitFor();
            logger.info("[Git]: shell 执行结果 {}", exitCode == 0 ? "success" : "exitCode " + exitCode);

        } catch (UserInputException e) {
            throw new UserInputException(e.getMessage());
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            try {
                if (bufferedReader != null) {
                    bufferedReader.close();
                }
                if (p != null) {
                    p.destroy();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return true;
    }


    public static boolean rmDir(String localPath) {
        ProcessBuilder pb = new ProcessBuilder(RM_SHELL, localPath);
        pb.directory(new File(SHELL_DIR));
        // 合并标准输出流和错误输出流
        pb.redirectErrorStream(true);
        BufferedReader bufferedReader = null;
        Process p = null;
        try {
            p = pb.start();
            bufferedReader = new BufferedReader(new InputStreamReader(p.getInputStream(), StandardCharsets.UTF_8));

            String line;
            while ((line = bufferedReader.readLine()) != null) {
                logger.info("[RM]: {}", line);
            }

            int exitCode = p.waitFor();
            logger.info("[RM]: shell 执行结果 {}", exitCode == 0 ? "success" : "exitCode " + exitCode);
        } catch (Exception e) {
            logger.error("[RM]: error", e);
            return false;
        } finally {
            try {
                if (bufferedReader != null) {
                    bufferedReader.close();
                }
                if (p != null) {
                    p.destroy();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return true;
    }

    /**
     * 克隆代码
     * @param iplist  被测服务器iplist
     * @param sourcePath  mergeclass存放位置
     */
    public static boolean dumpmergeclass(String iplist, String sourcePath) {
        ProcessBuilder pb = new ProcessBuilder(MERGECLASS_SHELL, iplist, sourcePath);
        pb.directory(new File(SHELL_DIR));
        pb.redirectErrorStream(true);
        BufferedReader bufferedReader = null;
        Process p = null;
        try {
            p = pb.start();
            bufferedReader = new BufferedReader(new InputStreamReader(p.getInputStream(), StandardCharsets.UTF_8));

            String line;
            while ((line = bufferedReader.readLine()) != null) {
                logger.info("[Dump Merge Class]: {}", line);
                if (line.indexOf("Permission denied") != -1) {
                    throw new UserInputException("复制mergeclass失败，请检查是否与被测服务器间建立信任关系");
                }
            }

            int exitCode = p.waitFor();
            logger.info("[Dump Merge Class]: shell 执行结果 {}", exitCode == 0 ? "success" : "exitCode " + exitCode);
        } catch (UserInputException e) {
            throw new UserInputException(e.getMessage());
        } catch (DeveloperConfigException e) {
            throw new DeveloperConfigException(e.getMessage());
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            try {
                if (bufferedReader != null) {
                    bufferedReader.close();
                }
                if (p != null) {
                    p.destroy();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return true;
    }

    /**
     * 根据分支克隆代码
     *
     * @param gitUrl     仓库地址ssh
     * @param sourcePath 克隆代码后存放位置
     * @param newBranch  被测分支
     * @param oldBranch  比较分支
     */
    public static boolean dumpcode(String gitUrl, String sourcePath, String newBranch, String oldBranch) {
        if (oldBranch == null) {
            oldBranch = "";
        }
        ProcessBuilder pb = new ProcessBuilder(CODE_SHELL, gitUrl, sourcePath, newBranch, oldBranch);
        pb.directory(new File(SHELL_DIR));
        pb.redirectErrorStream(true);
        Process p = null;
        BufferedReader bufferedReader = null;
        try {
            p = pb.start();

            bufferedReader = new BufferedReader(new InputStreamReader(p.getInputStream(), StandardCharsets.UTF_8));
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                logger.info("[Server Git]: {}", line);
                if (line.indexOf("not found in upstream origin") != -1) {
                    throw new UserInputException("拉取分支代码失败，请检查分支" + newBranch + "是否正确或仓库地址是否填写正确");
                }
                if (line.indexOf("你没有权限访问仓库") != -1) {
                    throw new UserInputException("覆盖率平台没有被测试项目git权限，请联系项目负责人增加读的权限");
                }
                if (line.indexOf("Please make sure you have the correct access rights") != -1) {
                    throw new UserInputException("拉取分支代码失败，请检查仓库地址是否填写正确");
                }

            }
            int exitCode = p.waitFor();
            logger.info("[Server Git]: shell 执行结果 {}", exitCode == 0 ? "success" : "exitCode " + exitCode);
        } catch (UserInputException e) {
            throw new UserInputException(e.getMessage());
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            try {
                if (bufferedReader != null) {
                    bufferedReader.close();
                }
                if (p != null) {
                    p.destroy();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return true;
    }

    /**
     * 根据commit克隆代码
     *
     * @param gitUrl     仓库地址ssh
     * @param sourcePath 克隆代码后存放位置
     * @param newBranch  被测分支
     * @param commit     commit
     */
    public static boolean cloneCodeByCommit(String gitUrl, String sourcePath, String newBranch, String commit) {
        ProcessBuilder pb = new ProcessBuilder(CODE_COMMIT_SHELL, gitUrl, sourcePath, newBranch, commit);
        pb.directory(new File(SHELL_DIR));
        pb.redirectErrorStream(true);
        Process p = null;
        BufferedReader bufferedReader = null;
        try {
            p = pb.start();

            bufferedReader = new BufferedReader(new InputStreamReader(p.getInputStream(), StandardCharsets.UTF_8));
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                logger.info("[Server Git commit]: {}", line);
                if (line.indexOf("not found in upstream origin") != -1) {
                    throw new UserInputException("拉取分支代码失败，请检查分支" + newBranch + "是否正确或仓库地址是否填写正确");
                }
                if (line.indexOf("你没有权限访问仓库") != -1) {
                    throw new UserInputException("覆盖率平台没有被测试项目git权限，请联系项目负责人增加读的权限");
                }
                if (line.indexOf("Please make sure you have the correct access rights") != -1) {
                    throw new UserInputException("拉取分支代码失败，请检查仓库地址是否填写正确");
                }
            }

            int exitCode = p.waitFor();
            logger.info("[Server Git commit]: shell 执行结果 {}", exitCode == 0 ? "success" : "exitCode " + exitCode);
        } catch (UserInputException e) {
            throw new UserInputException(e.getMessage());
        } catch (Exception e) {
            logger.error("[Server Git commit]:拉取源码失败", e);
        } finally {
            try {
                if (bufferedReader != null) {
                    bufferedReader.close();
                }
                if (p != null) {
                    p.destroy();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return true;
    }

    /**
     * 获取仓库名称
     *
     * @param gitUrl git地址
     * @return 仓库名称
     */
    public static String getRepositoryName(String gitUrl) {
        String[] urlArr = gitUrl.split("/");
        String projectNameGit = urlArr[urlArr.length - 1];
        return projectNameGit.split("\\.")[0];
    }

    /**
     * 全量模式
     * 目标目录下的生成iOS端覆盖率报告html版本
     *
     * @param localCodePath
     * @return
     */
    public static boolean gcovrHtml(String localCodePath) {
        ProcessBuilder pb = new ProcessBuilder(GCOVR_HTML_SHELL, localCodePath);
        pb.directory(new File(SHELL_DIR));
        pb.redirectErrorStream(true);
        Process p = null;
        BufferedReader bufferedReader = null;

        try {
            p = pb.start();

            bufferedReader = new BufferedReader(new InputStreamReader(p.getInputStream(), StandardCharsets.UTF_8));
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                logger.info("[iOS gcovr_html]: {}", line);
            }

            int exitCode = p.waitFor();
            logger.info("[iOS gcovr_html]: shell 执行结果 {}", exitCode == 0 ? "success" : "exitCode " + exitCode);
        } catch (Exception e) {
            logger.error("[iOS gcovr_html]: {} iOS端覆盖率文件生成html报告失败", localCodePath, e);
            return false;
        } finally {
            try {
                if (bufferedReader != null) {
                    bufferedReader.close();
                }
                if (p != null) {
                    p.destroy();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return true;
    }


    /**
     * 全量模式
     * 目标目录下的生成iOS端覆盖率报告csv版本
     *
     * @param localCodePath
     * @return
     */
    public static boolean gcovrCsv(String localCodePath) {
        ProcessBuilder pb = new ProcessBuilder(GCOVR_CSV_SHELL, localCodePath);
        pb.directory(new File(SHELL_DIR));
        pb.redirectErrorStream(true);
        Process p = null;
        BufferedReader bufferedReader = null;
        try {
            p = pb.start();
            bufferedReader = new BufferedReader(new InputStreamReader(p.getInputStream(), StandardCharsets.UTF_8));
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                logger.info("[iOS gcovr_csv]: {}", line);
            }

            int exitCode = p.waitFor();
            logger.info("[iOS gcovr_csv]: shell 执行结果 {}", exitCode == 0 ? "success" : "exitCode " + exitCode);
        } catch (Exception e) {
            logger.error("[iOS gcovr_csv]: {} iOS端覆盖率文件生成csv报告失败", localCodePath, e);
            return false;
        } finally {
            try {
                if (bufferedReader != null) {
                    bufferedReader.close();
                }
                if (p != null) {
                    p.destroy();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return true;
    }

    /**
     * 增量模式
     * lcov生成html报告
     *
     * @param localCodePath
     * @return
     */
    public static boolean lcovHtml(String localCodePath) {
        ProcessBuilder pb = new ProcessBuilder(LCOV_HTML_SHELL);
        pb.directory(new File(SHELL_DIR));
        pb.redirectErrorStream(true);
        Process p = null;
        BufferedReader bufferedReader = null;

        try {
            p = pb.start();
            bufferedReader = new BufferedReader(new InputStreamReader(p.getInputStream(), StandardCharsets.UTF_8));
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                logger.info("[iOS lcov_html]: {}", line);
            }

            int exitCode = p.waitFor();
            logger.info("[iOS lcov_html]: shell 执行结果 {}", exitCode == 0 ? "success" : "exitCode " + exitCode);
        } catch (Exception e) {
            logger.error("[iOS lcov_html]: {} iOS端覆盖率文件lcov方式生成html报告失败", localCodePath, e);
            return false;
        } finally {
            try {
                if (bufferedReader != null) {
                    bufferedReader.close();
                }
                if (p != null) {
                    p.destroy();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return true;
    }

    /**
     * 增量模式
     * lcov生成info文件
     *
     * @param localCodePath
     * @return
     */
    public static boolean lcovInfo(String localCodePath) {
        ProcessBuilder pb = new ProcessBuilder(LCOV_HTML_SHELL, localCodePath, localCodePath);
        pb.directory(new File(SHELL_DIR));
        pb.redirectErrorStream(true);
        Process p = null;
        BufferedReader bufferedReader = null;

        try {
            p = pb.start();
            bufferedReader = new BufferedReader(new InputStreamReader(p.getInputStream(), StandardCharsets.UTF_8));
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                logger.info("[iOS lcov_html]: {}", line);
            }

            int exitCode = p.waitFor();
            logger.info("[iOS lcov_info]: shell 执行结果 {}", exitCode == 0 ? "success" : "exitCode " + exitCode);
        } catch (Exception e) {
            logger.error("[iOS lcov_info]: {} iOS端覆盖率文件lcov方式生成info报告失败", localCodePath, e);
            return false;
        } finally {
            try {
                if (bufferedReader != null) {
                    bufferedReader.close();
                }
                if (p != null) {
                    p.destroy();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return true;
    }


    public static ApiResponse<Object> getGitBranch(String branchFileName, String gitAddress) {
        ProcessBuilder processBuilder = new ProcessBuilder(GIT_BRANCH,
                branchFileName, gitAddress, GitBranchConstant.GIT_COMPONENT_PATH, GitBranchConstant.BRANCH_FILE_PATH, GitBranchConstant.SUFFIX);
        processBuilder.directory(new File(SHELL_DIR));
        processBuilder.redirectErrorStream(true);
        String stdInputInfo = null;
        try {
            Process start = processBuilder.start();
            BufferedReader stdInput = new BufferedReader(new InputStreamReader(start.getInputStream()));
            String line = null;
            while ((line = stdInput.readLine()) != null) {
                stdInputInfo = line;
                log.info("GitBranchUtils shell info = {}", stdInputInfo);
            }
            start.waitFor();
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (stdInputInfo.equals("0")) {
            log.info("获取{}仓库分支成功,已经重定向到{}文件中", gitAddress, GitBranchConstant.BRANCH_FILE_PATH + branchFileName);
        } else {
            return ApiResponse.buildFailure("获取分支信息失败，请检查git地址是否正确或联系管理员");
        }
        File file = new File(GitBranchConstant.BRANCH_FILE_PATH + branchFileName + ".txt");
        List<String> branchList = new ArrayList<>();
        try {
            BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
            String line = null;
            while ((line = bufferedReader.readLine()) != null) {
                int i = line.lastIndexOf("origin/");
                if (i != -1) {
                    branchList.add(line.substring(i + 7));
                }
            }
        } catch (Exception e) {
            log.info("error {}", e.getMessage());
        }
        return ApiResponse.buildSuccess(branchList.stream().distinct().collect(Collectors.toList()));
    }
}