package com.maoyan.coverage.admin.common.utils;

import org.apache.http.client.HttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.LaxRedirectStrategy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

/**
 * @author lizhuoran05
 * @date 2021/8/17
 */
public class HttpUtils {
    private static final Logger LOGGER = LoggerFactory.getLogger(HttpUtils.class);

    private static final String UTF8 = "UTF-8";

    private static final int CONNECT_TIMEOUT = 10000;

    private static final int READ_TIMEOUT = 10000;

    private HttpUtils() {
    }

    /**
     * 无自定义header的get方法
     *
     * @param url
     * @param jsonParams
     * @param connectTimeOut
     * @param readTimeOut
     * @return
     */
    public static String get(String url,
                             String jsonParams,
                             Integer connectTimeOut,
                             Integer readTimeOut) {

        return doRequest(url, jsonParams, HttpMethod.GET, connectTimeOut, readTimeOut, null, null);
    }

    public static String get(String url, HttpHeaders httpHeaders) {
        return doRequest(url, null, HttpMethod.GET, CONNECT_TIMEOUT, READ_TIMEOUT, httpHeaders, null);
    }

    public static String get(String url) {
        return doRequest(url, null, HttpMethod.GET, CONNECT_TIMEOUT, READ_TIMEOUT, null, null);
    }

    public static String get(String url, String jsonParams, HttpHeaders headers, String uriVariables) {
        return doRequest(url, jsonParams, HttpMethod.GET, CONNECT_TIMEOUT, READ_TIMEOUT, headers, uriVariables);
    }

    /**
     * 有自定义header的get方法
     *
     * @param url
     * @param jsonParams
     * @param connectTimeOut
     * @param readTimeOut
     * @param headers
     * @return
     */
    public static String get(String url,
                             String jsonParams,
                             Integer connectTimeOut,
                             Integer readTimeOut,
                             HttpHeaders headers) {
        return doRequest(url, jsonParams, HttpMethod.GET, connectTimeOut, readTimeOut, headers, null);
    }

    /**
     * 无自定义header的post方法
     *
     * @param url
     * @param jsonParams
     * @param connectTimeOut
     * @param readTimeOut
     * @return
     */
    public static String post(String url,
                              String jsonParams,
                              Integer connectTimeOut,
                              Integer readTimeOut) {
        return doRequest(url, jsonParams, HttpMethod.POST, connectTimeOut, readTimeOut, null, null);
    }

    /**
     * 有自定义header的post方法
     *
     * @param url
     * @param jsonParams
     * @param connectTimeOut
     * @param readTimeOut
     * @param headers
     * @return
     */
    public static String post(String url,
                              String jsonParams,
                              Integer connectTimeOut,
                              Integer readTimeOut,
                              HttpHeaders headers) {
        return doRequest(url, jsonParams, HttpMethod.POST, connectTimeOut, readTimeOut, headers, null);
    }

    public static String post(String url,
                              String jsonParams,
                              HttpHeaders headers) {
        return doRequest(url, jsonParams, HttpMethod.POST, CONNECT_TIMEOUT, READ_TIMEOUT, headers, null);
    }

    /**
     * 参数为MultiValueMap
     *
     * @param url
     * @param jsonParams
     * @param headers
     * @return
     */
    public static String post(String url, MultiValueMap jsonParams, HttpHeaders headers) {
        return doRequest(url, jsonParams, HttpMethod.POST, headers);
    }

    public static String put(String url,
                             String jsonParams,
                             Integer connectTimeOut,
                             Integer readTimeOut,
                             HttpHeaders headers) {
        return doRequest(url, jsonParams, HttpMethod.PUT, connectTimeOut, readTimeOut, headers, null);
    }

    public static String delete(String url,
                                String jsonParams,
                                Integer connectTimeOut,
                                Integer readTimeOut,
                                HttpHeaders headers) {
        return doRequest(url, jsonParams, HttpMethod.DELETE, connectTimeOut, readTimeOut, headers, null);
    }

    private static String doRequest(String url,
                                    String jsonParams,
                                    HttpMethod method,
                                    Integer connectTimeOut,
                                    Integer readTimeOut,
                                    HttpHeaders headers,
                                    String uriVariables) {
        String result;
        try {
            if (headers == null) {
                headers = new HttpHeaders();
                headers.add("Accept-Charset", UTF8);
                headers.add("Content-type", "application/json; charset=UTF-8");
            }

            HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
            requestFactory.setConnectTimeout(connectTimeOut == null ? CONNECT_TIMEOUT : connectTimeOut);
            requestFactory.setReadTimeout(readTimeOut == null ? READ_TIMEOUT : readTimeOut);
            final HttpClient httpClient = HttpClientBuilder.create()
                    .setRedirectStrategy(new LaxRedirectStrategy())
                    .build();
            requestFactory.setHttpClient(httpClient);
            RestTemplate template = new RestTemplate(requestFactory);

            HttpEntity<String> formEntity = new HttpEntity<>(jsonParams, headers);
            ResponseEntity<String> responseEntity = template.exchange(url, method, formEntity, String.class, uriVariables);
            result = responseEntity.getBody();
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
            throw e;
        }

        return result;
    }

    public static String doRequest(String url, MultiValueMap jsonParams, HttpMethod method, HttpHeaders headers) {
        String result = null;

        try {
            HttpEntity<MultiValueMap> formEntity = new HttpEntity<>(jsonParams, headers);
            SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
            requestFactory.setConnectTimeout(CONNECT_TIMEOUT);
            requestFactory.setReadTimeout(READ_TIMEOUT);

            RestTemplate template = new RestTemplate(requestFactory);
            ResponseEntity<String> responseEntity = template.exchange(url, method, formEntity, String.class);

            result = responseEntity.getBody();
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        }

        return result;

    }
}
