package com.maoyan.coverage.admin.common.utils;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author yimingyu
 * @date 2021/09/17
 */
@Slf4j
public class IPUtils {

    public static boolean isIP(String ipStr){
        if (StringUtils.isEmpty(ipStr) || ipStr.split("\\.").length != 4){
            return false;
        }
        String regex = "^(((\\d{1,2})|(1\\d{2})|(2[0-4]\\d)|(25[0-5]))\\.){3}((\\d{1,2})|(1\\d{2})|(2[0-4]\\d)|(25[0-5]))$";
        Pattern compile = Pattern.compile(regex);
        Matcher matcher = compile.matcher(ipStr);
        if (matcher.find()){
            log.info(matcher.group(1));
            return true;
        }
        return false;
    }

    public static boolean isIpBatch(List<String> ipList){
        log.info("server job ipList = {}", ipList);
        if (CollectionUtils.isEmpty(ipList)){
            return false;
        }
        boolean rest = ipList.stream().allMatch(IPUtils::isIP);
        return rest;
    }

}
