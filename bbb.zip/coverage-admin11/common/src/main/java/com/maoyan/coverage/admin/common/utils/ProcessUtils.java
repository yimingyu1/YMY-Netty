package com.maoyan.coverage.admin.common.utils;

import java.text.DecimalFormat;

/**
 * @author lizhuoran05
 * @date 2021/8/16
 */
public class ProcessUtils {

    private static int count = 0;

    /**
     * 进度条长度
     */
    private static final int BAR_LEN = 50;

    /**
     * 用于进度条显示的字符
     */
    private static final char SHOW_CHAR = '#';

    private static final DecimalFormat FORMAT = new DecimalFormat("#.##%");

    /**
     * 显示进度条
     */
    public static void show(String title, int value, int total) {
        reset();
        // 比例
        float rate = (float) (value * 1.0 / total);
        // 比例*进度条总长度=当前长度
        draw(title, rate);
        if (value == total) {
            afterComplete();
        }
    }

    /**
     * 画指定长度的SHOW_CHAR
     */
    private static void draw(String title, float rate) {
        int len = (int) (rate * ProcessUtils.BAR_LEN);
        System.out.print(title + "  ");
        for (int i = 0; i < len; i++) {
            System.out.print(SHOW_CHAR);
        }
        for (int i = 0; i < ProcessUtils.BAR_LEN - len; i++) {
            System.out.print(" ");
        }
        System.out.print(" |" + format(rate));
    }


    /**
     * 光标移动到行首
     */
    private static void reset() {
        System.out.print('\r');
    }

    /**
     * 完成后换行
     */
    private static void afterComplete() {
        System.out.println();
    }

    private static String format(float num) {
        return FORMAT.format(num);
    }
}
