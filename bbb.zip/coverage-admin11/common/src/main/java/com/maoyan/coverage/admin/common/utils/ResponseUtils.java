package com.maoyan.coverage.admin.common.utils;


import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Maps;
import com.maoyan.coverage.admin.domain.model.ErrorResponse;
import com.maoyan.coverage.admin.domain.model.Paging;

import java.util.Map;

public class ResponseUtils {

    public static Object buildGoodResponse(){
        return buildResponse(true, null, null, null, null);
    }

    public static Object buildGoodResponse(Object data){
        return buildResponse(true, null, data, null, null);
    }

    public static Object buildGoodResponse(String key, Object value){
        Map<String, Object> data = ImmutableMap.<String, Object>builder().put(key, value).build();
        return buildResponse(true, null, data, null, null);
    }

    public static Object buildGoodResponse(Object data, Paging paging, Long timestamp){
        return buildResponse(true, null, data, paging, timestamp);
    }

    public static Object buildBadResponse(ErrorResponse error){
        return buildResponse(false, error, null, null, null);
    }

    private static Object buildResponse(boolean isSuccess, ErrorResponse error, Object data, Paging paging, Long timestamp){
        Map<String, Object> response = Maps.newHashMap();
        response.put("success", isSuccess);
        if (!isSuccess){
            response.put("error", error);
        } else {
            response.put("data", data);
            if (paging != null){
                response.put("paging", paging);
            }
            if (timestamp != null){
                response.put("timestamp", timestamp);
            }
        }
        return response;
    }
}
